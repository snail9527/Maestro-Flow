/**
 * Spec entry parser — shared between specs routes and WikiIndexer.
 *
 * Extracts SpecEntry objects from markdown body text. Supports both
 * `<spec-entry>` closed-tag format and legacy heading-based format.
 */
import { basename, extname } from 'node:path';
// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------
const ENTRY_TYPES = [
    'coding', 'arch', 'quality', 'debug', 'test', 'review', 'learning', 'tools',
    'bug', 'pattern', 'decision', 'rule', 'validation',
];
const FILE_TYPE_MAP = {
    learnings: 'learning',
    'coding-conventions': 'coding',
    'architecture-constraints': 'arch',
    'quality-rules': 'review',
    'debug-notes': 'debug',
    tools: 'tools',
    'test-conventions': 'test',
    'review-standards': 'review',
};
export const FILE_CATEGORY_MAP = {
    learnings: 'learning',
    'coding-conventions': 'coding',
    'architecture-constraints': 'arch',
    'quality-rules': 'review',
    'debug-notes': 'debug',
    'test-conventions': 'test',
    'review-standards': 'review',
    tools: 'tools',
};
// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
/** Heading regex: matches ## or ### at start of line. */
export const HEADING_RE = /^(#{2,3})\s+(.+)$/;
const TAG_ATTR_RE = /([\w-]+)="([^"]*)"/g;
/** Detect entry type from heading text or fall back to file-based default. */
export function detectEntryType(heading, fileName) {
    const lower = heading.toLowerCase();
    for (const t of ENTRY_TYPES) {
        if (lower.includes(`[${t}]`))
            return t;
    }
    for (const t of ENTRY_TYPES) {
        if (new RegExp(`\\b${t}\\s*:`).test(lower))
            return t;
    }
    const stem = basename(fileName, extname(fileName));
    return FILE_TYPE_MAP[stem] ?? 'general';
}
/** Strip [type], [date], and legacy "type:" prefix from heading to get clean title. */
export function extractCleanTitle(heading) {
    return heading
        .replace(/\[(coding|arch|quality|debug|test|review|learning|bug|pattern|decision|rule|validation)\]\s*/gi, '')
        .replace(/\[\d{4}-\d{2}-\d{2}\]\s*/g, '')
        .replace(/\d{4}-\d{2}-\d{2}T[\d:.Z+-]*/g, '')
        .replace(/^(coding|arch|quality|debug|test|review|learning|bug|pattern|decision|rule|validation)\s*:\s*/i, '')
        .trim();
}
// ---------------------------------------------------------------------------
// Parser
// ---------------------------------------------------------------------------
/**
 * Generic entry block parser. Extracts closed-tag blocks matching `tagName`,
 * then parses remaining text with legacy heading-based parser.
 */
function parseEntryBlocks(body, tagName, fileName, frontmatter) {
    const stem = basename(fileName, extname(fileName));
    const entries = [];
    let entryIndex = 0;
    // Pass 1: Extract <tagName> closed-tag blocks
    const tagRe = new RegExp(`<${tagName}\\s+([^>]+)>([\\s\\S]*?)<\\/${tagName}>`, 'g');
    const consumedRanges = [];
    let tagMatch;
    while ((tagMatch = tagRe.exec(body)) !== null) {
        const attrStr = tagMatch[1];
        const innerContent = tagMatch[2].trim();
        consumedRanges.push({ start: tagMatch.index, end: tagMatch.index + tagMatch[0].length });
        const attrs = {};
        let attrMatch;
        TAG_ATTR_RE.lastIndex = 0;
        while ((attrMatch = TAG_ATTR_RE.exec(attrStr)) !== null) {
            attrs[attrMatch[1]] = attrMatch[2];
        }
        const titleMatch = innerContent.match(/^###\s+(.+)$/m);
        const title = attrs.title || (titleMatch ? titleMatch[1].trim() : innerContent.split('\n')[0].trim());
        const type = attrs.type ?? detectEntryType(title, fileName);
        const id = `${stem}-${String(++entryIndex).padStart(3, '0')}`;
        const kws = attrs.keywords ? attrs.keywords.split(',').map((k) => k.trim().toLowerCase()).filter(Boolean) : [];
        const ref = attrs.ref || undefined;
        const description = attrs.description || undefined;
        const entryCategory = attrs.category
            || (typeof frontmatter?.category === 'string' ? frontmatter.category : null)
            || FILE_CATEGORY_MAP[stem]
            || 'general';
        const VALID_CONFIDENCE = ['high', 'medium', 'low', 'contested'];
        const VALID_STATUS = ['active', 'deprecated'];
        const rawConfidence = attrs.confidence || undefined;
        const confidence = rawConfidence && VALID_CONFIDENCE.includes(rawConfidence) ? rawConfidence : undefined;
        const conflictNote = attrs['conflict-note'] || undefined;
        const sid = attrs.sid || undefined;
        const supersedes = attrs.supersedes || undefined;
        const supersededBy = attrs['superseded-by'] || undefined;
        const rawStatus = attrs.status || undefined;
        const status = rawStatus && VALID_STATUS.includes(rawStatus) ? rawStatus : undefined;
        entries.push({
            id,
            type,
            title,
            description,
            content: innerContent,
            file: fileName,
            timestamp: attrs.date ?? '',
            category: entryCategory,
            keywords: kws,
            ...(ref ? { ref } : {}),
            ...(confidence ? { confidence } : {}),
            ...(conflictNote ? { conflictNote } : {}),
            ...(sid ? { sid } : {}),
            ...(supersedes ? { supersedes } : {}),
            ...(supersededBy ? { supersededBy } : {}),
            ...(status ? { status } : {}),
        });
    }
    // Pass 2: Parse remaining text with legacy heading-based parser
    let remaining = body;
    for (const range of consumedRanges.reverse()) {
        remaining = remaining.substring(0, range.start) + remaining.substring(range.end);
    }
    const lines = remaining.split('\n');
    const sections = [];
    let current = null;
    for (const line of lines) {
        const m = line.match(HEADING_RE);
        if (m) {
            if (current)
                sections.push(current);
            current = { heading: m[2].trim(), level: m[1].length, bodyLines: [] };
        }
        else if (current) {
            current.bodyLines.push(line);
        }
    }
    if (current)
        sections.push(current);
    for (const sec of sections) {
        const content = sec.bodyLines.join('\n').trim();
        if (!content)
            continue;
        const type = detectEntryType(sec.heading, fileName);
        const id = `${stem}-${String(++entryIndex).padStart(3, '0')}`;
        const dateMatch = sec.heading.match(/\[(\d{4}-\d{2}-\d{2})\]/) ?? sec.heading.match(/(\d{4}-\d{2}-\d{2})/);
        const timestamp = dateMatch ? dateMatch[1] : '';
        const title = extractCleanTitle(sec.heading) || sec.heading;
        const category = typeof frontmatter?.category === 'string'
            ? frontmatter.category
            : (FILE_CATEGORY_MAP[stem] ?? 'general');
        const keywords = Array.isArray(frontmatter?.keywords)
            ? frontmatter.keywords.map(String)
            : [];
        entries.push({ id, type, title, content, file: fileName, timestamp, category, keywords });
    }
    return entries;
}
/**
 * Parse markdown body into SpecEntry objects from <spec-entry> blocks.
 */
export function parseSpecEntries(body, fileName, frontmatter) {
    return parseEntryBlocks(body, 'spec-entry', fileName, frontmatter);
}
/**
 * Parse markdown body into SpecEntry objects from <knowhow-entry> blocks.
 */
export function parseKnowhowEntries(body, fileName, frontmatter) {
    return parseEntryBlocks(body, 'knowhow-entry', fileName, frontmatter);
}
//# sourceMappingURL=spec-entry-parser.js.map