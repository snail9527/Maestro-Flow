// ---------------------------------------------------------------------------
// Room Types — internal types for meeting room subsystems
// ---------------------------------------------------------------------------
export {};
//# sourceMappingURL=room-types.js.map