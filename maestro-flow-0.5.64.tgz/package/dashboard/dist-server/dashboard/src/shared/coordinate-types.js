// ---------------------------------------------------------------------------
// Coordinate Runner types -- session, step, and event payload interfaces
// ---------------------------------------------------------------------------
export {};
//# sourceMappingURL=coordinate-types.js.map