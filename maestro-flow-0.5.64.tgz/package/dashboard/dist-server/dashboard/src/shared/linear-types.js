// ---------------------------------------------------------------------------
// Linear API types -- shared between server and client
// ---------------------------------------------------------------------------
export const LINEAR_PRIORITY_LABELS = {
    0: 'No priority',
    1: 'Urgent',
    2: 'High',
    3: 'Medium',
    4: 'Low',
};
export const LINEAR_PRIORITY_COLORS = {
    0: '#A09D97',
    1: '#C46555',
    2: '#B89540',
    3: '#5B8DB8',
    4: '#A09D97',
};
//# sourceMappingURL=linear-types.js.map