// ---------------------------------------------------------------------------
// Maestro session types — parsed from .workflow/.maestro/*/status.json
// and walker-state.json for the Maestro Coordinate dashboard page
// ---------------------------------------------------------------------------
export {};
//# sourceMappingURL=maestro-session-types.js.map