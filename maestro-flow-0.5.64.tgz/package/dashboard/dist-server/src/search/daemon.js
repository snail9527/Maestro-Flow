/**
 * Search daemon — resident process that keeps WikiIndexer + ONNX model warm.
 *
 * Protocol: line-delimited JSON over TCP on localhost.
 * Lock: .workflow/search-daemon.json with PID + port.
 * Idle timeout: auto-shutdown after 30 min of inactivity.
 */
import { createServer, connect } from 'node:net';
import { resolve, join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { existsSync, readFileSync, writeFileSync, unlinkSync } from 'node:fs';
import { WikiIndexer } from '#maestro-dashboard/wiki/wiki-indexer.js';
import { buildInvertedIndex } from '#maestro-dashboard/wiki/search.js';
const IDLE_TIMEOUT_MS = 30 * 60 * 1000;
const DAEMON_FILE = 'search-daemon.json';
export function getDaemonPath(workflowRoot) {
    return join(workflowRoot, DAEMON_FILE);
}
export function readDaemonInfo(workflowRoot) {
    const p = getDaemonPath(workflowRoot);
    if (!existsSync(p))
        return null;
    try {
        return JSON.parse(readFileSync(p, 'utf-8'));
    }
    catch {
        return null;
    }
}
export function isDaemonAlive(info) {
    try {
        process.kill(info.pid, 0);
        return true;
    }
    catch {
        return false;
    }
}
export function queryDaemon(port, req) {
    return new Promise((resolve, reject) => {
        const socket = connect(port, '127.0.0.1');
        let buf = '';
        socket.setTimeout(5000);
        socket.on('connect', () => { socket.write(JSON.stringify(req) + '\n'); });
        socket.on('data', (chunk) => { buf += chunk.toString(); });
        socket.on('end', () => {
            try {
                resolve(JSON.parse(buf));
            }
            catch {
                reject(new Error('bad response'));
            }
        });
        socket.on('error', reject);
        socket.on('timeout', () => { socket.destroy(); reject(new Error('timeout')); });
    });
}
export async function tryDaemonSearch(workflowRoot, query, limit, skipEmbedding) {
    const info = readDaemonInfo(workflowRoot);
    if (!info || !isDaemonAlive(info))
        return null;
    try {
        return await queryDaemon(info.port, { action: 'search', query, limit, skipEmbedding });
    }
    catch {
        return null;
    }
}
// ── Server ──────────────────────────────────────────────────────────────
export async function startDaemon(workflowRoot, config) {
    // Check existing daemon
    const existing = readDaemonInfo(workflowRoot);
    if (existing && isDaemonAlive(existing)) {
        throw new Error(`Daemon already running (pid=${existing.pid}, port=${existing.port})`);
    }
    const indexer = new WikiIndexer(config);
    // Pre-warm: build index + BM25 + embedding
    const index = await indexer.rebuild();
    let bm25 = buildInvertedIndex(index.entries);
    const embeddingWarm = indexer.getEmbeddingIndex().catch(() => null);
    let idleTimer = null;
    const resetIdle = (server) => {
        if (idleTimer)
            clearTimeout(idleTimer);
        idleTimer = setTimeout(() => { shutdown(server, workflowRoot); }, IDLE_TIMEOUT_MS);
    };
    const server = createServer((socket) => {
        let buf = '';
        socket.on('data', (chunk) => {
            buf += chunk.toString();
            const nlIdx = buf.indexOf('\n');
            if (nlIdx === -1)
                return;
            const line = buf.slice(0, nlIdx);
            buf = buf.slice(nlIdx + 1);
            handleRequest(line, indexer, () => bm25, socket).then(() => {
                resetIdle(server);
            });
        });
    });
    await embeddingWarm;
    return new Promise((res, reject) => {
        server.listen(0, '127.0.0.1', () => {
            const addr = server.address();
            if (!addr || typeof addr === 'string') {
                reject(new Error('bad addr'));
                return;
            }
            const port = addr.port;
            const info = { pid: process.pid, port, startedAt: new Date().toISOString() };
            writeFileSync(getDaemonPath(workflowRoot), JSON.stringify(info));
            resetIdle(server);
            res({ port, server });
        });
        server.on('error', reject);
    });
}
async function handleRequest(line, indexer, getBm25, socket) {
    let resp;
    try {
        const req = JSON.parse(line);
        if (req.action === 'search') {
            const { results, embeddingUsed, embeddingDocs } = await indexer.searchWithMeta(req.query, req.limit, { skipEmbedding: req.skipEmbedding });
            resp = { ok: true, results, embeddingUsed, embeddingDocs };
        }
        else {
            resp = { ok: false, error: `unknown action` };
        }
    }
    catch (e) {
        resp = { ok: false, error: e instanceof Error ? e.message : String(e) };
    }
    socket.end(JSON.stringify(resp) + '\n');
}
function shutdown(server, workflowRoot) {
    try {
        unlinkSync(getDaemonPath(workflowRoot));
    }
    catch { }
    server.close();
    process.exit(0);
}
// ── Stop ────────────────────────────────────────────────────────────────
export function stopDaemon(workflowRoot) {
    const info = readDaemonInfo(workflowRoot);
    if (!info)
        return false;
    try {
        unlinkSync(getDaemonPath(workflowRoot));
    }
    catch { }
    if (isDaemonAlive(info)) {
        try {
            process.kill(info.pid, 'SIGTERM');
            return true;
        }
        catch {
            return false;
        }
    }
    return false;
}
// ── Spawn (detached, for hooks) ─────────────────────────────────────────
export async function spawnDaemon(workflowRoot) {
    const existing = readDaemonInfo(workflowRoot);
    if (existing && isDaemonAlive(existing))
        return;
    // Clean stale PID file
    if (existing)
        try {
            unlinkSync(getDaemonPath(workflowRoot));
        }
        catch { }
    const { spawn: spawnProc } = await import('node:child_process');
    const selfDir = dirname(fileURLToPath(import.meta.url));
    const binPath = resolve(selfDir, '..', 'cli.js');
    const child = spawnProc(process.execPath, [binPath, 'search-start-daemon'], { cwd: resolve(workflowRoot, '..'), detached: true, stdio: 'ignore' });
    child.unref();
}
//# sourceMappingURL=daemon.js.map