/**
 * Shared types and utilities for the search daemon (client + server).
 * Single source of truth — both daemon.ts and daemon-client.ts import from here.
 */
import { join } from 'node:path';
import { existsSync, readFileSync } from 'node:fs';
const DAEMON_FILE = 'search-daemon.json';
export function getDaemonPath(workflowRoot) {
    return join(workflowRoot, DAEMON_FILE);
}
export function readDaemonInfo(workflowRoot) {
    const p = getDaemonPath(workflowRoot);
    if (!existsSync(p))
        return null;
    try {
        return JSON.parse(readFileSync(p, 'utf-8'));
    }
    catch {
        return null;
    }
}
export function isDaemonAlive(info) {
    try {
        process.kill(info.pid, 0);
        return true;
    }
    catch {
        return false;
    }
}
//# sourceMappingURL=daemon-types.js.map