// src/graph/kg/extraction/code/plugin-types.ts
// MaestroGraph extractor plugin system types
// Supports declarative (YAML rules) and script (.mjs) modes
export {};
//# sourceMappingURL=plugin-types.js.map