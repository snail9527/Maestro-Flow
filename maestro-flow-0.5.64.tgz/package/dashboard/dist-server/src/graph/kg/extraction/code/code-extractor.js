// src/graph/kg/extraction/code/code-extractor.ts
// 代码提取编排器 — 扫描源文件 → 语言检测 → tree-sitter 解析 → 生成 nodes + edges
// 参考: codegraph extraction pipeline
import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs';
import { resolve, extname, join, relative } from 'node:path';
import { execFileSync } from 'node:child_process';
import { getTreeSitterEngine } from './tree-sitter.js';
import { getExtractor, detectLanguageFromPath, isFileLevelOnlyLanguage } from './languages/index.js';
import { isGeneratedFile, isTestFile } from './generated-detection.js';
import { symbolToNode, makeCodeNodeId, makeFileNodeId } from './tree-sitter-types.js';
import { extractVueSFC } from './vue-extractor.js';
import { extractSvelte } from './svelte-extractor.js';
import { extractLiquid } from './liquid-extractor.js';
import { extractMybatisXml } from './mybatis-extractor.js';
import { extractDfm } from './dfm-extractor.js';
import { createHash } from 'node:crypto';
import { PluginEngine } from './plugin-engine.js';
import { buildScanScope } from './scan-scope.js';
import { CodeParseRunner } from './worker-parser.js';
const BINARY_EXTENSIONS = new Set([
    '.wasm', '.png', '.jpg', '.jpeg', '.gif', '.svg', '.ico',
    '.woff', '.woff2', '.ttf', '.eot', '.mp4', '.webm',
    '.zip', '.tar', '.gz', '.exe', '.dll', '.so', '.dylib',
]);
const DEFAULT_MAX_FILE_SIZE = 1024 * 1024; // 1MB, aligned with CodeGraph
function scanFiles(options) {
    const files = [];
    const maxFileSize = options.maxFileSize ?? DEFAULT_MAX_FILE_SIZE;
    const srcDir = resolve(options.srcDir);
    const scope = buildScanScope({
        projectRoot: options.projectRoot ?? srcDir,
        srcDir,
        excludeDirs: options.excludeDirs,
        excludeFiles: options.excludeFiles,
        createMaestroIgnore: options.createMaestroIgnore,
    });
    if (!existsSync(srcDir))
        return files;
    function collectFile(fullPath) {
        let stat;
        try {
            stat = statSync(fullPath);
        }
        catch {
            return;
        }
        if (!stat.isFile())
            return;
        if (scope.ignores(fullPath))
            return;
        if (stat.size > maxFileSize)
            return;
        const ext = extname(fullPath).toLowerCase();
        if (BINARY_EXTENSIONS.has(ext))
            return;
        const language = detectLanguageFromPath(fullPath);
        if (language === 'unknown')
            return;
        if (!options.includeTests && isTestFile(fullPath))
            return;
        files.push({
            path: fullPath,
            language,
            size: stat.size,
            modifiedAt: Math.floor(stat.mtimeMs),
            contentHash: '',
        });
    }
    function collectGitVisibleFiles() {
        const srcRel = relative(scope.projectRoot, srcDir).replace(/\\/g, '/') || '.';
        if (srcRel.startsWith('..'))
            return false;
        try {
            const output = execFileSync('git', ['ls-files', '-z', '-c', '-o', '--exclude-standard', '--', srcRel], {
                cwd: scope.projectRoot,
                encoding: 'utf-8',
                maxBuffer: 50 * 1024 * 1024,
                stdio: ['pipe', 'pipe', 'ignore'],
                timeout: 30_000,
                windowsHide: true,
            });
            for (const relPath of output.split('\0').filter(Boolean)) {
                collectFile(resolve(scope.projectRoot, relPath));
            }
            return true;
        }
        catch {
            return false;
        }
    }
    function walkDir(dir) {
        let entries;
        try {
            entries = readdirSync(dir);
        }
        catch {
            return;
        }
        for (const entry of entries) {
            const fullPath = join(dir, entry);
            let stat;
            try {
                stat = statSync(fullPath);
            }
            catch {
                continue;
            }
            if (stat.isDirectory()) {
                if (!scope.ignores(fullPath, true))
                    walkDir(fullPath);
                continue;
            }
            collectFile(fullPath);
        }
    }
    if (!collectGitVisibleFiles()) {
        walkDir(srcDir);
    }
    return files;
}
/**
 * 批量代码提取 — 扫描目录 → tree-sitter 解析 → nodes + edges
 *
 * 设计: 逐文件提取, 汇总后返回结果；大仓库写库请使用 forEachCodeExtractionResult()
 * 支持: 自定义提取器 (vue/svelte/liquid/mybatis/dfm) 优先于通用 tree-sitter
 */
export async function extractCode(options) {
    return runCodeExtraction(options, undefined, true);
}
/**
 * 流式代码提取 — 每个文件提取完成后立即回调，避免在内存中累积全量结果。
 */
export async function forEachCodeExtractionResult(options, onResult) {
    const { stats } = await runCodeExtraction(options, onResult, false);
    return stats;
}
async function runCodeExtraction(options, onResult, collectResults) {
    const startMs = Date.now();
    const resolvedSrcDir = resolve(options.srcDir);
    const engine = getTreeSitterEngine();
    const hasTreeSitter = engine.isAvailable();
    const parser = new CodeParseRunner();
    // 插件引擎
    const projectRoot = options.projectRoot ?? resolve(resolvedSrcDir, '..');
    const pluginEngine = new PluginEngine(projectRoot);
    let hasPlugins = false;
    try {
        hasPlugins = await pluginEngine.load({ allowScripts: options.allowExtractorScripts });
    }
    catch { /* plugins optional */ }
    // 扫描文件
    const scannedFiles = scanFiles(options);
    const results = [];
    const errors = [];
    let totalNodes = 0;
    let totalEdges = 0;
    let totalRefs = 0;
    let extractedCount = 0;
    let skippedCount = 0;
    const emitResult = async (result, referencesCount) => {
        if (collectResults) {
            results.push(result);
        }
        await onResult?.(result);
        totalNodes += result.nodes.length;
        totalEdges += result.edges.length;
        totalRefs += referencesCount;
        extractedCount++;
    };
    try {
        for (let i = 0; i < scannedFiles.length; i++) {
            const file = scannedFiles[i];
            options.onProgress?.(file.path, i + 1, scannedFiles.length);
            try {
                const sourceCode = readFileSync(file.path, 'utf-8');
                file.contentHash = createHash('sha256').update(sourceCode).digest('hex').substring(0, 16);
                const relPath = relative(resolvedSrcDir, file.path).replace(/\\/g, '/');
                // 自定义提取器优先 (vue/svelte/liquid/mybatis/dfm)
                const customResult = await extractWithCustomExtractor(sourceCode, file.path);
                if (customResult) {
                    const { nodes, edges } = buildResultFromCustomExtractor(customResult.symbols, customResult.references, customResult.edges, file, relPath);
                    const normalizedRefs = normalizeReferenceAnchors(customResult.references, file.path);
                    await emitResult({
                        nodes,
                        edges,
                        references: normalizedRefs,
                        fileRecord: createFileRecord(file, nodes.length),
                    }, normalizedRefs.length);
                    continue;
                }
                // file-level-only 语言 (yaml/twig/properties)
                if (isFileLevelOnlyLanguage(file.language)) {
                    const fileNode = createFileLevelNode(file, relPath);
                    await emitResult({
                        nodes: [fileNode],
                        edges: [],
                        references: [],
                        fileRecord: createFileRecord(file, 1),
                    }, 0);
                    continue;
                }
                // tree-sitter 通用提取
                if (!hasTreeSitter) {
                    skippedCount++;
                    continue;
                }
                const extractor = getExtractor(file.language);
                if (!extractor) {
                    skippedCount++;
                    continue;
                }
                let extracted = null;
                const fileMatchesPlugin = hasPlugins && pluginEngine.hasMatchingPlugin(file.path, file.language);
                if (fileMatchesPlugin) {
                    const tree = await engine.parse(sourceCode, file.language);
                    if (tree) {
                        try {
                            extracted = extractor.extract(tree, sourceCode, file.path);
                            try {
                                const pluginResult = await pluginEngine.run(file.path, sourceCode, file.language, tree, extracted);
                                if (pluginResult.symbols.length > 0 || (pluginResult.references?.length ?? 0) > 0 || (pluginResult.edges?.length ?? 0) > 0) {
                                    extracted = pluginEngine.mergeResults(extracted, pluginResult);
                                }
                            }
                            catch {
                                // Plugin extraction is best-effort and must not block core indexing.
                            }
                        }
                        finally {
                            tree.delete();
                        }
                    }
                }
                else {
                    extracted = await parser.extract(sourceCode, file.language, file.path);
                }
                if (!extracted) {
                    errors.push({ filePath: file.path, message: 'tree-sitter parse failed' });
                    skippedCount++;
                    continue;
                }
                const { nodes, edges, normalizedRefs } = buildResultFromTreeSitter(extracted, file);
                await emitResult({
                    nodes,
                    edges,
                    references: normalizedRefs,
                    fileRecord: createFileRecord(file, nodes.length),
                }, normalizedRefs.length);
            }
            catch (err) {
                errors.push({
                    filePath: file.path,
                    message: err instanceof Error ? err.message : String(err),
                });
                skippedCount++;
            }
        }
    }
    finally {
        parser.dispose();
    }
    return {
        results,
        stats: {
            filesScanned: scannedFiles.length,
            filesExtracted: extractedCount,
            filesSkipped: skippedCount,
            nodesCreated: totalNodes,
            edgesCreated: totalEdges,
            referencesCollected: totalRefs,
            errors,
            durationMs: Date.now() - startMs,
        },
    };
}
// ---------------------------------------------------------------------------
// 自定义提取器路由
// ---------------------------------------------------------------------------
async function extractWithCustomExtractor(source, filePath) {
    const ext = extname(filePath).toLowerCase();
    // Vue SFC
    if (ext === '.vue') {
        const result = await extractVueSFC(source, filePath);
        return { symbols: result.symbols, references: result.references, edges: result.edges };
    }
    // Svelte
    if (ext === '.svelte') {
        const result = await extractSvelte(source, filePath);
        return { symbols: result.symbols, references: result.references, edges: result.edges };
    }
    // Liquid
    if (ext === '.liquid') {
        const result = extractLiquid(source, filePath);
        return { symbols: result.symbols, references: result.references, edges: result.edges };
    }
    // MyBatis XML mapper (检测是否包含 <mapper> 标签)
    if (ext === '.xml' && source.includes('<mapper')) {
        const result = extractMybatisXml(source, filePath);
        return { symbols: result.symbols, references: result.references, edges: result.edges };
    }
    // Delphi DFM/FMX
    if (ext === '.dfm' || ext === '.fmx') {
        const result = extractDfm(source, filePath);
        return { symbols: result.symbols, references: result.references, edges: result.edges };
    }
    return null;
}
// ---------------------------------------------------------------------------
// 辅助函数
// ---------------------------------------------------------------------------
function buildResultFromCustomExtractor(symbols, references, rawEdges, file, relPath) {
    const now = Date.now();
    const nodes = symbols.map(s => symbolToNode(s, now));
    const edges = rawEdges.map(e => ({
        source: e.source,
        target: e.target,
        kind: e.kind,
        provenance: 'tree-sitter',
    }));
    // 自定义提取器 (vue/svelte/liquid) 也必须建 file 节点 —
    // 否则引用锚点 (makeFileNodeId) 无对应节点, unresolved_refs FK 插入失败,
    // 所有 calls/imports 引用被逐文件静默丢弃 (曾致 vue/svelte script 内引用全丢)
    nodes.push(createFileNode(file));
    return { nodes, edges };
}
function buildResultFromTreeSitter(extracted, file) {
    const now = Date.now();
    const nodes = extracted.symbols.map(s => {
        const node = symbolToNode(s, now);
        const pSym = s;
        if (pSym.pluginMetadata) {
            node.metadata = { ...node.metadata, plugin: pSym.pluginMetadata };
        }
        return node;
    });
    // 统一引用锚点 — 旧格式 fromSymbolId (\`\${filePath}:<module>\` / \`\${filePath}:\${parent}\`) 不是合法节点 ID,
    // unresolved_refs 有 FK → nodes, 非 code: 前缀的锚点全部改为 file 节点 ID (code:...:<file>)
    const fileNodeId = makeFileNodeId(file.path);
    const normalizedRefs = normalizeReferenceAnchors(extracted.references ?? [], file.path);
    const edges = [];
    for (const e of extracted.edges) {
        if (e.source.startsWith('code:')) {
            edges.push({
                source: e.source,
                target: e.target,
                kind: e.kind,
                line: e.line,
                column: e.col,
                provenance: 'tree-sitter',
            });
        }
        else if (e.kind === 'contains') {
            // 裸名 contains (父级符号未用节点 ID) → 转当前文件节点 ID
            edges.push({
                source: makeCodeNodeId(file.path, e.source),
                target: makeCodeNodeId(file.path, e.target),
                kind: 'contains',
                line: e.line,
                provenance: 'tree-sitter',
            });
        }
        else if (e.kind === 'extends' || e.kind === 'implements') {
            // java/rust/cpp 继承边端点用裸名 (跨文件无法本地解析) → 转 extends/implements 引用,
            // 由 code-resolution 阶段按名匹配库内符号 (匹配不到则自然过滤)
            normalizedRefs.push({
                fromSymbolName: '<file>',
                fromSymbolId: fileNodeId,
                referenceName: e.target,
                referenceKind: e.kind,
                line: e.line ?? 0,
                col: e.col ?? 0,
                filePath: file.path,
                language: file.language,
            });
        }
    }
    // 为每个文件创建 file 节点 — 作为 imports 边的锚点与 contains 层级根
    // (id 用绝对路径 makeFileNodeId(file.path), 与符号节点 filePath 命名空间一致)
    const fileNode = createFileNode(file);
    nodes.push(fileNode);
    // file → 顶层符号 contains 边
    for (const s of extracted.symbols) {
        if (!s.qualifiedName.includes('.')) {
            edges.push({
                source: fileNodeId,
                target: makeCodeNodeId(s.filePath, s.qualifiedName),
                kind: 'contains',
                line: s.startLine,
                provenance: 'tree-sitter',
            });
        }
    }
    // 通用 contains 边 — 按 qualifiedName 层级推导 (覆盖所有语言),
    // 与提取器手动产出的 contains 边去重 (保留先出现的带 line 版本)
    const containsByKey = new Map();
    for (const e of edges) {
        if (e.kind === 'contains')
            containsByKey.set(`${e.source}\u0000${e.target}`, e);
    }
    for (const s of extracted.symbols) {
        const parts = s.qualifiedName.split('.');
        for (let i = 1; i < parts.length; i++) {
            const parent = parts.slice(0, i).join('.');
            const child = parts.slice(0, i + 1).join('.');
            const src = makeCodeNodeId(s.filePath, parent);
            const tgt = makeCodeNodeId(s.filePath, child);
            const key = `${src}\u0000${tgt}`;
            if (!containsByKey.has(key)) {
                const e = { source: src, target: tgt, kind: 'contains', provenance: 'tree-sitter' };
                containsByKey.set(key, e);
                edges.push(e);
            }
        }
    }
    if (isGeneratedFile(file.path)) {
        for (const node of nodes) {
            node.metadata = { ...node.metadata, generated: true };
        }
    }
    return { nodes, edges, normalizedRefs };
}
// 统一引用锚点 — 所有语言提取器的 fromSymbolId 若非合法节点 ID (code: 前缀)
// 一律改写为 file 节点 ID, 保证 unresolved_refs FK 与 code-resolution JOIN 可用
function normalizeReferenceAnchors(refs, filePath) {
    const fileNodeId = makeFileNodeId(filePath);
    return (refs ?? []).map(ref => ({
        ...ref,
        fromSymbolId: ref.fromSymbolId.startsWith('code:') ? ref.fromSymbolId : fileNodeId,
    }));
}
// 创建 file 节点 (与符号节点共享 code: 命名空间, id = code:<abs-path>:<file>)
function createFileNode(file) {
    return {
        id: makeFileNodeId(file.path),
        kind: 'file',
        name: file.path.split(/[\\/]/).pop() ?? file.path,
        qualifiedName: file.path.replace(/\\/g, '/'),
        filePath: file.path,
        language: file.language,
        startLine: 1,
        endLine: 0,
        startColumn: 1,
        endColumn: 1,
        docstring: '',
        signature: '',
        visibility: '',
        isExported: false,
        isAsync: false,
        isStatic: false,
        isAbstract: false,
        decorators: [],
        typeParameters: [],
        sourceType: 'codegraph',
        definition: '',
        aliases: [],
        keywords: [],
        category: '',
        roles: [],
        priority: '',
        status: 'active',
        body: '',
        metadata: {},
        updatedAt: Date.now(),
    };
}
function createFileLevelNode(file, relPath) {
    // id 用绝对路径命名空间 (与符号节点 filePath 一致), 保证 imports/contains 边可 JOIN
    return {
        id: makeFileNodeId(file.path),
        kind: 'file',
        name: relPath.split('/').pop() ?? relPath,
        qualifiedName: relPath,
        filePath: file.path,
        language: file.language,
        startLine: 1,
        endLine: 0,
        startColumn: 1,
        endColumn: 1,
        docstring: '',
        signature: '',
        visibility: '',
        isExported: false,
        isAsync: false,
        isStatic: false,
        isAbstract: false,
        decorators: [],
        typeParameters: [],
        sourceType: 'codegraph',
        definition: '',
        aliases: [],
        keywords: [],
        category: '',
        roles: [],
        priority: '',
        status: 'active',
        body: '',
        metadata: {},
        updatedAt: Date.now(),
    };
}
function createFileRecord(file, nodeCount) {
    return {
        path: file.path,
        contentHash: file.contentHash,
        language: file.language,
        size: file.size,
        modifiedAt: file.modifiedAt,
        indexedAt: Date.now(),
        nodeCount,
        errors: [],
        sourceType: 'codegraph',
    };
}
//# sourceMappingURL=code-extractor.js.map