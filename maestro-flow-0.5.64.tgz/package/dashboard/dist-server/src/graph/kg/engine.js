// src/graph/kg/engine.ts — MaestroGraph 主入口类
// 参考: plan-maestrograph.md Gap C8 — CodeGraph Public Lifecycle API
import { existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { KgDatabaseConnection, KgQueryBuilder, getKgDatabasePath, applyMigrations } from './db/index.js';
import { resolveKnowledgeEdges as resolveKnowledgeEdgesImpl } from './resolution/knowledge-resolver.js';
import { bfs, dfs as dfsImpl, getCallers as getCallersImpl, getCallees as getCalleesImpl, getImpactRadius, getCallGraph as getCallGraphImpl, getTypeHierarchy as getTypeHierarchyImpl, findUsages as findUsagesImpl, getAncestors as getAncestorsImpl, getChildren as getChildrenImpl, getNodeContext as getNodeContextImpl, getFileDependencies as getFileDependenciesImpl, getFileDependents as getFileDependentsImpl, findDeadCode as findDeadCodeImpl, getNodeMetrics as getNodeMetricsImpl, findShortestPath as findShortestPathImpl, } from './query/traversal.js';
import { searchUnified as searchUnifiedImpl, mergeCodeSearchResults } from './query/search.js';
import { buildCodeEmbeddingIndex, saveCodeEmbeddingIndex } from './embedding/index.js';
import { buildContext as buildContextImpl } from './query/context-builder.js';
export class MaestroGraph {
    conn = null;
    queries = null;
    projectRoot;
    _codeEmbeddingCache = null;
    constructor(projectRoot) {
        this.projectRoot = resolve(projectRoot);
    }
    // ── Lifecycle ──────────────────────────────────────────────────────
    static async init(projectRoot) {
        const mg = new MaestroGraph(projectRoot);
        const dbPath = getKgDatabasePath(projectRoot);
        mg.conn = new KgDatabaseConnection();
        mg.conn.initialize(dbPath);
        applyMigrations(mg.conn);
        mg.queries = new KgQueryBuilder(mg.conn);
        return mg;
    }
    static async open(projectRoot) {
        const mg = new MaestroGraph(projectRoot);
        const dbPath = getKgDatabasePath(projectRoot);
        if (!existsSync(dbPath)) {
            throw new Error(`MaestroGraph not initialized. Run "maestro kg init" first. Expected: ${dbPath}`);
        }
        mg.conn = new KgDatabaseConnection();
        mg.conn.open(dbPath);
        applyMigrations(mg.conn);
        mg.queries = new KgQueryBuilder(mg.conn);
        return mg;
    }
    /**
     * 以隔离只读方式打开现有 canonical MaestroGraph 数据库。
     * 此路径显式跳过 migration、sync 与 embedding lifecycle。
     */
    static async openReadOnly(projectRoot) {
        const mg = new MaestroGraph(projectRoot);
        const dbPath = getKgDatabasePath(projectRoot);
        if (!existsSync(dbPath)) {
            throw new Error(`MaestroGraph not initialized. Expected: ${dbPath}`);
        }
        mg.conn = new KgDatabaseConnection();
        mg.conn.openReadOnly(dbPath);
        mg.queries = new KgQueryBuilder(mg.conn);
        return mg;
    }
    static isInitialized(projectRoot) {
        return existsSync(getKgDatabasePath(projectRoot));
    }
    static openSync(projectRoot) {
        try {
            const dbPath = getKgDatabasePath(resolve(projectRoot));
            if (!existsSync(dbPath))
                return null;
            const mg = new MaestroGraph(projectRoot);
            mg.conn = new KgDatabaseConnection();
            mg.conn.open(dbPath);
            try {
                applyMigrations(mg.conn);
            }
            catch { /* best-effort */ }
            mg.queries = new KgQueryBuilder(mg.conn);
            return mg;
        }
        catch {
            return null;
        }
    }
    get rawDb() {
        if (!this.conn)
            throw new Error('MaestroGraph not open');
        return this.conn.raw;
    }
    close() {
        this.conn?.close();
        this.conn = null;
        this.queries = null;
        this._codeEmbeddingCache = null;
    }
    // ── Indexing ──────────────────────────────────────────────────────
    async indexAll(options) {
        const { syncKnowledgeGraph } = await import('./extraction/orchestrator.js');
        return syncKnowledgeGraph(this.projectRoot, { sources: options?.sources, graph: this });
    }
    async indexKnowledge(options) {
        const knowledgeSources = options?.sources
            ?? ['domain', 'spec', 'knowhow', 'codebase', 'issue'];
        const { syncKnowledgeGraph } = await import('./extraction/orchestrator.js');
        return syncKnowledgeGraph(this.projectRoot, { sources: knowledgeSources, graph: this });
    }
    async sync() {
        const { syncKnowledgeGraph } = await import('./extraction/orchestrator.js');
        return syncKnowledgeGraph(this.projectRoot, { graph: this });
    }
    resolveReferences() {
        if (!this.conn)
            throw new Error('MaestroGraph not open');
        const result = this.resolveKnowledgeEdges();
        return {
            edgesCreated: result.totalEdgesCreated,
            edges: result.edges,
            durationMs: result.durationMs,
        };
    }
    resolveKnowledgeEdges() {
        if (!this.conn)
            throw new Error('MaestroGraph not open');
        return resolveKnowledgeEdgesImpl(this.conn.raw, { projectPath: this.projectRoot });
    }
    // ── Query ─────────────────────────────────────────────────────────
    searchUnified(query, options) {
        if (!this.queries)
            throw new Error('MaestroGraph not open');
        return searchUnifiedImpl(this.queries, query, {
            sourceTypes: options?.sourceTypes,
            kinds: options?.kinds,
            limit: options?.limit ?? 20,
            includeCode: options?.includeCode,
            includeKnowledge: options?.includeKnowledge,
        });
    }
    searchCode(query, options) {
        if (!this.queries)
            throw new Error('MaestroGraph not open');
        return this.queries.searchCodeFTS(query, {
            kinds: options?.kinds,
            languages: options?.languages,
            limit: options?.limit ?? 20,
        });
    }
    searchKnowledge(query, options) {
        if (!this.queries)
            throw new Error('MaestroGraph not open');
        return this.queries.searchKnowledgeFTS(query, {
            sourceTypes: options?.sourceTypes,
            limit: options?.limit ?? 20,
        });
    }
    // ── Code Embedding ────────────────────────────────────────────────
    _getCodeEmbeddingDir() {
        return resolve(this.projectRoot, '.workflow', 'kg');
    }
    /**
     * Build (or incrementally rebuild) the code embedding index from all codegraph nodes.
     * Persists the index to .workflow/kg/code-embedding-index.bin and caches in memory.
     */
    async buildCodeEmbeddings() {
        if (!this.queries)
            throw new Error('MaestroGraph not open');
        // Get all code nodes from the DB (only codegraph nodes are embeddable)
        const allCodeNodes = this.queries.getNodesBySourceType('codegraph');
        // Build index (incremental if cache exists)
        const index = await buildCodeEmbeddingIndex(allCodeNodes, this._codeEmbeddingCache);
        // Persist to disk
        const dir = this._getCodeEmbeddingDir();
        saveCodeEmbeddingIndex(index, dir);
        // Cache in memory
        this._codeEmbeddingCache = index;
        return index;
    }
    /**
     * Load the code embedding index from disk or return the in-memory cache.
     * Returns null if no persisted index exists.
     */
    async getCodeEmbeddingIndex() {
        if (this._codeEmbeddingCache)
            return this._codeEmbeddingCache;
        try {
            const { loadCodeEmbeddingIndex } = await import('./embedding/index.js');
            const dir = this._getCodeEmbeddingDir();
            const index = loadCodeEmbeddingIndex(dir);
            if (index) {
                const { getModelId } = await import('#maestro-dashboard/wiki/embedding.js');
                if (index.modelId !== getModelId())
                    return null;
                this._codeEmbeddingCache = index;
            }
            return index;
        }
        catch {
            return null;
        }
    }
    async searchHybrid(query, options) {
        if (!this.queries)
            throw new Error('MaestroGraph not open');
        const limit = options?.limit ?? 20;
        const vecPromise = this._getVectorResults(query, limit * 2);
        const ftsOutput = searchUnifiedImpl(this.queries, query, {
            limit: limit * 2,
            sourceTypes: options?.sourceTypes,
        });
        const vecResults = await vecPromise;
        if (!vecResults || vecResults.length === 0) {
            return ftsOutput.directMatches.slice(0, limit);
        }
        return mergeCodeSearchResults(ftsOutput.directMatches, vecResults, this.queries, limit);
    }
    async _getVectorResults(query, limit) {
        const embIdx = await this.getCodeEmbeddingIndex();
        if (!embIdx || embIdx.nodeIds.length === 0)
            return null;
        const { embedQuery } = await import('#maestro-dashboard/wiki/embedding.js');
        const queryVec = await embedQuery(query);
        if (!queryVec)
            return null;
        const { searchCodeVectors } = await import('./embedding/index.js');
        return searchCodeVectors(queryVec, embIdx, limit);
    }
    getNode(id) {
        if (!this.queries)
            throw new Error('MaestroGraph not open');
        return this.queries.getNode(id);
    }
    getStats() {
        if (!this.queries || !this.conn)
            throw new Error('MaestroGraph not open');
        return this.queries.getStats(this.conn.getSize());
    }
    getDetectedFrameworks() {
        return this.getStats().detectedFrameworks;
    }
    // ── Traversal (C8 API) ────────────────────────────────────────────
    getCallers(nodeId, depth = 1) {
        if (!this.queries)
            throw new Error('MaestroGraph not open');
        return getCallersImpl(this.queries, nodeId, depth);
    }
    getCallees(nodeId, depth = 1) {
        if (!this.queries)
            throw new Error('MaestroGraph not open');
        return getCalleesImpl(this.queries, nodeId, depth);
    }
    getImpact(nodeId, depth = 3) {
        if (!this.queries)
            throw new Error('MaestroGraph not open');
        return getImpactRadius(this.queries, nodeId, depth);
    }
    traverse(startId, options) {
        if (!this.queries)
            throw new Error('MaestroGraph not open');
        return bfs(this.queries, startId, options);
    }
    traverseDFS(startId, options) {
        if (!this.queries)
            throw new Error('MaestroGraph not open');
        return dfsImpl(this.queries, startId, options);
    }
    getTypeHierarchy(nodeId) {
        if (!this.queries)
            throw new Error('MaestroGraph not open');
        return getTypeHierarchyImpl(this.queries, nodeId);
    }
    findUsages(nodeId) {
        if (!this.queries)
            throw new Error('MaestroGraph not open');
        return findUsagesImpl(this.queries, nodeId);
    }
    getAncestors(nodeId) {
        if (!this.queries)
            throw new Error('MaestroGraph not open');
        return getAncestorsImpl(this.queries, nodeId);
    }
    getChildren(nodeId) {
        if (!this.queries)
            throw new Error('MaestroGraph not open');
        return getChildrenImpl(this.queries, nodeId);
    }
    getCallGraph(nodeId, depth) {
        if (!this.queries)
            throw new Error('MaestroGraph not open');
        return getCallGraphImpl(this.queries, nodeId, depth);
    }
    getNodeContext(nodeId) {
        if (!this.queries)
            throw new Error('MaestroGraph not open');
        return getNodeContextImpl(this.queries, nodeId);
    }
    getFileDependencies(filePath) {
        if (!this.queries)
            throw new Error('MaestroGraph not open');
        return getFileDependenciesImpl(this.queries, filePath);
    }
    getFileDependents(filePath) {
        if (!this.queries)
            throw new Error('MaestroGraph not open');
        return getFileDependentsImpl(this.queries, filePath);
    }
    findDeadCode(options) {
        if (!this.queries)
            throw new Error('MaestroGraph not open');
        return findDeadCodeImpl(this.queries, options);
    }
    getNodeMetrics(nodeId) {
        if (!this.queries)
            throw new Error('MaestroGraph not open');
        return getNodeMetricsImpl(this.queries, nodeId);
    }
    findShortestPath(fromId, toId, maxDepth) {
        if (!this.queries)
            throw new Error('MaestroGraph not open');
        return findShortestPathImpl(this.queries, fromId, toId, maxDepth);
    }
    // ── Context (C8 API) ──────────────────────────────────────────────
    buildContext(query, options) {
        if (!this.queries)
            throw new Error('MaestroGraph not open');
        return buildContextImpl(this.queries, query, options);
    }
    // ── Internal Access (供 CLI/MCP 消费) ──────────────────────────────
    getQueryBuilder() {
        if (!this.queries)
            throw new Error('MaestroGraph not open');
        return this.queries;
    }
    getConnection() {
        if (!this.conn)
            throw new Error('MaestroGraph not open');
        return this.conn;
    }
    // ── Insertion (供 extractor 使用) ──────────────────────────────────
    insertExtractionResults(result) {
        if (!this.queries)
            throw new Error('MaestroGraph not open');
        this.conn.transaction(() => {
            this.queries.insertNodes(result.nodes);
            this.queries.insertEdges(result.edges);
            this.queries.upsertFile(result.fileRecord);
        });
    }
}
//# sourceMappingURL=engine.js.map