/**
 * KG Sync State — persistent freshness watermark for codegraph sync.
 *
 * Records the git HEAD at the last successful codegraph sync in
 * .workflow/kg/sync-state.json so change detection can catch committed
 * changes (commit / pull / branch switch) that leave the working tree clean.
 */
import { execSync } from 'node:child_process';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
function syncStatePath(projectPath) {
    return resolve(projectPath, '.workflow', 'kg', 'sync-state.json');
}
export function readSyncState(projectPath) {
    try {
        const data = JSON.parse(readFileSync(syncStatePath(projectPath), 'utf-8'));
        return typeof data.lastSyncAt === 'number' ? data : null;
    }
    catch {
        return null;
    }
}
export function writeSyncState(projectPath, head) {
    try {
        const path = syncStatePath(projectPath);
        mkdirSync(dirname(path), { recursive: true });
        const data = { lastSyncHead: head, lastSyncAt: Date.now() };
        writeFileSync(path, JSON.stringify(data), 'utf-8');
    }
    catch {
        // Best-effort — freshness falls back to dirty-file detection.
    }
}
export function getGitHead(projectPath) {
    try {
        const head = execSync('git rev-parse HEAD', {
            cwd: projectPath,
            encoding: 'utf-8',
            timeout: 5000,
            stdio: ['pipe', 'pipe', 'pipe'],
        }).trim();
        return head || null;
    }
    catch {
        return null;
    }
}
//# sourceMappingURL=sync-state.js.map