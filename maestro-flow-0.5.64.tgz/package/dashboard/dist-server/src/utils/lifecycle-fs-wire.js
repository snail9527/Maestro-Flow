export const LIFECYCLE_FS_HELPER_PROTOCOL = 'lifecycle-fs-helper/1.0';
export const LIFECYCLE_FS_GENERATION_SCHEMA = 'lifecycle-fs-generation/1.0';
//# sourceMappingURL=lifecycle-fs-wire.js.map