// src/utils/cooldown-guard.ts — Cross-process cooldown via tmpdir bridge files
//
// Shared abstraction for time-based throttling across subprocess invocations.
// Each guard writes a JSON bridge file in tmpdir; subsequent calls within the
// cooldown window are skipped.
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
export class CooldownGuard {
    prefix;
    cooldownMs;
    constructor(opts) {
        this.prefix = opts.prefix;
        this.cooldownMs = opts.cooldownMs;
    }
    shouldRun(sessionId) {
        const bridge = this.read(sessionId);
        if (!bridge)
            return true;
        return (Date.now() - bridge.last_trigger) >= this.cooldownMs;
    }
    markDone(sessionId, extra) {
        const data = {
            last_trigger: Date.now(),
            session_id: sessionId,
            extra,
        };
        try {
            writeFileSync(this.path(sessionId), JSON.stringify(data), 'utf-8');
        }
        catch {
            // Best-effort
        }
    }
    timeSinceLastMs(sessionId) {
        const bridge = this.read(sessionId);
        if (!bridge)
            return null;
        return Date.now() - bridge.last_trigger;
    }
    read(sessionId) {
        const p = this.path(sessionId);
        if (!existsSync(p))
            return null;
        try {
            return JSON.parse(readFileSync(p, 'utf-8'));
        }
        catch {
            return null;
        }
    }
    path(sessionId) {
        return join(tmpdir(), `${this.prefix}${sessionId}.json`);
    }
}
// Pre-configured guards for common use cases
export const kgSyncGuard = new CooldownGuard({ prefix: 'maestro-kg-sync-', cooldownMs: 30_000 });
export const kgInitGuard = new CooldownGuard({ prefix: 'maestro-kg-init-', cooldownMs: 300_000 });
//# sourceMappingURL=cooldown-guard.js.map