// ---------------------------------------------------------------------------
// Collab Types — shared between server and client for human collaboration
// ---------------------------------------------------------------------------
export const COLLAB_STATUS_COLORS = {
    online: '#22c55e',
    offline: '#9ca3af',
    away: '#eab308',
};
/** Color per activity action type — shared across components */
export const COLLAB_ACTION_COLORS = {
    join: '#22c55e',
    phase_change: '#a78bfa',
    task_update: '#34d399',
    message: '#60a5fa',
    discussion: '#60a5fa',
    report: '#f59e0b',
    sync: '#06b6d4',
};
//# sourceMappingURL=collab-types.js.map