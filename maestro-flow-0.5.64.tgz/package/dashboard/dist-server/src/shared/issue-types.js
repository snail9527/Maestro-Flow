// ---------------------------------------------------------------------------
// Issue type system -- types for the Issue tracking feature
// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// Validation helpers
// ---------------------------------------------------------------------------
export const VALID_ISSUE_TYPES = new Set([
    'bug', 'feature', 'improvement', 'task',
]);
export const VALID_ISSUE_PRIORITIES = new Set([
    'low', 'medium', 'high', 'urgent',
]);
export const VALID_ISSUE_STATUSES = new Set([
    'open', 'registered', 'in_progress', 'resolved', 'closed', 'deferred',
]);
//# sourceMappingURL=issue-types.js.map