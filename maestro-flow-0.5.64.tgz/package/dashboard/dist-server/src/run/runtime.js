import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, readdirSync, statSync, writeFileSync, } from 'node:fs';
import { basename, extname, join, relative, resolve as resolvePath, sep } from 'node:path';
import { hashDirectory, hashFile, scanOutputs } from './artifacts.js';
import { parseArgumentHint } from '../config/argument-hint-parser.js';
import { hashCommandContract, resolveCommandSource, resolveStepContent, } from './contract.js';
import { PLATFORM_SUFFIX, transformContentForPlatform, } from '../core/skill-converter.js';
import { deriveHandoff, readReportFrontmatter } from './report.js';
import { buildKnowledgeReconciliationCard, knowledgeCandidateReceipt, runKnowledgeDeltaPath, runKnowledgeDeltaSchema, stageHandoffKnowledgeCandidates, summarizeSessionKnowledge, } from './knowledge.js';
import { applyAutomaticKnowledgeSuppression, ensureKnowledgeReconciliation, isKnowledgeReconciliationFresh, ensureSessionKnowledgeReconciliation, persistSessionKnowledgeReconciliation, readKnowledgeReconciliation, reconcileRunKnowledgeSync, reconciliationForCandidate, reconciliationSummary, writeKnowledgeReconciliation, } from '../knowledge/reconcile.js';
import { gateSchema, } from './schemas.js';
import { briefResultV11Schema, commandRebindAuditSchema, completeInputSnapshotSchema, executionContractV11Schema, guidanceSnapshotSchema, } from './protocol-schemas.js';
import { createIntentIdentity } from './intent-identity.js';
import { applyChainProposal, selectChainProposal, validateChainProposalArtifacts, } from './chain-proposal.js';
import { createTopicIdentity, normalizeTopic, sameTopicIdentity } from './topic-identity.js';
import { assessArtifactReuse } from './reuse-assessment.js';
import { buildIntentSection, buildBoundaryContractSection, buildProgressSection, buildSignalsSection, } from './inject.js';
import { SessionStore } from './store.js';
import { createGateRegistry } from './defaults.js';
import { activeStepIndex, nextPendingDecisionIndex, nextPendingIndex, issueRetryToken, } from './chain.js';
import { canonicalRunDir, resolveRunContextFull, resolveTargetPlatform } from './context.js';
import { checkLease, claimLease } from './lease.js';
import { assertTransitionMutationRevisions, createTransitionOutcome, prepareTransitionMutation, stableJsonUtf8, transitionMutationReceipt, TransitionReceiptError, validatePersistedTransitionRecord, } from './transition-receipts.js';
import { validateSessionId } from './ids.js';
import { reuseAcceptanceStatus } from './continuation.js';
import { ensureSessionProjection, localISO, migrateV1toV2, readStateJson, writeStateJson, } from '../utils/state-schema.js';
const explicitGateCheckSchema = gateSchema.shape.check;
function sha256(value) {
    return createHash('sha256').update(value).digest('hex');
}
function protocolSha256(value) {
    return `sha256:${sha256(value)}`;
}
function buildGuidanceSnapshot(projectRoot, command, source) {
    const guidance = resolveStepContent(projectRoot, command);
    return guidanceSnapshotSchema.parse({
        schema_version: 'guidance-snapshot/1.0',
        source_path: source.relativePath,
        content_hash: protocolSha256(source.raw),
        resolved_prompt_hash: protocolSha256(source.raw),
        prepare_hash: guidance.prepare ? protocolSha256(guidance.prepare.raw) : null,
        workflow_hash: guidance.workflow ? protocolSha256(guidance.workflow.raw) : null,
        run_mode_hash: guidance.runMode ? protocolSha256(guidance.runMode.raw) : null,
    });
}
function guidanceFreshness(projectRoot, run) {
    const source = resolveCommandSource(projectRoot, run.command.name);
    const current = buildGuidanceSnapshot(projectRoot, run.command.name, source);
    const captured = run.guidance_snapshot ?? null;
    if (!captured)
        return { status: 'unavailable', changed: [], captured, current };
    const comparisons = [
        ['command', captured.content_hash, current.content_hash],
        ['resolved_prompt', captured.resolved_prompt_hash, current.resolved_prompt_hash],
        ['prepare', captured.prepare_hash, current.prepare_hash],
        ['workflow', captured.workflow_hash, current.workflow_hash],
        ['run_mode', captured.run_mode_hash, current.run_mode_hash],
    ];
    const changed = comparisons.filter(([, before, after]) => before !== after).map(([key]) => key);
    return { status: changed.length > 0 ? 'changed' : 'none', changed, captured, current };
}
function stableJson(value) {
    const normalize = (item) => {
        if (Array.isArray(item))
            return item.map(normalize);
        if (item && typeof item === 'object') {
            return Object.fromEntries(Object.entries(item)
                .filter(([, child]) => child !== undefined)
                .sort(([left], [right]) => left.localeCompare(right))
                .map(([key, child]) => [key, normalize(child)]));
        }
        return item;
    };
    return JSON.stringify(normalize(value));
}
function contractHash(contract) {
    return hashCommandContract(contract);
}
function dateId() {
    const now = new Date();
    return `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;
}
function slug(value, fallback) {
    const normalized = value
        .normalize('NFKD')
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-+|-+$/g, '')
        .slice(0, 64);
    return normalized || fallback;
}
function emptyProjectState(projectRoot) {
    return migrateV1toV2({ project_name: basename(projectRoot), status: 'active' });
}
function projectState(projectRoot) {
    const empty = emptyProjectState(projectRoot);
    const current = readStateJson(projectRoot);
    if (!current)
        return empty;
    return {
        ...empty,
        ...current,
        milestones: current.milestones ?? [],
        artifacts: current.artifacts ?? [],
        accumulated_context: current.accumulated_context ?? empty.accumulated_context,
        transition_history: current.transition_history ?? [],
        milestone_history: current.milestone_history ?? [],
        sessions: current.sessions ?? [],
        active_session_id: current.active_session_id ?? null,
    };
}
function projectSessionEntry(session) {
    return {
        session_id: session.session_id,
        intent: session.intent,
        status: session.status,
        depends_on: [],
        roadmap_artifact_id: null,
        seed_ref: null,
    };
}
function compatibleTopic(session, identity) {
    return session.topic_identity
        ? sameTopicIdentity(session.topic_identity, identity)
        : normalizeTopic(session.intent) === identity.normalized;
}
function uniqueTopicCandidate(label, candidates) {
    if (candidates.length > 1) {
        throw new Error(`${label} is ambiguous; pass --session: ${candidates.map(item => item.sessionId).join(', ')}`);
    }
    return candidates[0]?.sessionId ?? null;
}
function runningTopicCandidatesLocked(store, identity, currentDraft) {
    if (!existsSync(store.sessionsRoot))
        return [];
    const running = readdirSync(store.sessionsRoot).sort().flatMap(sessionId => {
        if (!store.sessionExists(sessionId))
            return [];
        try {
            const session = currentDraft?.session_id === sessionId
                ? currentDraft
                : store.readBundle(sessionId).session;
            return session.status === 'running' ? [{ sessionId, session }] : [];
        }
        catch {
            return [];
        }
    });
    const native = running.filter(item => item.session.topic_identity
        && sameTopicIdentity(item.session.topic_identity, identity));
    if (native.length > 0)
        return native;
    return running.filter(item => !item.session.topic_identity
        && normalizeTopic(item.session.intent) === identity.normalized);
}
/** Read-only command-independent topic lookup used by prepare and recall. */
export function resolveTopicSessionId(projectRoot, topic, requested) {
    const store = new SessionStore(projectRoot);
    const identity = createTopicIdentity(projectRoot, topic);
    if (requested) {
        validateSessionId(requested);
        if (!store.sessionExists(requested))
            return null;
        const session = store.readBundle(requested).session;
        if (!compatibleTopic(session, identity)) {
            throw new Error(`Explicit Session ${requested} is incompatible with topic ${JSON.stringify(topic)}`);
        }
        return requested;
    }
    const running = store.listSessions({ statuses: ['running'] }).candidates;
    const native = running.filter(item => item.session.topic_identity
        && sameTopicIdentity(item.session.topic_identity, identity));
    const nativeId = uniqueTopicCandidate('Running topic match', native);
    if (nativeId)
        return nativeId;
    const legacy = running.filter(item => !item.session.topic_identity
        && normalizeTopic(item.session.intent) === identity.normalized);
    return uniqueTopicCandidate('Legacy exact intent match', legacy);
}
function resolveSessionId(store, requested, topic, source) {
    const topicIdentity = createTopicIdentity(store.projectRoot, topic, { source });
    if (requested) {
        validateSessionId(requested);
        if (store.sessionExists(requested)) {
            const existing = store.readBundle(requested).session;
            if (!compatibleTopic(existing, topicIdentity)) {
                throw new Error(`Explicit Session ${requested} is incompatible with topic ${JSON.stringify(topic)}`);
            }
        }
        return { sessionId: requested, topicIdentity };
    }
    const matched = resolveTopicSessionId(store.projectRoot, topic);
    if (matched)
        return { sessionId: matched, topicIdentity };
    const base = `${dateId()}-${slug(topic, 'session')}`;
    if (!store.sessionExists(base))
        return { sessionId: base, topicIdentity };
    for (let index = 2; index < 1000; index++) {
        const candidate = `${base}-${String(index).padStart(2, '0')}`;
        if (!store.sessionExists(candidate))
            return { sessionId: candidate, topicIdentity };
    }
    throw new Error(`Unable to allocate session ID for topic: ${topic}`);
}
function nextSequence(store, sessionId) {
    const runsDir = join(store.sessionDir(sessionId), 'runs');
    if (!existsSync(runsDir))
        return 1;
    let max = 0;
    for (const name of readdirSync(runsDir)) {
        const match = name.match(/^\d{8}-(\d{3})-/);
        if (match)
            max = Math.max(max, Number(match[1]));
    }
    return max + 1;
}
function defaultAlias(kind, command) {
    const value = `${kind} ${command}`.toLowerCase();
    if (value.includes('analy') || value.includes('finding'))
        return 'current-analysis';
    if (value.includes('plan'))
        return 'current-plan';
    if (value.includes('execut') || value.includes('change-manifest'))
        return 'latest-execution';
    if (value.includes('verif'))
        return 'latest-verification';
    if (value.includes('review'))
        return 'latest-review';
    if (value.includes('test') || value.includes('acceptance'))
        return 'latest-test';
    if (value.includes('debug') || value.includes('diagnos'))
        return 'latest-debug';
    return undefined;
}
function observedArtifactHash(path) {
    try {
        if (!existsSync(path))
            return null;
        const stat = statSync(path);
        const hash = stat.isDirectory() ? hashDirectory(path).hash : hashFile(path).hash;
        return `sha256:${hash}`;
    }
    catch {
        return null;
    }
}
function producerContractDrift(projectRoot, run, artifact) {
    if (!run.contract_snapshot)
        return { producerHash: null, currentHash: null, drift: 'unknown' };
    const current = resolveCommandSource(projectRoot, run.command.name);
    const producerHash = run.contract_snapshot.snapshot_hash;
    const currentHash = current.contractSnapshot.snapshot_hash;
    if (producerHash === currentHash) {
        return {
            producerHash,
            currentHash,
            drift: current.contentHash === run.command.content_hash ? 'none' : 'prompt_only',
        };
    }
    const compatible = current.contract.produces.some(output => output.kind === artifact.kind
        && (!output.schema || output.schema === artifact.schema_version)
        && (!output.role || output.role === artifact.role));
    return { producerHash, currentHash, drift: compatible ? 'compatible_output' : 'breaking' };
}
/**
 * Enumerate and assess only artifacts already registered in the target Session.
 * The caller invokes this while holding the SessionStore update lock, so the
 * observed bytes and registry revision are the fence bound into the new Run.
 */
function collectReusableUpstream(projectRoot, store, session, registry, gates, contract) {
    if (contract.consumes.length === 0)
        return { upstream: {}, assessments: [] };
    const consumedKinds = new Set(contract.consumes.map(c => c.kind));
    const replacesIndex = new Map();
    for (const [id, artifact] of Object.entries(registry.artifacts)) {
        if (artifact.replaces) {
            const list = replacesIndex.get(artifact.replaces);
            if (list)
                list.push(id);
            else
                replacesIndex.set(artifact.replaces, [id]);
        }
    }
    const candidates = Object.entries(registry.artifacts)
        .filter(([, artifact]) => consumedKinds.has(artifact.kind))
        .map(([artifactId, artifact]) => {
        let producer = null;
        try {
            producer = store.readRun(session.session_id, artifact.producer_run_id);
        }
        catch { /* assessed as unavailable */ }
        const path = join(store.sessionDir(session.session_id), artifact.relative_path);
        return { artifactId, artifact, producer, observedHash: observedArtifactHash(path) };
    })
        .filter(item => item.producer !== null)
        .sort((left, right) => (right.producer?.sequence ?? 0) - (left.producer?.sequence ?? 0)
        || left.artifactId.localeCompare(right.artifactId));
    const assessments = [];
    const upstream = {};
    for (const consume of contract.consumes) {
        const aliasTargetId = consume.alias ? registry.aliases[consume.alias] : undefined;
        const matchingKind = candidates.filter(item => item.artifact.kind === consume.kind);
        const scopedCandidates = consume.alias
            ? matchingKind.filter(item => item.artifactId === aliasTargetId)
            : matchingKind;
        const assessed = scopedCandidates.map(item => {
            const producer = item.producer;
            const supersededBy = replacesIndex.get(item.artifactId) ?? [];
            const acceptedSchemas = consume.schema
                ? [consume.schema]
                : (contract.contract_version ?? 1) === 1 ? [item.artifact.schema_version] : [];
            const acceptedRoles = consume.role ? [consume.role] : [];
            const currentSameRoleCandidates = matchingKind
                .filter(peer => peer.artifact.role === item.artifact.role)
                .filter(peer => peer.artifact.status === 'sealed')
                .filter(peer => !Object.values(registry.artifacts).some(candidate => candidate.replaces === peer.artifactId))
                .filter(peer => consume.alias ? peer.artifactId === aliasTargetId : true);
            const sameRoleCandidates = currentSameRoleCandidates
                .map(peer => ({
                artifactId: peer.artifactId,
                artifactHash: peer.artifact.content_hash ? `sha256:${peer.artifact.content_hash}` : null,
                eligible: peer.producer?.status === 'sealed'
                    && peer.artifact.status === 'sealed'
                    && peer.observedHash === `sha256:${peer.artifact.content_hash}`
                    && (acceptedSchemas.length === 0 || acceptedSchemas.includes(peer.artifact.schema_version))
                    && (acceptedRoles.length === 0 || acceptedRoles.includes(peer.artifact.role)),
            }));
            const assessmentInput = {
                candidate: {
                    workspaceId: createTopicIdentity(projectRoot, session.intent, { source: 'legacy-intent' }).workspace_id,
                    sessionId: session.session_id,
                    producerRunId: producer.run_id,
                    producerRunHash: observedArtifactHash(join(store.runDir(session.session_id, producer.run_id), 'run.json')),
                    producerStatus: producer.status,
                    artifactId: item.artifactId,
                    artifactRole: item.artifact.role,
                    artifactStatus: item.artifact.status,
                    artifactHash: `sha256:${item.artifact.content_hash}`,
                    observedArtifactHash: item.observedHash,
                    artifactSchema: item.artifact.schema_version,
                    artifactRegistryRevision: registry.revision,
                },
                consumer: {
                    kind: consume.kind,
                    alias: consume.alias ?? null,
                    schema: consume.schema ?? null,
                    role: consume.role ?? null,
                },
                acceptedArtifactSchemas: acceptedSchemas,
                acceptedArtifactRoles: acceptedRoles,
                contract: producerContractDrift(projectRoot, producer, item.artifact),
                freshness: item.artifact.status === 'superseded' || supersededBy.length > 0
                    ? 'stale'
                    : consume.alias
                        ? (aliasTargetId === item.artifactId ? 'fresh' : 'unknown')
                        : currentSameRoleCandidates.length > 0 ? 'fresh' : 'unknown',
                quality: {
                    status: producer.status !== 'sealed'
                        || producer.output.verdict === 'blocked'
                        || producer.output.verdict === 'failed'
                        || producer.handoff?.verdict === 'blocked'
                        || producer.handoff?.verdict === 'failed'
                        || producer.gate_ids.some(id => {
                            const status = gates.gates[id]?.status;
                            return status !== undefined && !['passed', 'waived', 'skipped'].includes(status);
                        })
                        ? 'low'
                        : (producer.handoff?.concerns.length ?? 0) > 0
                            || producer.handoff?.verdict === 'ready_with_concerns'
                            || producer.output.verdict === 'ready_with_concerns'
                            ? 'medium'
                            : producer.handoff?.verdict === 'ready' && producer.output.verdict === 'ready'
                                ? 'high'
                                : 'unknown',
                    concernCodes: producer.handoff?.concerns ?? [],
                },
                supersession: {
                    status: item.artifact.status === 'superseded' || supersededBy.length > 0 ? 'superseded' : 'current',
                    supersedesArtifactIds: item.artifact.replaces ? [item.artifact.replaces] : [],
                    supersededByArtifactIds: supersededBy,
                },
                conflicts: { sameRoleCandidates },
            };
            let assessment = assessArtifactReuse(assessmentInput);
            const finalArtifactHash = observedArtifactHash(join(store.sessionDir(session.session_id), item.artifact.relative_path));
            const finalRunHash = observedArtifactHash(join(store.runDir(session.session_id, producer.run_id), 'run.json'));
            if (finalArtifactHash !== assessment.source_fence.observed_artifact_hash
                || finalRunHash !== assessment.source_fence.producer_run_hash) {
                const producerFenceStable = finalRunHash === assessment.source_fence.producer_run_hash;
                assessment = assessArtifactReuse({
                    ...assessmentInput,
                    candidate: {
                        ...assessmentInput.candidate,
                        observedArtifactHash: finalArtifactHash,
                        producerRunHash: producerFenceStable ? finalRunHash : null,
                    },
                });
            }
            assessments.push(assessment);
            return { item, assessment };
        });
        const selected = assessed.find(item => item.assessment.decision === 'REUSE');
        if (!selected)
            continue;
        const alias = consume.alias
            ?? Object.entries(registry.aliases).find(([, id]) => id === selected.item.artifactId)?.[0]
            ?? selected.item.artifactId;
        upstream[alias] = {
            artifact_id: selected.item.artifactId,
            path: `sessions/${session.session_id}/${selected.item.artifact.relative_path}`,
            kind: selected.item.artifact.kind,
            status: 'sealed',
        };
    }
    return { upstream, assessments };
}
export function assessSessionReuse(projectRoot, sessionId, command) {
    const store = new SessionStore(projectRoot);
    return store.withLock(() => {
        const bundle = store.readBundle(sessionId);
        return collectReusableUpstream(projectRoot, store, bundle.session, bundle.artifacts, bundle.gates, resolveCommandSource(projectRoot, command).contract);
    });
}
function revalidateRunReuse(projectRoot, store, bundle, run, contract) {
    const stored = (run.input.reuse_assessments ?? []);
    if (stored.length === 0) {
        return {
            upstream: {},
            assessments: [],
            blockers: run.input.consumes.length > 0 ? ['consumed artifacts have no reusable source fence'] : [],
        };
    }
    const current = collectReusableUpstream(projectRoot, store, bundle.session, bundle.artifacts, bundle.gates, contract ?? contractForRun(projectRoot, run).contract);
    const upstream = {};
    const assessments = [];
    const blockers = [];
    for (const original of stored) {
        const refreshed = current.assessments.find(item => item.source_fence.artifact_id === original.source_fence.artifact_id
            && item.consumer.kind === original.consumer.kind
            && item.consumer.alias === original.consumer.alias);
        const aliasCurrent = original.consumer.alias === null
            || bundle.artifacts.aliases[original.consumer.alias] === original.source_fence.artifact_id;
        const sourceFenceCurrent = refreshed !== undefined
            && refreshed.source_fence.artifact_registry_revision === original.source_fence.artifact_registry_revision
            && refreshed.source_fence.artifact_hash === original.source_fence.artifact_hash
            && refreshed.source_fence.observed_artifact_hash === original.source_fence.observed_artifact_hash
            && refreshed.source_fence.producer_run_hash === original.source_fence.producer_run_hash
            && aliasCurrent;
        const originalReuseCurrent = original.decision === 'REUSE'
            && refreshed?.decision === 'REUSE'
            && sourceFenceCurrent;
        const acceptedReviewCurrent = original.decision === 'REVIEW'
            && refreshed?.decision === 'REVIEW'
            && refreshed.assessment_hash === original.assessment_hash
            && stableJsonUtf8(refreshed.source_fence) === stableJsonUtf8(original.source_fence)
            && sourceFenceCurrent
            && reuseAcceptanceStatus(bundle.session, run, original) === 'accepted';
        if (!originalReuseCurrent && !acceptedReviewCurrent) {
            const assessment = refreshed
                ? {
                    ...refreshed,
                    decision: refreshed.decision === 'REUSE' ? 'REVIEW' : refreshed.decision,
                    reason_codes: refreshed.decision === 'REUSE'
                        ? [...new Set([...refreshed.reason_codes, 'FRESHNESS_UNKNOWN'])]
                        : refreshed.reason_codes,
                }
                : { ...original, decision: 'REJECT', reason_codes: [...new Set([...original.reason_codes, 'ARTIFACT_INVALID'])] };
            assessments.push(assessment);
            if (run.input.consumes.includes(original.source_fence.artifact_id)) {
                blockers.push(`artifact ${original.source_fence.artifact_id} reuse fence is no longer current or accepted`);
            }
            continue;
        }
        assessments.push(refreshed);
        if (!run.input.consumes.includes(original.source_fence.artifact_id)) {
            blockers.push(`artifact ${original.source_fence.artifact_id} is not bound in run.input.consumes`);
            continue;
        }
        const alias = original.consumer.alias ?? original.source_fence.artifact_id;
        const artifact = bundle.artifacts.artifacts[original.source_fence.artifact_id];
        upstream[alias] = {
            artifact_id: original.source_fence.artifact_id,
            path: `sessions/${bundle.session.session_id}/${artifact.relative_path}`,
            kind: artifact.kind,
            status: 'sealed',
        };
    }
    return { upstream, assessments, blockers };
}
/**
 * Explicitly accept one REVIEW assessment. The receipt binds the exact
 * assessment hash and source fence; run.input.consumes is updated in the same
 * authority transaction, so an Artifact Registry candidate alone never opens
 * the required consume gate.
 */
export function acceptRunReuse(projectRoot, runId, assessmentHash, sessionId, options) {
    const actor = options.actor.trim();
    const reason = options.reason.trim();
    const evidence = options.evidence.map(item => item.trim()).filter(Boolean);
    if (!actor)
        throw new Error('reuse acceptance requires a non-empty actor');
    if (!reason)
        throw new Error('reuse acceptance requires a non-empty reason');
    if (evidence.length === 0)
        throw new Error('reuse acceptance requires at least one evidence reference');
    const store = new SessionStore(projectRoot);
    const located = store.findRun(runId, sessionId);
    const initialBundle = store.readBundle(located.sessionId);
    const initialRun = located.run;
    const assessment = initialRun.input.reuse_assessments
        .find(item => item.assessment_hash === assessmentHash);
    if (!assessment)
        throw new Error(`reuse assessment not found: ${assessmentHash}`);
    if (assessment.decision !== 'REVIEW') {
        throw new Error(`reuse assessment ${assessmentHash} is ${assessment.decision}, expected REVIEW`);
    }
    const resolvedContract = contractForRun(projectRoot, initialRun).contract;
    const prepared = prepareTransitionMutation({
        session: initialBundle.session,
        currentFence: store.readSessionFence(located.sessionId, runId),
        operation: 'accept-reuse',
        subject: { session_id: located.sessionId, run_id: runId, chain_step_id: initialRun.chain_step_id },
        payload: {
            run_id: runId,
            assessment_hash: assessment.assessment_hash,
            artifact_id: assessment.source_fence.artifact_id,
            source_fence: assessment.source_fence,
            actor,
            reason,
            evidence,
        },
        options,
    });
    const evaluated = store.replayOrApplyTransition(located.sessionId, prepared.request, (draft, tx) => {
        assertTransitionMutationRevisions(draft.session, prepared.options);
        const leaseConflict = checkLease(draft.session.orchestration.lease, prepared.options.leaseClaim ?? {});
        if (leaseConflict)
            throw new Error(leaseConflict);
        const run = tx.readRun(runId);
        if (run.status === 'sealed' || run.status === 'completed') {
            throw new Error(`Run ${runId} is ${run.status} and immutable`);
        }
        const stored = run.input.reuse_assessments
            .find(item => item.assessment_hash === assessment.assessment_hash);
        const current = collectReusableUpstream(projectRoot, store, draft.session, draft.artifacts, draft.gates, resolvedContract).assessments.find(item => item.assessment_hash === assessment.assessment_hash);
        if (!stored || stored.decision !== 'REVIEW'
            || !current || current.decision !== 'REVIEW'
            || stableJsonUtf8(stored.source_fence) !== stableJsonUtf8(assessment.source_fence)
            || stableJsonUtf8(current.source_fence) !== stableJsonUtf8(assessment.source_fence)) {
            throw new TransitionReceiptError('FENCE_CONFLICT', `reuse assessment ${assessment.assessment_hash} no longer matches its REVIEW source fence`);
        }
        if (!run.input.consumes.includes(assessment.source_fence.artifact_id)) {
            run.input.consumes.push(assessment.source_fence.artifact_id);
        }
        const context = {
            projectRoot,
            runDir: store.runDir(located.sessionId, runId),
            session: draft.session,
            registry: draft.artifacts,
            scan: { artifacts: [], warnings: [], errors: [] },
            evidence: draft.evidence,
            run,
        };
        for (const gateId of run.gate_ids) {
            const gate = draft.gates.gates[gateId];
            if (gate?.scope === 'entry')
                gate.status = evaluateGate(gate, context);
        }
        summarizeRegistry(draft.gates);
        const entryGates = gateSummary(draft.gates, run.gate_ids.filter(gateId => draft.gates.gates[gateId]?.scope === 'entry'));
        if (run.status === 'blocked' && entryGates.blocking.length === 0)
            run.status = 'running';
        draft.session.activity_revision++;
        tx.writeRun(run);
        const acceptance = {
            run_id: runId,
            assessment_hash: assessment.assessment_hash,
            artifact_id: assessment.source_fence.artifact_id,
            source_fence: assessment.source_fence,
            actor,
            reason,
            evidence,
        };
        const result = {
            session_id: located.sessionId,
            run_id: runId,
            artifact_id: assessment.source_fence.artifact_id,
            assessment_hash: assessment.assessment_hash,
            run_status: run.status,
            consumes: [...run.input.consumes],
            entry_gates: entryGates,
        };
        return createTransitionOutcome({
            request_id: prepared.request.request_id,
            request_hash: prepared.request.normalized_request_hash,
            operation: 'accept-reuse', status: 'applied', applied_at: new Date().toISOString(),
            subject: prepared.request.subject,
            postconditions: {
                session_identity_revision: draft.session.identity_revision,
                session_activity_revision: draft.session.activity_revision,
                active_run_id: draft.session.active_run_id,
                run_hash: protocolSha256(`${JSON.stringify(run, null, 2)}\n`),
                artifact_registry_revision: draft.artifacts.revision,
            },
            exit_code: 0, error_code: null, result: { acceptance, value: result },
        });
    });
    return {
        ...structuredClone(evaluated.outcome.result.value),
        transition: transitionMutationReceipt(prepared.request, evaluated.outcome, evaluated.replayed),
    };
}
function argumentHint(raw) {
    const match = raw.match(/^---\s*\r?\n[\s\S]*?^argument-hint:\s*(["']?)(.*?)\1\s*$[\s\S]*?^---\s*$/m);
    return match?.[2]?.trim() ?? '';
}
function argumentDefinitions(source) {
    if (source.contract.contract_version === 2.1 && source.contract.arguments.length > 0) {
        return source.contract.arguments.map(item => ({ ...item, positional: !item.name.startsWith('-') }));
    }
    return parseArgumentHint(argumentHint(source.raw));
}
export function resolveArgumentRequirements(projectRoot, command, args) {
    const source = resolveCommandSource(projectRoot, command);
    const definitions = argumentDefinitions(source);
    const strictDefaults = new Map(source.contract.arguments.map(item => [item.name, item.default]));
    const actual = new Map();
    const positionals = [];
    const byName = new Map(definitions.map(item => [item.name, item]));
    for (let index = 0; index < args.length; index++) {
        const value = args[index];
        if (!value.startsWith('-')) {
            positionals.push(value);
            continue;
        }
        const equals = value.indexOf('=');
        const name = equals === -1 ? value : value.slice(0, equals);
        const definition = byName.get(name);
        if (!definition) {
            if (equals === -1 && index + 1 < args.length && !args[index + 1].startsWith('-'))
                index++;
            continue;
        }
        if (definition.type === 'boolean') {
            actual.set(name, true);
        }
        else if (equals !== -1) {
            actual.set(name, value.slice(equals + 1));
        }
        else if (index + 1 < args.length && !args[index + 1].startsWith('-')) {
            actual.set(name, args[++index]);
        }
    }
    let positionalIndex = 0;
    return definitions.map(definition => {
        const value = definition.positional
            ? positionals[positionalIndex++]
            : actual.get(definition.name);
        const fallback = strictDefaults.get(definition.name);
        const sourceKind = value !== undefined
            ? 'actual-arg'
            : fallback !== undefined
                ? 'contract-default'
                : 'unresolved';
        const required = definition.required === true;
        const missing = required && value === undefined && fallback === undefined;
        const strict = source.contract.arguments.find(item => item.name === definition.name);
        return {
            name: definition.name,
            required,
            missing,
            type: definition.type,
            source: sourceKind,
            ...(fallback !== undefined ? { default: fallback } : {}),
            ...(missing ? { question: strict?.question ?? `Provide required argument ${definition.name}` } : {}),
        };
    });
}
function assertDispatchableCommand(projectRoot, command, args) {
    const content = resolveStepContent(projectRoot, command);
    if (!content.prepare && !content.workflow) {
        throw new Error('no prepare or workflow content');
    }
    const missing = resolveArgumentRequirements(projectRoot, command, args)
        .filter(item => item.required && item.missing);
    if (missing.length > 0) {
        throw new Error(`missing required arguments: ${missing.map(item => `${item.name}: ${item.question}`).join('; ')}`);
    }
}
/** Compact a full Handoff into the shared PrevHandoff summary shape. */
function toPrevHandoff(handoff) {
    return {
        run_id: handoff.producer_run_id,
        command: handoff.command,
        verdict: handoff.verdict,
        summary: handoff.summary,
        decisions: handoff.decisions.map(d => d.text),
        concerns: handoff.concerns,
    };
}
/**
 * Latest sealed Run's handoff at or before `beforeSequence` (exclusive), scanning
 * the session's runs by descending sequence. When `beforeSequence` is undefined
 * the newest sealed handoff wins. Returns null when no sealed handoff exists.
 */
function latestHandoffBefore(store, sessionId, beforeSequence) {
    const runsDir = join(store.sessionDir(sessionId), 'runs');
    if (!existsSync(runsDir))
        return null;
    const runIds = readdirSync(runsDir).filter(name => existsSync(join(runsDir, name, 'run.json')));
    let best = null;
    for (const runId of runIds) {
        let run;
        try {
            run = store.readRun(sessionId, runId);
        }
        catch {
            continue;
        }
        if (!run.handoff)
            continue;
        if (beforeSequence !== undefined && run.sequence >= beforeSequence)
            continue;
        if (!best || run.sequence > best.sequence)
            best = { sequence: run.sequence, handoff: run.handoff };
    }
    return best ? toPrevHandoff(best.handoff) : null;
}
/** Prev handoff via session.latest_completed_run_id (fast path for step-drivers). */
function handoffByLatestCompleted(store, session) {
    const runId = session.latest_completed_run_id;
    if (!runId)
        return null;
    try {
        const run = store.readRun(session.session_id, runId);
        return run.handoff ? toPrevHandoff(run.handoff) : null;
    }
    catch {
        return null;
    }
}
/** Fast-path-first handoff lookup: O(1) via latest_completed_run_id, fallback to full scan. */
function handoffBeforeSequence(store, session, beforeSequence) {
    const latestId = session.latest_completed_run_id;
    if (latestId) {
        try {
            const latestRun = store.readRun(session.session_id, latestId);
            if (latestRun.handoff && latestRun.sequence < beforeSequence) {
                return toPrevHandoff(latestRun.handoff);
            }
        }
        catch { /* fall through to scan */ }
    }
    return latestHandoffBefore(store, session.session_id, beforeSequence);
}
/**
 * Build the shared session anchor grounding sections (Intent / Boundary
 * Contract / Execution Progress). Progress is derived from the orchestration
 * chain crossed with each completed Run's handoff.summary; an empty chain omits
 * the Progress section. Reuses the P0 inject builders.
 */
function buildAnchorSections(store, session) {
    const chain = session.orchestration.chain;
    const completed = chain.filter(s => (s.status === 'completed' || s.status === 'sealed') && s.run_id);
    const completedHandoffs = [];
    const recent = completed.slice(-5).map(s => {
        let summary = null;
        if (s.run_id) {
            try {
                const handoff = store.readRun(session.session_id, s.run_id).handoff;
                summary = handoff?.summary ?? null;
                if (handoff)
                    completedHandoffs.push(handoff);
            }
            catch {
                summary = null;
            }
        }
        return {
            step_id: s.step_id,
            command: s.command,
            stage: null,
            summary,
            caveats: null,
        };
    });
    const progress = chain.length > 0
        ? buildProgressSection({
            recent,
            done_count: completed.length,
            pending_count: chain.filter(s => s.status === 'pending').length,
        })
        : null;
    return {
        intent: buildIntentSection(session.intent),
        boundary_contract: buildBoundaryContractSection(session.boundary_contract),
        progress,
        signals: buildSignalsSection({
            caveats: completedHandoffs.flatMap(handoff => handoff.concerns).slice(-3),
            deferred: completedHandoffs.flatMap(handoff => handoff.next.map(item => item.reason || item.command)).slice(-5),
        }),
    };
}
function explicitGate(definition, scope, runId, id) {
    if (typeof definition === 'string') {
        return {
            key: definition,
            title: definition,
            scope,
            run_id: runId,
            required: false,
            blocking: false,
            applicable_modes: [],
            status: 'skipped',
            check: { type: 'manual', prompt: definition },
            evidence_refs: [],
            waiver: null,
        };
    }
    return gateSchema.parse({
        key: definition.key,
        title: definition.title ?? definition.key,
        scope,
        run_id: runId,
        required: definition.required,
        blocking: definition.blocking,
        applicable_modes: definition.applicable_modes,
        status: 'pending',
        check: explicitGateCheckSchema.parse(definition.check),
        evidence_refs: [],
        waiver: null,
    });
}
function registerRunGates(registry, contract, runId, sequence) {
    let ordinal = 0;
    const ids = [];
    const add = (gate) => {
        ordinal++;
        const id = `GATE-${String(sequence).padStart(3, '0')}-${String(ordinal).padStart(2, '0')}`;
        registry.gates[id] = gate;
        ids.push(id);
    };
    for (const consume of contract.consumes) {
        add({
            key: `consume-${consume.alias ?? consume.kind}`,
            title: `Resolve required ${consume.kind} input`,
            scope: 'entry',
            run_id: runId,
            required: consume.required,
            blocking: consume.required,
            applicable_modes: [],
            status: 'pending',
            check: {
                type: 'artifact',
                kind: consume.kind,
                ...(consume.alias ? { alias: consume.alias } : {}),
                ...(consume.require_status ? { require_status: consume.require_status } : {}),
            },
            evidence_refs: [],
            waiver: null,
        });
    }
    for (const definition of contract.gates.entry) {
        ordinal++;
        const id = `GATE-${String(sequence).padStart(3, '0')}-${String(ordinal).padStart(2, '0')}`;
        registry.gates[id] = explicitGate(definition, 'entry', runId, id);
        ids.push(id);
    }
    for (const produce of contract.produces) {
        // Legacy v1 contracts do not have enforceable output requiredness. The
        // parser deliberately normalizes those outputs to required=false; only an
        // explicit v2/v2.1 `required: true` declaration may create a blocking gate.
        const required = produce.required === true;
        add({
            key: `produce-${produce.kind}`,
            title: `Produce ${produce.kind}`,
            scope: 'exit',
            run_id: runId,
            required,
            blocking: required,
            applicable_modes: [],
            status: 'pending',
            check: { type: 'artifact', kind: produce.kind, ...(produce.alias ? { alias: produce.alias } : {}) },
            evidence_refs: [],
            waiver: null,
        });
        if ((contract.contract_version === 2 || contract.contract_version === 2.1) && produce.schema) {
            add({
                key: `produce-schema-${produce.alias ?? produce.kind}`,
                title: `Validate ${produce.kind} schema`,
                scope: 'exit',
                run_id: runId,
                required,
                blocking: required,
                applicable_modes: [],
                status: 'pending',
                check: { type: 'schema', artifact_ref: produce.alias ?? produce.kind, schema_id: produce.schema },
                evidence_refs: [],
                waiver: null,
            });
        }
    }
    for (const definition of contract.gates.exit) {
        ordinal++;
        const id = `GATE-${String(sequence).padStart(3, '0')}-${String(ordinal).padStart(2, '0')}`;
        registry.gates[id] = explicitGate(definition, 'exit', runId, id);
        ids.push(id);
    }
    registry.revision++;
    summarizeRegistry(registry);
    return ids;
}
function artifactForGate(gate, context) {
    const check = gate.check;
    if (check.type !== 'artifact' && check.type !== 'schema')
        return null;
    if (check.type === 'artifact') {
        if (gate.scope === 'exit') {
            const found = context.scan.artifacts.find(item => item.kind === check.kind && (!check.alias || item.alias === check.alias));
            return found ? { status: 'draft', schema: found.schemaVersion } : null;
        }
        const consumed = new Set(context.run.input.consumes);
        if (check.alias) {
            const artifactId = context.registry.aliases[check.alias];
            const artifact = artifactId ? context.registry.artifacts[artifactId] : undefined;
            if (artifactId && consumed.has(artifactId) && artifact && artifact.kind === check.kind) {
                return { status: artifact.status, schema: artifact.schema_version };
            }
            return null;
        }
        const artifact = Object.entries(context.registry.artifacts)
            .find(([artifactId, item]) => consumed.has(artifactId) && item.kind === check.kind)?.[1];
        if (artifact)
            return { status: artifact.status, schema: artifact.schema_version };
        return null;
    }
    if (gate.scope === 'exit') {
        const found = context.scan.artifacts.find(item => item.alias === check.artifact_ref || item.kind === check.artifact_ref);
        if (found)
            return { status: 'draft', schema: found.schemaVersion };
    }
    const byAlias = context.registry.aliases[check.artifact_ref];
    const artifact = context.registry.artifacts[byAlias ?? check.artifact_ref];
    return artifact ? { status: artifact.status, schema: artifact.schema_version } : null;
}
function dottedValue(value, path) {
    return path.split('.').reduce((current, key) => {
        if (!current || typeof current !== 'object')
            return undefined;
        return current[key];
    }, value);
}
function evaluateGate(gate, context) {
    if (gate.waiver)
        return 'waived';
    if (gate.applicable_modes.length > 0 && !gate.applicable_modes.includes(context.session.orchestration.quality_mode)) {
        return 'skipped';
    }
    switch (gate.check.type) {
        case 'artifact': {
            const artifact = artifactForGate(gate, context);
            if (!artifact)
                return gate.required ? 'failed' : 'skipped';
            if (gate.check.require_status === 'sealed' && artifact.status !== 'sealed')
                return 'failed';
            return 'passed';
        }
        case 'schema': {
            const artifact = artifactForGate(gate, context);
            return artifact?.schema === gate.check.schema_id ? 'passed' : 'failed';
        }
        case 'session':
            return Object.is(dottedValue(context.session, gate.check.field), gate.check.equals) ? 'passed' : 'failed';
        case 'file': {
            const path = gate.check.path.startsWith('outputs/')
                ? join(context.runDir, gate.check.path)
                : join(context.projectRoot, gate.check.path);
            return existsSync(path) === gate.check.exists ? 'passed' : 'failed';
        }
        case 'decision': {
            const check = gate.check;
            const reportMatch = context.reportDecisions?.some(decision => decision.id === check.point && decision.status === check.outcome);
            if (reportMatch)
                return 'passed';
            const matched = Object.values(context.evidence.records).some(record => record.point === check.point && record.outcome === check.outcome && record.status === 'accepted');
            return matched ? 'passed' : 'failed';
        }
        case 'command': {
            const result = spawnSync(gate.check.argv[0], gate.check.argv.slice(1), {
                cwd: context.projectRoot,
                shell: process.platform === 'win32',
                stdio: 'ignore',
            });
            return result.status === gate.check.expect_exit ? 'passed' : 'failed';
        }
        case 'manual':
            return gate.required ? 'pending' : 'skipped';
    }
}
function evaluateRunGates(bundle, run, context) {
    let changed = false;
    for (const id of run.gate_ids) {
        const gate = bundle.gates.gates[id];
        if (gate) {
            const next = evaluateGate(gate, context);
            if (next !== gate.status) {
                gate.status = next;
                changed = true;
            }
        }
    }
    if (changed)
        bundle.gates.revision++;
    summarizeRegistry(bundle.gates);
    return gateSummary(bundle.gates, run.gate_ids);
}
function isFailureVerdict(verdict) {
    return verdict === 'needs-retry' || verdict === 'blocked';
}
/**
 * A failed attempt is allowed to end without pretending that its successful
 * output contract was satisfied. Exit gates belong to the success path, so
 * mark them not-applicable while retaining entry-gate and scan diagnostics.
 */
function skipExitGatesForFailedAttempt(bundle, run) {
    let changed = false;
    for (const id of run.gate_ids) {
        const gate = bundle.gates.gates[id];
        if (!gate || gate.scope !== 'exit' || gate.status === 'passed' || gate.status === 'waived')
            continue;
        gate.status = 'skipped';
        changed = true;
    }
    if (changed)
        bundle.gates.revision++;
    summarizeRegistry(bundle.gates);
    return gateSummary(bundle.gates, run.gate_ids);
}
function summarizeRegistry(registry) {
    const entries = Object.entries(registry.gates);
    const active = entries.filter(([, gate]) => ['pending', 'running', 'failed', 'blocked'].includes(gate.status));
    const blocking = active.find(([, gate]) => gate.blocking);
    registry.summary = {
        total: entries.length,
        passed: entries.filter(([, gate]) => gate.status === 'passed').length,
        blocked: entries.filter(([, gate]) => gate.status === 'blocked').length,
        failed: entries.filter(([, gate]) => gate.status === 'failed').length,
        active_gate_ids: active.map(([id]) => id),
        blocking_run_id: blocking?.[1].run_id ?? null,
    };
}
function gateSummary(registry, ids) {
    const summary = { passed: [], failed: [], skipped: [], blocking: [] };
    for (const id of ids) {
        const gate = registry.gates[id];
        if (!gate)
            continue;
        if (gate.status === 'passed' || gate.status === 'waived')
            summary.passed.push(id);
        else if (gate.status === 'skipped')
            summary.skipped.push(id);
        else
            summary.failed.push(id);
        if (gate.blocking && !['passed', 'waived', 'skipped'].includes(gate.status))
            summary.blocking.push(id);
    }
    return summary;
}
function contractForRun(projectRoot, run) {
    const source = resolveCommandSource(projectRoot, run.command.name);
    const currentContractHash = contractHash(source.contract);
    if (run.contract_snapshot) {
        if (source.contractSnapshot.snapshot_hash !== run.contract_snapshot.snapshot_hash) {
            throw new Error(`Command lifecycle contract changed after run creation: ${run.command.name} `
                + `(expected ${run.contract_snapshot.snapshot_hash}, got ${source.contractSnapshot.snapshot_hash})`);
        }
        return {
            contract: source.contract,
            warning: source.contentHash === run.command.content_hash
                ? null
                : `Command prompt changed after run creation: ${run.command.name}; lifecycle contract is unchanged`,
        };
    }
    if (run.command.contract_hash) {
        if (currentContractHash !== run.command.contract_hash) {
            throw new Error(`Command lifecycle contract changed after run creation: ${run.command.name} `
                + `(expected ${run.command.contract_hash}, got ${currentContractHash})`);
        }
        return {
            contract: source.contract,
            warning: source.contentHash === run.command.content_hash
                ? null
                : `Command prompt changed after run creation: ${run.command.name}; lifecycle contract is unchanged`,
        };
    }
    if (source.contentHash !== run.command.content_hash) {
        throw new Error(`Command definition changed after run creation: ${run.command.name}; `
            + `legacy Run has no contract_hash. Rebind prompt-only drift with: `
            + `maestro run rebind ${run.run_id} --session ${run.session_id} --reason "<reason>"`);
    }
    return { contract: source.contract, warning: null };
}
function gateContractShape(gate) {
    return stableJson({
        key: gate.key,
        title: gate.title,
        scope: gate.scope,
        run_id: gate.run_id,
        required: gate.required,
        blocking: gate.blocking,
        applicable_modes: gate.applicable_modes,
        check: gate.check,
    });
}
function assertRebindCompatible(registry, run, source) {
    const expectedRegistry = createGateRegistry();
    const expectedIds = registerRunGates(expectedRegistry, source.contract, run.run_id, run.sequence);
    if (stableJson(expectedIds) !== stableJson(run.gate_ids)) {
        throw new Error('Cannot rebind: current lifecycle contract produces a different Run gate set');
    }
    for (const id of expectedIds) {
        const expected = expectedRegistry.gates[id];
        const actual = registry.gates[id];
        if (!actual || gateContractShape(actual) !== gateContractShape(expected)) {
            throw new Error(`Cannot rebind: registered gate ${id} differs from the current lifecycle contract`);
        }
    }
    if (run.contract_snapshot) {
        if (stableJson(run.contract_snapshot.normalized) !== stableJson(source.contractSnapshot.normalized)) {
            throw new Error('Cannot rebind: stored and current lifecycle contract semantics differ');
        }
        return;
    }
    const unrecoverableProduce = source.contract.produces.find(produce => produce.path || produce.primary);
    if (unrecoverableProduce) {
        throw new Error(`Cannot rebind: legacy Run cannot prove path/primary compatibility for produce ${unrecoverableProduce.kind}; `
            + 'create a retry Run instead');
    }
}
function scanSummary(scan) {
    return scan.artifacts.map(item => ({
        path: item.relativePath,
        kind: item.kind,
        role: item.role,
        ...(item.alias ? { alias: item.alias } : {}),
    }));
}
function ensureRunShell(store, sessionId, runId) {
    const runDir = store.runDir(sessionId, runId);
    mkdirSync(join(runDir, 'outputs'), { recursive: true });
    mkdirSync(join(runDir, 'evidence'), { recursive: true });
    mkdirSync(join(runDir, 'work'), { recursive: true });
    const report = join(runDir, 'report.md');
    if (!existsSync(report)) {
        writeFileSync(report, '---\nverdict: ready\nsummary: ""\nconstraints: []\ndecisions: []\nconcerns: []\nnext: []\ndetails: {}\n---\n## 摘要\n\n## 结论/Verdict\n\n## 讨论/复盘\n\n## 产物\n\n## 交接/Next\n', 'utf8');
    }
    writeFileSync(join(runDir, 'diagnostics.ndjson'), '', { flag: 'a' });
    return runDir;
}
function validateSealedIntegrity(run, registry, scan) {
    const sealed = Object.entries(registry.artifacts).filter(([, item]) => item.producer_run_id === run.run_id);
    if (sealed.length !== scan.artifacts.length)
        throw new Error(`Sealed run ${run.run_id} artifact set changed`);
    for (const [, artifact] of sealed) {
        const current = scan.artifacts.find(item => item.relativePath === artifact.relative_path);
        if (!current || current.contentHash !== artifact.content_hash) {
            throw new Error(`Sealed artifact is immutable: ${artifact.relative_path}`);
        }
    }
}
export function createRun(options) {
    const store = new SessionStore(options.projectRoot);
    const state = projectState(options.projectRoot);
    const explicitSession = options.sessionId && store.sessionExists(options.sessionId)
        ? store.readBundle(options.sessionId).session
        : null;
    const intent = options.intent?.trim() || explicitSession?.intent || options.command;
    const topic = options.topic?.trim()
        || explicitSession?.topic_identity?.verbatim
        || explicitSession?.intent
        || intent;
    const intentIdentity = options.intentIdentity ?? createIntentIdentity(options.projectRoot, options.command, intent);
    const source = resolveCommandSource(options.projectRoot, options.command);
    if (source.sessionMode === 'none') {
        throw new Error(`Command "${options.command}" declares session-mode: none and cannot create a Run. `
            + `Use it directly without the run lifecycle.`);
    }
    if (source.sessionMode === 'brief') {
        throw new Error(`Command "${options.command}" declares session-mode: brief. `
            + `Use "maestro run skill ${options.command}" instead of "maestro run create".`);
    }
    const argumentRequirements = resolveArgumentRequirements(options.projectRoot, options.command, options.args ?? []);
    const missingArguments = argumentRequirements.filter(item => item.required && item.missing);
    if (missingArguments.length > 0) {
        throw new Error(`Missing required arguments: ${missingArguments.map(item => `${item.name} (${item.question})`).join(', ')}. `
            + '--intent is Session metadata only and does not fill command arguments; '
            + 'pass required inputs with --arg <value> or -- <args...>.');
    }
    const resolvedSession = resolveSessionId(store, options.sessionId, topic, options.topic ? 'explicit' : options.chainStepId ? 'workflow' : 'legacy-intent');
    const { sessionId, topicIdentity } = resolvedSession;
    const sessionExisted = store.sessionExists(sessionId);
    if (!sessionExisted) {
        store.createSession(sessionId, intent, {
            command: options.command,
            intentIdentity,
            ...(options.sessionProvenance ? { provenance: options.sessionProvenance } : {}),
        });
    }
    return store.update(sessionId, (bundle, tx) => {
        if (options.requireRunningSession) {
            if (bundle.session.status !== 'running') {
                throw new Error(`Session ${sessionId} is ${bundle.session.status}; publishing requires running status`);
            }
            if (options.expectedIdentityRevision !== undefined
                && bundle.session.identity_revision !== options.expectedIdentityRevision) {
                throw new TransitionReceiptError('FENCE_CONFLICT', `stale identity revision: expected ${options.expectedIdentityRevision}, current ${bundle.session.identity_revision}`);
            }
            if (options.expectedActivityRevision !== undefined
                && bundle.session.activity_revision !== options.expectedActivityRevision) {
                throw new TransitionReceiptError('FENCE_CONFLICT', `stale activity revision: expected ${options.expectedActivityRevision}, current ${bundle.session.activity_revision}`);
            }
            const conflict = checkLease(bundle.session.orchestration.lease, options.leaseClaim ?? {});
            if (conflict)
                throw new Error(conflict);
        }
        if (bundle.session.active_run_id) {
            throw new Error(`Session ${sessionId} already has active Run ${bundle.session.active_run_id}; `
                + `inspect it with: maestro run brief ${bundle.session.active_run_id} --session ${sessionId}`);
        }
        if ((bundle.session.topic_identity && !sameTopicIdentity(bundle.session.topic_identity, topicIdentity))
            || (!bundle.session.topic_identity && sessionExisted && normalizeTopic(bundle.session.intent) !== topicIdentity.normalized)) {
            throw new Error(`Session ${sessionId} topic identity changed after resolution`);
        }
        if (!bundle.session.intent_identity) {
            bundle.session.intent_identity = intentIdentity;
        }
        let boundStep = null;
        let chainStepId = options.chainStepId;
        if (options.retryToken && !chainStepId) {
            const retryStep = bundle.session.orchestration.chain.find(step => step.pending_retry?.token === options.retryToken);
            if (!retryStep)
                throw new Error('invalid, expired, or already-consumed retry token');
            chainStepId = retryStep.step_id;
        }
        if (chainStepId) {
            if (bundle.session.status !== 'running') {
                throw new Error(`Session ${sessionId} is ${bundle.session.status}; chain dispatch requires running status`);
            }
            if (options.expectedActivityRevision !== undefined
                && bundle.session.activity_revision !== options.expectedActivityRevision) {
                throw new Error(`Session ${sessionId} changed after run-next preflight `
                    + `(expected activity_revision ${options.expectedActivityRevision}, got ${bundle.session.activity_revision})`);
            }
            if (options.expectedIdentityRevision !== undefined
                && bundle.session.identity_revision !== options.expectedIdentityRevision) {
                throw new Error(`Session ${sessionId} identity changed after run-next preflight `
                    + `(expected identity_revision ${options.expectedIdentityRevision}, got ${bundle.session.identity_revision})`);
            }
            const conflict = checkLease(bundle.session.orchestration.lease, options.leaseClaim ?? {});
            if (conflict)
                throw new Error(conflict);
            const running = bundle.session.orchestration.chain.find(step => step.status === 'running');
            if (running)
                throw new Error(`chain step already running: ${running.step_id}`);
            boundStep = bundle.session.orchestration.chain.find(step => step.step_id === chainStepId) ?? null;
            if (!boundStep)
                throw new Error(`chain step not found: ${chainStepId}`);
            if (boundStep.status !== 'pending') {
                throw new Error(`chain step ${boundStep.step_id} is ${boundStep.status}, not pending`);
            }
            if (boundStep.decision_ref)
                throw new Error(`chain step ${boundStep.step_id} is a decision node`);
            if (boundStep.command !== options.command) {
                throw new Error(`chain step ${boundStep.step_id} expects command ${boundStep.command}, got ${options.command}`);
            }
            const boundIndex = bundle.session.orchestration.chain.findIndex(step => step.step_id === boundStep.step_id);
            const earlierDecision = bundle.session.orchestration.chain
                .slice(0, boundIndex)
                .find(step => {
                if (!step.decision_ref)
                    return false;
                const point = bundle.session.orchestration.decision_points
                    .find(item => item.point_id === step.decision_ref);
                const stepTerminal = step.status === 'sealed' || step.status === 'completed';
                return !stepTerminal || point?.status !== 'passed';
            });
            if (earlierDecision) {
                const point = bundle.session.orchestration.decision_points
                    .find(item => item.point_id === earlierDecision.decision_ref);
                throw new Error(`earlier decision ${earlierDecision.decision_ref} is ${point?.status ?? 'pending'} `
                    + `and gates chain step ${boundStep.step_id}`);
            }
        }
        if (!bundle.session.topic_identity) {
            bundle.session.topic_identity = topicIdentity;
            bundle.session.identity_revision++;
        }
        if (!options.sessionId) {
            const candidates = runningTopicCandidatesLocked(store, topicIdentity, bundle.session);
            const resolved = uniqueTopicCandidate(candidates.some(item => item.session.topic_identity) ? 'Running topic match' : 'Legacy exact intent match', candidates);
            if (resolved !== sessionId) {
                throw new Error(`Topic Session selection changed after resolution; expected ${sessionId}, got ${resolved ?? 'none'}`);
            }
        }
        const freshState = projectState(options.projectRoot);
        const sequence = nextSequence(store, sessionId);
        const runId = `${dateId()}-${String(sequence).padStart(3, '0')}-${slug(options.command, 'run')}`;
        const now = localISO();
        const resolvedPlatform = resolveTargetPlatform(options.platform, undefined, bundle.session);
        let parentRunId = null;
        if (boundStep?.pending_retry) {
            const pending = boundStep.pending_retry;
            if (!options.retryToken)
                throw new Error(`chain step ${boundStep.step_id} requires its pending retry token`);
            if (pending.token !== options.retryToken)
                throw new Error('retry token does not match the requested chain step');
            if (pending.session_id !== sessionId)
                throw new Error(`retry token belongs to Session ${pending.session_id}`);
            if (pending.chain_step_id !== boundStep.step_id)
                throw new Error('retry token chain step mismatch');
            if (pending.command !== options.command)
                throw new Error(`retry token is for command ${pending.command}`);
            if (Date.parse(pending.expires_at) <= Date.now())
                throw new Error('retry token has expired');
            const parent = tx.readRun(pending.parent_run_id);
            if (parent.session_id !== sessionId)
                throw new Error(`retry parent belongs to Session ${parent.session_id}`);
            if (parent.command.name !== options.command)
                throw new Error('retry parent command mismatch');
            if (parent.chain_step_id !== boundStep.step_id)
                throw new Error('retry parent chain step mismatch');
            if (parent.sequence >= sequence)
                throw new Error('retry parent must precede the replacement Run');
            if (!parent.retry_fence || parent.retry_fence.token !== pending.token) {
                throw new Error('retry parent fence does not match the pending token');
            }
            if (parent.retry_fence.consumed_at)
                throw new Error('retry token was already consumed');
            parent.retry_fence.consumed_at = now;
            boundStep.pending_retry = null;
            parentRunId = parent.run_id;
            tx.writeRun(parent);
        }
        else if (options.retryToken) {
            throw new Error('invalid, expired, or already-consumed retry token');
        }
        const runDir = ensureRunShell(store, sessionId, runId);
        const gateIds = registerRunGates(bundle.gates, source.contract, runId, sequence);
        const reuse = collectReusableUpstream(options.projectRoot, store, bundle.session, bundle.artifacts, bundle.gates, source.contract);
        const upstream = reuse.upstream;
        const guidanceSnapshot = buildGuidanceSnapshot(options.projectRoot, options.command, source);
        const creationMode = options.creation?.mode
            ?? (options.retryToken ? 'retry' : boundStep ? 'chain-next' : 'explicit-create');
        const run = {
            schema_version: 'command-run/1.3',
            session_id: sessionId,
            run_id: runId,
            sequence,
            parent_run_id: parentRunId,
            chain_step_id: boundStep?.step_id ?? null,
            resolved_platform: resolvedPlatform,
            goal_binding: null,
            checkpoint_expectation: null,
            checkpoint: null,
            retry_fence: null,
            contract_snapshot: source.contractSnapshot,
            guidance_snapshot: guidanceSnapshot,
            creation_decision: {
                schema_version: 'creation-decision/1.0',
                decision_id: `dec_${sha256(`${sessionId}\u0000${runId}\u0000${now}`).slice(0, 24)}`,
                request_id: options.creation?.requestId ?? null,
                mode: creationMode,
                authority: options.creation?.authority ?? (boundStep ? 'chain-transition' : 'explicit-command'),
                decided_at: now,
                session_identity_revision: bundle.session.identity_revision,
                session_activity_revision: bundle.session.activity_revision,
                confirmation_token_hash: options.creation?.confirmationTokenHash ?? null,
            },
            creation_provenance: options.creation?.provenance ?? {
                schema_version: 'creation-provenance/1.0',
                provenance: 'native-v2',
                source_workspace_id: null,
                source_session_id: null,
                source_run_id: parentRunId,
                imported_artifact_hashes: [],
            },
            transition: options.creation?.transition ?? null,
            command: {
                name: options.command,
                version: '1.0',
                source_path: source.relativePath,
                content_hash: source.contentHash,
                resolved_prompt_hash: sha256(source.raw),
                contract_hash: contractHash(source.contract),
            },
            status: 'running',
            input: {
                args: options.args ?? [],
                consumes: Object.values(upstream).map(item => item.artifact_id),
                context_identity_revision: bundle.session.identity_revision,
                reuse_assessments: reuse.assessments,
            },
            gate_ids: gateIds,
            output: { produces: [], primary_artifact_id: null, verdict: null },
            handoff: null,
            started_at: now,
            completed_at: null,
            sealed_at: null,
        };
        const emptyScan = { artifacts: [], warnings: [], errors: [] };
        const entryContext = {
            projectRoot: options.projectRoot,
            runDir,
            session: bundle.session,
            registry: bundle.artifacts,
            scan: emptyScan,
            evidence: bundle.evidence,
            run,
        };
        for (const id of gateIds) {
            const gate = bundle.gates.gates[id];
            if (gate?.scope === 'entry')
                gate.status = evaluateGate(gate, entryContext);
        }
        summarizeRegistry(bundle.gates);
        const entrySummary = gateSummary(bundle.gates, gateIds.filter(id => bundle.gates.gates[id]?.scope === 'entry'));
        const entryBlockers = entrySummary.blocking.slice(0, 5).map(gateId => {
            const gate = bundle.gates.gates[gateId];
            return { gate_id: gateId, title: gate.title, status: gate.status };
        });
        if (entrySummary.blocking.length > 0)
            run.status = 'blocked';
        bundle.session.active_run_id = runId;
        if (boundStep) {
            boundStep.status = 'running';
            boundStep.run_id = runId;
            const lease = claimLease(bundle.session.orchestration.lease, options.leaseClaim ?? {});
            if (lease)
                bundle.session.orchestration.lease = lease;
        }
        bundle.session.activity_revision++;
        bundle.session.status = 'running';
        bundle.gates.revision++;
        tx.writeRun(run);
        const nextState = ensureSessionProjection(freshState, projectSessionEntry(bundle.session));
        tx.writeJson(join(store.workflowRoot, 'state.json'), nextState);
        const runDirRel = canonicalRunDir(store, sessionId, runId);
        const hasWorkflow = resolveStepContent(options.projectRoot, options.command).workflow !== null;
        const readyReason = hasWorkflow
            ? 'load the workflow execution manual, execute it, then run: maestro run check → maestro run complete'
            : `write deliverables to ${runDirRel}/outputs/, then run: maestro run check → maestro run complete`;
        return {
            session_id: sessionId,
            run_id: runId,
            run_dir: runDirRel,
            chain_step_id: run.chain_step_id,
            resolved_platform: run.resolved_platform,
            upstream,
            topic_identity: bundle.session.topic_identity ?? topicIdentity,
            reuse_assessments: reuse.assessments,
            argument_requirements: argumentRequirements,
            entry_gates: entrySummary,
            entry_blockers: entryBlockers,
            session_created: !sessionExisted && Boolean(options.sessionId),
            next: {
                command: `maestro run brief ${runId}`,
                reason: entrySummary.blocking.length > 0
                    ? 'entry gates blocking — inspect gate status, resolve missing upstream before executing'
                    : readyReason,
            },
        };
    });
}
/**
 * Finish-work checklist injected when `run check` finds every gate clean.
 * Core norms (handoff frontmatter, knowledge staging, verdict semantics) are
 * runtime-built; workflow frontmatter `finish:` lines extend them. Mirrors the
 * core/extension split of the injection builder (inject.ts).
 */
function buildFinishChecklist(projectRoot, run, frontmatter) {
    const lines = [];
    if (!frontmatter.summary.trim()) {
        lines.push('report.md handoff frontmatter is empty — fill summary (plus concerns/decisions) before completing; the sealed handoff is derived from it.');
    }
    lines.push(`Stage knowledge before sealing: put accepted decisions and locked constraints in report.md frontmatter (completion stages them automatically); reusable recipes/pitfalls → \`maestro knowledge stage knowhow "<title>" --content-file <path|-> --run ${run.run_id}\` (write content to a temp file or stdin, never inline). Quality bar: stage only pitfalls ("when doing X, watch out for Y because Z"), failure lessons, non-trivial trade-offs, or newly established prescriptive constraints — never process notes, re-descriptions of existing patterns, trivial operations, or raw tool/log traces; zero candidates is a legitimate outcome. Do not write project spec/knowhow directly from routine Run completion.`);
    lines.push('Session-source candidates (staged with `--session`, run-less work) promote only after the Session is sealed with a fresh session reconciliation receipt; `maestro knowledge review <session-id> --refresh` repairs missing/stale session receipts.');
    lines.push(`Inspect the reconciliation receipt created by this check. For every candidate that needs a disposition, present it to the user first — title, content summary, evidence anchors, evidence-backed matches (id + title), and your recommended disposition (unique|duplicate|related|conflict|supersede + target) with a one-line rationale — then collect the user's decision and only then run \`maestro knowledge promote <session-id> --resolve <candidate-id> --as <choice> [--target <knowledge-id>] --reason "<reason>"\` (inline TOCTOU fence + resolve + promote). Never hand the raw promote command to the user as the whole task. Unresolved items may be sealed but cannot be promoted.`);
    lines.push(`Record stronger knowledge relations during staging: \`maestro knowledge stage <target> "<title>" --content-file <path|-> --run ${run.run_id} --signal cited|validated|contradicted --signal-ids <knowledge-ids>\`. A search result or automatic injection is exposure only; it is not evidence of use.`);
    lines.push(`Attribute search hits before citing: \`maestro knowledge record <knowledge-ids...> --signal consumed|cited|validated|contradicted --source search --run ${run.run_id}\` records pure attribution without staging a candidate (use stage --signal only when a candidate is intended); record/load turn exposure into evidence.`);
    lines.push('Teammate/agent outputs worth reusing: put conclusions into report.md frontmatter decisions/constraints (seal stages them automatically) or stage explicitly with `maestro knowledge stage knowhow "<title>" --content-file <path|-> --run ' + run.run_id + '` — never let sub-agent findings vanish at process exit.');
    lines.push('Negative knowledge: failed tests, rejected reviews, or contradicted practices → stage a counterexample candidate (scope + failure reason + alternative) with `maestro knowledge stage knowhow "<title>" --content-file <path|-> --run ' + run.run_id + '` so future runs stop repeating them.');
    lines.push('For contradicted canonical knowledge, record the contradiction before sealing. After candidate review/promotion, replace stale rules with `maestro spec supersede <old-sid> --by <new-sid>`; if both rules remain valid, use `maestro spec conflict mark <file> <line> --note "<reason>"`. Never leave a known-stale entry unmarked.');
    lines.push('Pick the verdict honestly: `done` (clean) or `done-with-concerns` (works but carries caveats — list every caveat in concerns).');
    lines.push(...resolveStepContent(projectRoot, run.command.name).finish);
    return lines;
}
function checkNext(sessionId, runId, status, clean) {
    if (status === 'sealed' || status === 'completed') {
        return {
            command: `maestro run next --session ${sessionId}`,
            reason: 'run sealed — advance the chain',
        };
    }
    if (!clean) {
        return {
            command: `maestro run check ${runId}`,
            reason: 'blocking gates or scan errors — repair outputs, then re-run check',
        };
    }
    return {
        command: `maestro run complete ${runId}`,
        reason: 'all gates clean — work through the finish checklist, then complete (--verdict done|done-with-concerns)',
    };
}
function validateStrictArtifactContract(runDir, contract, scan) {
    if (contract.contract_version !== 2 && contract.contract_version !== 2.1)
        return;
    for (const expected of contract.produces) {
        const expectedPath = expected.path?.replaceAll('\\', '/').replace(/^\.\//, '');
        const actual = expectedPath
            ? scan.artifacts.find(item => relative(runDir, item.absolutePath).replaceAll('\\', '/') === expectedPath)
            : undefined;
        if (!actual) {
            if (expected.required)
                scan.errors.push(`Missing required contract v2 output: ${expectedPath ?? expected.kind}`);
            continue;
        }
        if (actual.kind !== expected.kind) {
            scan.errors.push(`${expectedPath}: _meta.kind ${actual.kind} does not match contract ${expected.kind}`);
        }
        if (expected.schema && actual.schemaVersion !== expected.schema) {
            scan.errors.push(`${expectedPath}: _meta.schema ${actual.schemaVersion} does not match contract ${expected.schema}`);
        }
        const expectedRole = expected.role ?? (expected.primary ? 'primary' : 'attachment');
        if (actual.role !== expectedRole) {
            scan.errors.push(`${expectedPath}: _meta.role ${actual.role} does not match contract ${expectedRole}`);
        }
    }
}
export function checkRun(projectRoot, runId, sessionId) {
    const store = new SessionStore(projectRoot);
    const located = store.findRun(runId, sessionId);
    const initialBundle = store.readBundle(located.sessionId);
    const resolvedContract = contractForRun(projectRoot, located.run);
    const reuse = revalidateRunReuse(projectRoot, store, initialBundle, located.run, resolvedContract.contract);
    const scan = scanOutputs(store.runDir(located.sessionId, runId), store.sessionDir(located.sessionId), resolvedContract.contract);
    validateStrictArtifactContract(store.runDir(located.sessionId, runId), resolvedContract.contract, scan);
    validateChainProposalArtifacts(store.runDir(located.sessionId, runId), initialBundle, located.run, resolvedContract.contract, scan, {
        preflight: located.run.status !== 'sealed',
        validateCommand: (command, args) => assertDispatchableCommand(projectRoot, command, args),
    });
    scan.errors.push(...reuse.blockers);
    if (resolvedContract.warning)
        scan.warnings.unshift(resolvedContract.warning);
    const frontmatter = readReportFrontmatter(store.runDir(located.sessionId, runId));
    if (located.run.status === 'sealed') {
        const bundle = store.readBundle(located.sessionId);
        validateSealedIntegrity(located.run, bundle.artifacts, scan);
        const knowledgeReconciliation = readKnowledgeReconciliation(store, located.sessionId, runId, true);
        return {
            session_id: located.sessionId,
            run_id: runId,
            status: 'sealed',
            gates: gateSummary(bundle.gates, located.run.gate_ids),
            artifacts: scanSummary(scan),
            warnings: scan.warnings,
            errors: scan.errors,
            upstream: reuse.upstream,
            reuse_assessments: reuse.assessments,
            next: checkNext(located.sessionId, runId, 'sealed', true),
            ...(knowledgeReconciliation
                ? { knowledge_reconciliation: reconciliationSummary(knowledgeReconciliation) }
                : {}),
        };
    }
    const knowledgeReconciliation = reconcileRunKnowledgeSync(projectRoot, located.sessionId, runId, frontmatter);
    if (knowledgeReconciliation.counts.review_required > 0) {
        scan.warnings.push(`${knowledgeReconciliation.counts.review_required} knowledge candidate(s) require review before promotion`);
    }
    return store.update(located.sessionId, (bundle, tx) => {
        const run = tx.readRun(runId);
        const context = {
            projectRoot,
            runDir: store.runDir(located.sessionId, runId),
            session: bundle.session,
            registry: bundle.artifacts,
            scan,
            evidence: bundle.evidence,
            reportDecisions: frontmatter.decisions.map(item => ({ id: item.id, status: item.status })),
            run,
        };
        const gates = evaluateRunGates(bundle, run, context);
        if (run.status === 'created')
            run.status = 'running';
        tx.writeRun(run);
        writeKnowledgeReconciliation(store, tx, knowledgeReconciliation);
        const clean = gates.blocking.length === 0 && scan.errors.length === 0;
        // Write a .check_clean marker so `session done --check-clean` can skip
        // gate re-evaluation when outputs/ has not been modified since.
        if (clean) {
            try {
                writeFileSync(join(store.runDir(located.sessionId, runId), '.check_clean'), JSON.stringify({ at: new Date().toISOString(), gates_revision: bundle.gates.revision }), 'utf8');
            }
            catch { /* best-effort marker */ }
        }
        return {
            session_id: located.sessionId,
            run_id: runId,
            status: run.status,
            gates,
            artifacts: scanSummary(scan),
            warnings: scan.warnings,
            errors: scan.errors,
            upstream: reuse.upstream,
            reuse_assessments: reuse.assessments,
            next: checkNext(located.sessionId, runId, run.status, clean),
            knowledge_reconciliation: reconciliationSummary(knowledgeReconciliation),
            ...(clean ? { finish: buildFinishChecklist(projectRoot, run, frontmatter) } : {}),
        };
    });
}
export function rebindRunCommand(projectRoot, runId, reason, sessionId) {
    const normalizedReason = reason.trim();
    if (!normalizedReason)
        throw new Error('Rebind requires a non-empty reason');
    const store = new SessionStore(projectRoot);
    const located = store.findRun(runId, sessionId);
    const source = resolveCommandSource(projectRoot, located.run.command.name);
    const nextContractHash = contractHash(source.contract);
    return store.update(located.sessionId, (bundle, tx) => {
        const run = tx.readRun(runId);
        if (run.status === 'sealed')
            throw new Error(`Run ${runId} is sealed and immutable`);
        assertRebindCompatible(bundle.gates, run, source);
        const oldSourcePath = run.command.source_path;
        const oldContentHash = run.command.content_hash;
        const oldResolvedPromptHash = run.command.resolved_prompt_hash;
        const oldContractHash = run.command.contract_hash ?? null;
        const oldContractSnapshot = run.contract_snapshot;
        const oldSnapshotHash = oldContractSnapshot?.snapshot_hash ?? null;
        const oldGuidanceSnapshot = run.guidance_snapshot;
        const nextResolvedPromptHash = sha256(source.raw);
        const nextGuidanceSnapshot = oldGuidanceSnapshot
            ? buildGuidanceSnapshot(projectRoot, run.command.name, source)
            : null;
        const alreadyCurrent = oldSourcePath === source.relativePath
            && oldContentHash === source.contentHash
            && oldResolvedPromptHash === nextResolvedPromptHash
            && oldContractHash === nextContractHash
            && oldSnapshotHash === source.contractSnapshot.snapshot_hash
            && (!oldGuidanceSnapshot || stableJson(oldGuidanceSnapshot) === stableJson(nextGuidanceSnapshot));
        if (alreadyCurrent)
            throw new Error(`Run ${runId} is already bound to the current command definition`);
        const rebindKind = oldContractHash === null
            ? 'legacy_contract_backfill'
            : oldContractHash !== nextContractHash || oldSnapshotHash !== source.contractSnapshot.snapshot_hash
                ? 'compatible_contract_rebind'
                : 'prompt_only_rebind';
        run.command.source_path = source.relativePath;
        run.command.content_hash = source.contentHash;
        run.command.resolved_prompt_hash = nextResolvedPromptHash;
        run.command.contract_hash = nextContractHash;
        run.contract_snapshot = source.contractSnapshot;
        if (oldGuidanceSnapshot)
            run.guidance_snapshot = nextGuidanceSnapshot;
        tx.writeRun(run);
        const auditPath = join(store.runDir(located.sessionId, runId), 'command-rebind.json');
        const audit = commandRebindAuditSchema.parse({
            schema_version: 'command-rebind/1.1',
            run_id: runId,
            command: run.command.name,
            rebind_kind: rebindKind,
            reason: normalizedReason,
            old_source_path: oldSourcePath,
            source_path: source.relativePath,
            old_content_hash: oldContentHash,
            content_hash: source.contentHash,
            old_resolved_prompt_hash: oldResolvedPromptHash,
            resolved_prompt_hash: nextResolvedPromptHash,
            old_contract_hash: oldContractHash,
            contract_hash: nextContractHash,
            old_snapshot_hash: oldSnapshotHash,
            snapshot_hash: source.contractSnapshot.snapshot_hash,
            old_contract_snapshot: oldContractSnapshot,
            contract_snapshot: source.contractSnapshot,
            old_guidance_snapshot: oldGuidanceSnapshot,
            guidance_snapshot: nextGuidanceSnapshot,
            creation_decision_id: run.creation_decision?.decision_id ?? null,
            transition: run.transition,
            rebound_at: localISO(),
        });
        tx.writeJson(auditPath, audit);
        return {
            session_id: located.sessionId,
            run_id: runId,
            rebind_kind: rebindKind,
            old_content_hash: oldContentHash,
            content_hash: source.contentHash,
            old_contract_hash: oldContractHash,
            contract_hash: nextContractHash,
            old_snapshot_hash: oldSnapshotHash,
            snapshot_hash: source.contractSnapshot.snapshot_hash,
            audit_path: relative(projectRoot, auditPath).replaceAll('\\', '/'),
        };
    });
}
export function sealSession(projectRoot, sessionId, summary = '') {
    const store = new SessionStore(projectRoot);
    if (!store.sessionExists(sessionId))
        throw new Error(`Session not found: ${sessionId}`);
    const runsDir = join(store.sessionDir(sessionId), 'runs');
    const runIds = existsSync(runsDir)
        ? readdirSync(runsDir).filter(name => existsSync(join(runsDir, name, 'run.json')))
        : [];
    const result = store.update(sessionId, (bundle) => {
        const unsealed = runIds.filter(runId => store.readRun(sessionId, runId).status !== 'sealed');
        if (unsealed.length > 0)
            throw new Error(`Session has unsealed Runs: ${unsealed.join(', ')}`);
        const claimed = bundle.session.requests.filter(request => request.status === 'claimed');
        if (claimed.length > 0)
            throw new Error(`Session has claimed requests: ${claimed.map(item => item.request_id).join(', ')}`);
        const blocking = Object.entries(bundle.gates.gates)
            .filter(([, gate]) => gate.scope === 'session' && gate.required && gate.blocking)
            .filter(([, gate]) => !['passed', 'waived', 'skipped'].includes(gate.status))
            .map(([id]) => id);
        if (blocking.length > 0)
            throw new Error(`Session gates are not complete: ${blocking.join(', ')}`);
        const sealedAt = localISO();
        bundle.session.status = 'sealed';
        bundle.session.active_run_id = null;
        bundle.session.identity_revision++;
        bundle.session.activity_revision++;
        bundle.session.lifecycle.sealed_at = sealedAt;
        bundle.session.lifecycle.seal_summary = summary || `Sealed with ${runIds.length} Run(s)`;
        return { session_id: sessionId, status: 'sealed', sealed_at: sealedAt, run_count: runIds.length };
    });
    const state = projectState(projectRoot);
    const bundle = store.readBundle(sessionId);
    const projected = ensureSessionProjection(state, projectSessionEntry(bundle.session), false);
    if (projected.active_session_id === sessionId)
        projected.active_session_id = null;
    writeStateJson(projectRoot, projected);
    // K6: refresh the session-level reconciliation receipt at seal time
    // (isomorphic to the run-seal reconciliation write). Best-effort: a receipt
    // failure must not block sealing — the missing receipt keeps promotion of
    // session-origin candidates fail-closed until review --refresh repairs it.
    try {
        const sessionReceipt = ensureSessionKnowledgeReconciliation(projectRoot, sessionId);
        persistSessionKnowledgeReconciliation(projectRoot, sessionReceipt);
    }
    catch {
        // Missing receipt → promotion of session-origin candidates fails closed.
    }
    const knowledge = summarizeSessionKnowledge(projectRoot, sessionId, { readOnly: true });
    const reconciliation = knowledge.candidates.map(candidate => {
        const policies = reconciliationForCandidate(projectRoot, sessionId, candidate.run_ids, candidate.candidate_id);
        return policies.find(item => item.promotion_eligibility === 'suppressed')
            ?? policies.find(item => item.promotion_eligibility === 'review_required')
            ?? policies[0]
            ?? null;
    });
    return {
        ...result,
        knowledge: {
            pending_candidates: knowledge.candidates.filter(candidate => candidate.status === 'pending').length,
            promoting_candidates: knowledge.candidates.filter(candidate => candidate.status === 'promoting').length,
            promoted_candidates: knowledge.candidates.filter(candidate => candidate.status === 'promoted').length,
            review_required_candidates: reconciliation
                .filter(candidate => candidate?.promotion_eligibility === 'review_required').length,
            conflict_candidates: reconciliation
                .filter(candidate => candidate?.disposition === 'potential_conflict').length,
            suppressed_candidates: reconciliation
                .filter(candidate => candidate?.promotion_eligibility === 'suppressed').length,
            review_command: `maestro knowledge review ${sessionId}`,
        },
    };
}
function artifactId(sequence, ordinal) {
    return `ART-${String(sequence).padStart(3, '0')}-${String(ordinal).padStart(3, '0')}`;
}
function registerArtifacts(registry, run, discovered) {
    const ids = [];
    let ordinal = 0;
    for (const item of discovered) {
        ordinal++;
        const existing = Object.entries(registry.artifacts).find(([, artifact]) => artifact.producer_run_id === run.run_id && artifact.relative_path === item.relativePath);
        const id = existing?.[0] ?? artifactId(run.sequence, ordinal);
        const previous = existing?.[1];
        if (previous?.status === 'sealed' && previous.content_hash !== item.contentHash) {
            throw new Error(`Sealed artifact is immutable: ${item.relativePath}`);
        }
        const alias = item.alias ?? (item.role === 'primary' ? defaultAlias(item.kind, run.command.name) : undefined);
        const priorAliasId = alias ? registry.aliases[alias] : undefined;
        if (priorAliasId && priorAliasId !== id) {
            const prior = registry.artifacts[priorAliasId];
            if (prior && prior.status === 'sealed')
                prior.status = 'superseded';
        }
        registry.artifacts[id] = {
            kind: item.kind,
            role: item.role,
            producer_run_id: run.run_id,
            relative_path: item.relativePath,
            media_type: item.mediaType,
            schema_version: item.schemaVersion,
            content_hash: item.contentHash,
            size: item.size,
            status: 'sealed',
            derived_from: run.input.consumes,
            replaces: priorAliasId && priorAliasId !== id ? priorAliasId : previous?.replaces ?? null,
        };
        if (alias)
            registry.aliases[alias] = id;
        ids.push(id);
    }
    registry.revision++;
    return ids;
}
function recordCompletionEvidence(bundle, run, artifactIds, frontmatter) {
    const refs = [];
    let ordinal = 0;
    for (const decision of frontmatter.decisions) {
        ordinal++;
        const id = `EVD-${String(run.sequence).padStart(3, '0')}-${String(ordinal).padStart(3, '0')}`;
        bundle.evidence.records[id] = {
            run_id: run.run_id,
            command: run.command.name,
            kind: 'decision',
            point: decision.id,
            claim: decision.text,
            outcome: decision.status,
            rationale: decision.text.slice(0, 2000),
            status: decision.status,
            artifact_refs: artifactIds,
            gate_refs: [],
            source_refs: ['report.md'],
        };
        refs.push(id);
    }
    for (const gateId of run.gate_ids) {
        const gate = bundle.gates.gates[gateId];
        if (!gate)
            continue;
        ordinal++;
        const id = `EVD-${String(run.sequence).padStart(3, '0')}-${String(ordinal).padStart(3, '0')}`;
        bundle.evidence.records[id] = {
            run_id: run.run_id,
            command: run.command.name,
            kind: 'gate',
            point: gate.key,
            claim: gate.title,
            outcome: gate.status,
            rationale: `Gate ${gateId} evaluated as ${gate.status}`,
            status: gate.status === 'passed' || gate.status === 'waived' ? 'accepted' : 'proposed',
            artifact_refs: artifactIds,
            gate_refs: [gateId],
            source_refs: [],
        };
        gate.evidence_refs = [id];
        refs.push(id);
    }
    if (run.gate_ids.length > 0)
        bundle.gates.revision++;
    if (refs.length > 0)
        bundle.evidence.revision++;
    return refs;
}
function inferExtraMediaType(path) {
    switch (extname(path).toLowerCase()) {
        case '.json': return 'application/json';
        case '.md': return 'text/markdown';
        case '.yaml':
        case '.yml': return 'application/yaml';
        case '.txt':
        case '.log': return 'text/plain';
        default: return 'application/octet-stream';
    }
}
/**
 * Resolve `--artifact` run-relative paths into DiscoveredArtifact records for
 * registration. Each path must resolve inside run_dir (else throw) and must
 * exist (else throw). kind = filename stem, role = 'evidence'. Directories hash
 * recursively via the same content model as scanOutputs.
 */
function discoverExtraArtifacts(runDir, sessionDir, paths) {
    const runDirAbs = resolvePath(runDir);
    const discovered = [];
    for (const rel of paths) {
        const abs = resolvePath(runDir, rel);
        const within = abs === runDirAbs || abs.startsWith(runDirAbs + sep);
        if (!within) {
            throw new Error(`--artifact path escapes run directory: ${rel}`);
        }
        if (!existsSync(abs)) {
            throw new Error(`--artifact path does not exist: ${rel}`);
        }
        const stat = statSync(abs);
        const data = stat.isDirectory() ? null : readFileSync(abs);
        const contentHash = data
            ? createHash('sha256').update(data).digest('hex')
            : createHash('sha256').update(abs).digest('hex');
        const size = data ? data.byteLength : 0;
        const kind = basename(abs, extname(abs)) || basename(abs);
        discovered.push({
            absolutePath: abs,
            relativePath: relative(sessionDir, abs).replaceAll('\\', '/'),
            kind,
            schemaVersion: `${kind}/1.0`,
            role: 'evidence',
            mediaType: stat.isDirectory() ? 'application/vnd.maestro.directory' : inferExtraMediaType(abs),
            contentHash,
            size,
        });
    }
    return discovered;
}
/** Append `notes` to a derived handoff's concerns, de-duplicated, preserving order. */
function mergeNotesIntoConcerns(handoff, notes) {
    if (notes.length === 0)
        return;
    const seen = new Set(handoff.concerns);
    for (const note of notes) {
        const trimmed = note.trim();
        if (!trimmed || seen.has(trimmed))
            continue;
        seen.add(trimmed);
        handoff.concerns.push(trimmed);
    }
}
/**
 * Append CLI-supplied decisions to a derived handoff, de-duplicated by text. IDs
 * continue the report-frontmatter decision numbering (D-CLI-n) so they never
 * collide with report decisions; status is `accepted` (the orchestrator asserted
 * them). Report-frontmatter decisions remain the primary channel.
 */
function mergeDecisionsIntoHandoff(handoff, decisions) {
    if (decisions.length === 0)
        return;
    const seen = new Set(handoff.decisions.map(d => d.text));
    let ordinal = 0;
    for (const decision of decisions) {
        const trimmed = decision.trim();
        if (!trimmed || seen.has(trimmed))
            continue;
        seen.add(trimmed);
        ordinal++;
        handoff.decisions.push({ id: `D-CLI-${ordinal}`, status: 'accepted', text: trimmed });
    }
}
function applyChainVerdict(session, run, verdict) {
    const index = session.orchestration.chain.findIndex(step => step.run_id === run.run_id);
    if (index < 0)
        return null;
    const step = session.orchestration.chain[index];
    let retry = null;
    switch (verdict) {
        case 'done':
        case 'done-with-concerns':
            step.status = 'sealed';
            break;
        case 'needs-retry': {
            const current = step.retry ?? { count: 0, max: 2 };
            const next = { count: current.count + 1, max: current.max };
            step.retry = next;
            issueRetryToken(session.session_id, step, run);
            step.status = 'pending';
            step.run_id = null;
            retry = { ...next, exhausted: next.count >= next.max };
            break;
        }
        case 'blocked':
            step.status = 'failed';
            session.status = 'paused';
            break;
    }
    return { step_id: step.step_id, index, step_status: step.status, retry };
}
function preparedPathHash(path) {
    if (!existsSync(path))
        return null;
    const stat = statSync(path);
    return stat.isDirectory()
        ? protocolSha256(hashDirectory(path).hash)
        : protocolSha256(readFileSync(path));
}
function completeInputSnapshot(runDir, paths) {
    const runRoot = resolvePath(runDir);
    const files = [...new Set(paths.map(path => resolvePath(path)))]
        .map(path => {
        if (path !== runRoot && !path.startsWith(`${runRoot}${sep}`)) {
            throw new Error(`complete input path escapes run directory: ${path}`);
        }
        return {
            path: relative(runRoot, path).replaceAll('\\', '/') || '.',
            content_hash: preparedPathHash(path),
        };
    })
        .sort((left, right) => left.path.localeCompare(right.path));
    const unhashed = { schema_version: 'complete-input-snapshot/1.0', files };
    return completeInputSnapshotSchema.parse({
        ...unhashed,
        snapshot_hash: protocolSha256(stableJsonUtf8(unhashed)),
    });
}
function assertCompleteReplayInputs(runDir, record) {
    const parsed = completeInputSnapshotSchema.safeParse(record.payload.payload.completion_input_snapshot);
    if (!parsed.success) {
        throw new TransitionReceiptError('INVALID_TRANSITION_RECEIPT', 'complete receipt has no valid input snapshot');
    }
    const { snapshot_hash: _storedHash, ...unhashed } = parsed.data;
    if (protocolSha256(stableJsonUtf8(unhashed)) !== parsed.data.snapshot_hash) {
        throw new TransitionReceiptError('INVALID_TRANSITION_RECEIPT', 'complete receipt input snapshot hash is invalid');
    }
    let current;
    try {
        const paths = parsed.data.files.map(file => resolvePath(runDir, file.path));
        current = completeInputSnapshot(runDir, paths);
    }
    catch {
        throw new TransitionReceiptError('INVALID_TRANSITION_RECEIPT', 'complete receipt input snapshot contains an unsafe path');
    }
    if (stableJsonUtf8(current) !== stableJsonUtf8(parsed.data)) {
        throw new TransitionReceiptError('FENCE_CONFLICT', `complete request ${record.request_id} external input bytes changed since the original application`);
    }
}
/** Prepare report/output/state inputs and immutable hashes outside the transition lock. */
export function prepareCompleteInputs(projectRoot, runId, sessionId, options) {
    const store = new SessionStore(projectRoot);
    const located = store.findRun(runId, sessionId);
    const replayRequestId = options.transition?.requestId?.trim();
    let replayRecord;
    if (replayRequestId) {
        const candidate = store.readBundle(located.sessionId).session.requests.find(item => (item.type === 'transition' && 'outcome' in item && item.request_id === replayRequestId));
        if (candidate) {
            const validated = validatePersistedTransitionRecord(candidate);
            if (validated.payload.operation !== 'complete'
                || validated.payload.subject.session_id !== located.sessionId
                || validated.payload.subject.run_id !== runId) {
                throw new TransitionReceiptError('REQUEST_CONFLICT', `request_id ${replayRequestId} was already used for another transition subject`);
            }
            assertCompleteReplayInputs(store.runDir(located.sessionId, runId), validated);
            replayRecord = validated;
        }
    }
    const resolved = contractForRun(projectRoot, located.run);
    const runDir = store.runDir(located.sessionId, runId);
    const sessionDir = store.sessionDir(located.sessionId);
    const scan = scanOutputs(runDir, sessionDir, resolved.contract);
    let chainProposal = null;
    if (!isFailureVerdict(options.chainVerdict)) {
        validateStrictArtifactContract(runDir, resolved.contract, scan);
        const proposals = validateChainProposalArtifacts(runDir, store.readBundle(located.sessionId), located.run, resolved.contract, scan, {
            preflight: replayRecord === undefined,
            validateCommand: (command, args) => assertDispatchableCommand(projectRoot, command, args),
        });
        if (options.chainProposal && options.applyChainProposal) {
            throw new Error('use either chainProposal or applyChainProposal, not both');
        }
        if (options.chainProposal)
            chainProposal = selectChainProposal(runDir, options.chainProposal, proposals);
        if (options.applyChainProposal) {
            if (proposals.length !== 1) {
                throw new Error(`--apply-proposal requires exactly one valid chain proposal (found ${proposals.length})`);
            }
            chainProposal = proposals[0];
        }
    }
    else if (options.chainProposal || options.applyChainProposal) {
        throw new Error('chain proposal cannot be applied with needs-retry or blocked verdict');
    }
    const extraArtifacts = discoverExtraArtifacts(runDir, sessionDir, options.extraArtifacts ?? []);
    const completionPaths = [
        join(runDir, 'report.md'),
        ...resolved.contract.produces.flatMap(item => item.path ? [join(runDir, item.path)] : []),
        ...scan.artifacts.map(item => item.absolutePath),
        ...extraArtifacts.map(item => item.absolutePath),
    ];
    const paths = new Set([
        join(runDir, 'run.json'),
        join(runDir, 'report.md'),
        join(runDir, 'outputs'),
        join(store.workflowRoot, 'state.json'),
        ...scan.artifacts.map(item => item.absolutePath),
        ...extraArtifacts.map(item => item.absolutePath),
    ]);
    const frontmatter = readReportFrontmatter(runDir);
    const knowledgeReconciliation = ensureKnowledgeReconciliation(projectRoot, located.sessionId, runId, frontmatter);
    return {
        projectRoot,
        sessionId: located.sessionId,
        runId,
        runDir,
        sessionDir,
        store,
        contract: resolved.contract,
        warning: resolved.warning,
        scan,
        extraArtifacts,
        frontmatter,
        state: projectState(projectRoot),
        options,
        files: [...paths].sort().map(path => ({ path, hash: preparedPathHash(path) })),
        completionInputSnapshot: completeInputSnapshot(runDir, completionPaths),
        chainProposal,
        knowledgeReconciliation,
    };
}
function revalidatePreparedCompleteInputs(prepared) {
    for (const file of prepared.files) {
        if (preparedPathHash(file.path) !== file.hash) {
            throw new TransitionReceiptError('FENCE_CONFLICT', `prepared completion input changed: ${file.path}`);
        }
    }
    if (!isKnowledgeReconciliationFresh(prepared.projectRoot, prepared.sessionId, prepared.runId, prepared.knowledgeReconciliation, prepared.frontmatter)) {
        throw new TransitionReceiptError('FENCE_CONFLICT', 'knowledge candidates or project corpus changed after reconciliation');
    }
}
/** Apply complete authority using only the prepared inputs and StoreTransaction. */
export function applyCompleteRunMutation(draft, tx, prepared) {
    const { store, runId, projectRoot, scan, frontmatter, options } = prepared;
    const run = tx.readRun(runId);
    if (options.requireRunningSession) {
        if (draft.session.status !== 'running') {
            throw new Error(`Session ${prepared.sessionId} is ${draft.session.status}; publishing requires running status`);
        }
        if (draft.session.active_run_id !== runId) {
            throw new Error(`Session ${prepared.sessionId} active Run is ${draft.session.active_run_id ?? '<none>'}; expected ${runId}`);
        }
    }
    if (run.status === 'sealed')
        throw new Error(`Run ${runId} is sealed and immutable`);
    const reuse = revalidateRunReuse(projectRoot, store, draft, run);
    scan.errors.push(...reuse.blockers.filter(blocker => !scan.errors.includes(blocker)));
    if (prepared.warning && !scan.warnings.includes(prepared.warning))
        scan.warnings.unshift(prepared.warning);
    run.status = 'completed';
    run.completed_at = localISO();
    const context = {
        projectRoot,
        runDir: prepared.runDir,
        session: draft.session,
        registry: draft.artifacts,
        scan,
        evidence: draft.evidence,
        reportDecisions: frontmatter.decisions.map(item => ({ id: item.id, status: item.status })),
        run,
    };
    const failureVerdict = isFailureVerdict(options.chainVerdict);
    const gates = failureVerdict
        ? skipExitGatesForFailedAttempt(draft, run)
        : evaluateRunGates(draft, run, context);
    const blocked = !failureVerdict && (scan.errors.length > 0 || gates.blocking.length > 0);
    draft.session.activity_revision++;
    if (blocked) {
        run.status = 'blocked';
        tx.writeRun(run);
        tx.writeJson(join(store.workflowRoot, 'state.json'), ensureSessionProjection(prepared.state, projectSessionEntry(draft.session)));
        return {
            run,
            result: {
                session_id: prepared.sessionId, run_id: runId, status: run.status, gates,
                artifacts: scanSummary(scan), warnings: scan.warnings, errors: scan.errors,
                upstream: reuse.upstream, reuse_assessments: reuse.assessments, sealed: false,
                primary_artifact_id: null, artifact_ids: [],
                next_action: {
                    suggest_only: true, action: 'repair_run', command: `maestro run check ${runId}`,
                    reason: 'Run gates are blocking; fix outputs before advancing the chain',
                    preconditions: ['repair blocking outputs or gates', 'run check must report no blocking gates'],
                },
                chain_transition: null,
                chain_proposal: null,
                knowledge: null,
            },
        };
    }
    const artifactIds = registerArtifacts(draft.artifacts, run, [...scan.artifacts, ...prepared.extraArtifacts]);
    const primary = artifactIds.find(id => draft.artifacts.artifacts[id]?.role === 'primary') ?? null;
    const evidenceRefs = recordCompletionEvidence(draft, run, artifactIds, frontmatter);
    run.output = { produces: artifactIds, primary_artifact_id: primary, verdict: frontmatter.verdict };
    run.handoff = deriveHandoff(frontmatter, runId, run.command.name, artifactIds, evidenceRefs);
    if (!run.handoff.summary.trim() && options.summaryFallback?.trim()) {
        run.handoff.summary = options.summaryFallback.trim();
    }
    mergeNotesIntoConcerns(run.handoff, options.notes ?? []);
    mergeDecisionsIntoHandoff(run.handoff, options.decisions ?? []);
    const knowledgeDelta = stageHandoffKnowledgeCandidates(store, tx, prepared.sessionId, run);
    applyAutomaticKnowledgeSuppression(knowledgeDelta, prepared.knowledgeReconciliation);
    if (knowledgeDelta) {
        tx.writeJson(runKnowledgeDeltaPath(store, prepared.sessionId, runId), knowledgeDelta, runKnowledgeDeltaSchema);
    }
    writeKnowledgeReconciliation(store, tx, prepared.knowledgeReconciliation);
    run.status = 'sealed';
    run.sealed_at = localISO();
    draft.session.latest_completed_run_id = runId;
    if (draft.session.active_run_id === runId)
        draft.session.active_run_id = null;
    const chainTransition = options.chainVerdict
        ? applyChainVerdict(draft.session, run, options.chainVerdict)
        : null;
    const chainProposal = prepared.chainProposal
        ? {
            proposal_id: prepared.chainProposal.proposal.proposal_id,
            path: prepared.chainProposal.path,
            status: 'applied',
            operations: applyChainProposal(draft, prepared.chainProposal.proposal),
        }
        : null;
    summarizeRegistry(draft.gates);
    tx.writeRun(run);
    tx.writeJson(join(store.workflowRoot, 'state.json'), ensureSessionProjection(prepared.state, projectSessionEntry(draft.session)));
    return {
        run,
        result: {
            session_id: prepared.sessionId, run_id: runId, status: run.status, gates,
            artifacts: scanSummary(scan), warnings: scan.warnings, errors: scan.errors,
            upstream: reuse.upstream, reuse_assessments: reuse.assessments, sealed: true,
            primary_artifact_id: primary, artifact_ids: artifactIds,
            next_action: completionNextPointer(draft.session, runId),
            chain_transition: chainTransition,
            chain_proposal: chainProposal,
            knowledge: {
                ...knowledgeCandidateReceipt(prepared.sessionId, knowledgeDelta),
                reconciliation: reconciliationSummary(prepared.knowledgeReconciliation),
            },
        },
    };
}
export function completeRun(projectRoot, runId, sessionId, options = {}) {
    const preparedInputs = prepareCompleteInputs(projectRoot, runId, sessionId, options);
    const { store } = preparedInputs;
    const initialBundle = store.readBundle(preparedInputs.sessionId);
    const requestId = options.transition?.requestId?.trim();
    const priorRecord = requestId
        ? initialBundle.session.requests.find(item => item.type === 'transition'
            && 'outcome' in item && item.request_id === requestId)
        : undefined;
    const priorSnapshot = priorRecord?.payload.payload.completion_input_snapshot;
    const prepared = prepareTransitionMutation({
        session: initialBundle.session,
        currentFence: store.readSessionFence(preparedInputs.sessionId, runId),
        operation: 'complete',
        subject: { session_id: preparedInputs.sessionId, run_id: runId, chain_step_id: store.readRun(preparedInputs.sessionId, runId).chain_step_id },
        payload: {
            run_id: runId,
            notes: options.notes ?? [],
            extra_artifacts: options.extraArtifacts ?? [],
            summary_fallback: options.summaryFallback ?? null,
            decisions: options.decisions ?? [],
            chain_verdict: options.chainVerdict ?? null,
            chain_proposal: preparedInputs.chainProposal
                ? {
                    path: preparedInputs.chainProposal.path,
                    proposal_id: preparedInputs.chainProposal.proposal.proposal_id,
                    content_hash: preparedInputs.chainProposal.artifact.contentHash,
                }
                : null,
            completion_input_snapshot: priorSnapshot ?? preparedInputs.completionInputSnapshot,
        },
        options: options.transition ?? { leaseClaim: options.leaseClaim },
    });
    const evaluated = store.replayOrApplyTransition(preparedInputs.sessionId, prepared.request, (draft, tx) => {
        assertTransitionMutationRevisions(draft.session, prepared.options);
        const leaseConflict = checkLease(draft.session.orchestration.lease, prepared.options.leaseClaim ?? {});
        if (leaseConflict)
            throw new Error(leaseConflict);
        if (draft.artifacts.revision !== prepared.request.preconditions.artifact_registry_revision) {
            throw new TransitionReceiptError('FENCE_CONFLICT', 'complete authority fence changed after preparation');
        }
        revalidatePreparedCompleteInputs(preparedInputs);
        const applied = applyCompleteRunMutation(draft, tx, preparedInputs);
        return createTransitionOutcome({
            request_id: prepared.request.request_id,
            request_hash: prepared.request.normalized_request_hash,
            operation: 'complete', status: 'applied', applied_at: new Date().toISOString(),
            subject: prepared.request.subject,
            postconditions: {
                session_identity_revision: draft.session.identity_revision,
                session_activity_revision: draft.session.activity_revision,
                active_run_id: draft.session.active_run_id,
                run_hash: protocolSha256(`${JSON.stringify(applied.run, null, 2)}\n`),
                artifact_registry_revision: draft.artifacts.revision,
            },
            exit_code: applied.result.sealed ? 0 : 1,
            error_code: applied.result.sealed ? null : 'RUN_GATES_BLOCKING',
            result: { value: applied.result },
        });
    }, record => assertCompleteReplayInputs(preparedInputs.runDir, record));
    return {
        ...structuredClone(evaluated.outcome.result.value),
        transition: transitionMutationReceipt(prepared.request, evaluated.outcome, evaluated.replayed),
    };
}
/**
 * Locate the chain step a Run is bound to (run_id match), or null when the Run is
 * not part of the session's predefined chain (an ad-hoc `run create`).
 */
function chainStepForRun(session, runId) {
    const chain = session.orchestration.chain;
    for (let i = 0; i < chain.length; i++) {
        if (chain[i].run_id === runId)
            return { index: i, step_id: chain[i].step_id };
    }
    return null;
}
/**
 * The next-step pointer after a verdict is applied, closing complete → next.
 * Reads the post-verdict session: a paused session (blocked verdict) points at
 * resuming; a pending execution step points at `run next`; a pending decision
 * node hands off to the orchestrator; a fully-drained chain points at
 * `run seal-session`.
 */
function completionNextPointer(session, completedRunId) {
    const sessionId = session.session_id;
    if (session.status === 'paused') {
        return {
            suggest_only: true,
            action: 'resolve_session',
            command: null,
            reason: 'session paused — dispatch is forbidden until the blocker or escalation is explicitly resolved',
            preconditions: ['resolve the named blocker or escalated decision', 'perform an authorized Session resume transition'],
        };
    }
    const reconcilable = completedRunId
        ? session.orchestration.chain.find(step => step.status === 'running' && step.run_id === completedRunId)
        : null;
    if (reconcilable) {
        return {
            suggest_only: true,
            action: 'dispatch_next',
            command: `maestro run next --session ${sessionId}`,
            reason: `Run ${completedRunId} is sealed; run next reconciles chain step ${reconcilable.step_id} before continuing`,
            preconditions: ['session_status=running', `chain_step=${reconcilable.step_id}`, `sealed_run_id=${completedRunId}`],
        };
    }
    if (nextPendingIndex(session, true) !== null) {
        return {
            suggest_only: true,
            action: 'dispatch_next',
            command: `maestro run next --session ${sessionId}`,
            reason: 'more pending steps — advance the chain',
            preconditions: ['session_status=running', 'active_run_id=null', 'no earlier pending decision'],
        };
    }
    if (nextPendingDecisionIndex(session) !== null) {
        return {
            suggest_only: true,
            action: 'evaluate_decision',
            command: `maestro run next --session ${sessionId}`,
            reason: 'next node is a decision — the orchestrator evaluates it',
            preconditions: ['session_status=running', 'decision remains pending'],
        };
    }
    return {
        suggest_only: true,
        action: 'seal_session',
        command: `maestro run seal-session ${sessionId}`,
        reason: 'all steps complete — seal the session',
        preconditions: ['all Runs are sealed', 'all chain steps are terminal'],
    };
}
/**
 * `run complete` with a chain-advancement verdict — the generic-layer equivalent
 * of `ralph complete <idx> --status <S>`. All four verdicts first run the
 * standard seal path (completeRun: derive handoff + register artifacts + seal the
 * Run), so run.json is sealed regardless of the chain outcome. The verdict then
 * drives the bound chain step:
 *
 *   done / done-with-concerns → step `sealed`   (terminal; matches next.ts
 *                                                 reconcileSealedSteps)
 *   needs-retry               → step `pending`, run_id cleared, retry.count++
 *   blocked                   → step `failed`,  session `paused`
 *
 * A non-chain Run (no chain step bound to its run_id) still seals and carries its
 * signals via the handoff, but the chain and session status are left untouched —
 * the verdict is advisory there, never an error.
 *
 * Signals ride the handoff (P3 single-source): reason (blocked) and an auto
 * done-with-concerns note fold into notes → handoff.concerns; decisions append to
 * handoff.decisions; evidence paths register as extra artifacts. No handoff
 * schema field is added — the verdict itself lives only in the chain transition.
 */
export function completeRunWithVerdict(projectRoot, runId, sessionId, options = {}) {
    const verdict = options.verdict ?? 'done';
    const store = new SessionStore(projectRoot);
    // Compose the notes channel: caller notes + blocked reason + an auto concern
    // for done-with-concerns when the caller left the notes empty (ralph appended a
    // `concerns` string on DONE_WITH_CONCERNS; here the equivalent is a handoff
    // concern so the signal survives on the P3 single-source).
    const notes = [...(options.notes ?? [])];
    if (verdict === 'blocked' && options.reason?.trim()) {
        notes.push(options.reason.trim());
    }
    if (verdict === 'done-with-concerns' && notes.length === 0) {
        notes.push('completed with concerns');
    }
    const seal = completeRun(projectRoot, runId, sessionId, {
        notes,
        extraArtifacts: options.extraArtifacts,
        summaryFallback: options.summaryFallback,
        decisions: options.decisions,
        leaseClaim: options.leaseClaim,
        chainVerdict: verdict,
        chainProposal: options.chainProposal,
        applyChainProposal: options.applyChainProposal,
        transition: options.transition,
    });
    const after = store.readBundle(sessionId).session;
    if (!seal.sealed) {
        const bound = chainStepForRun(after, runId);
        const current = bound ? after.orchestration.chain[bound.index] : null;
        return {
            session_id: sessionId,
            run_id: runId,
            verdict,
            run_sealed: false,
            chain: current ? {
                step_id: current.step_id,
                index: bound.index,
                step_status: current.status,
                retry: current.retry ? { ...current.retry, exhausted: current.retry.count >= current.retry.max } : null,
            } : null,
            session_status: after.status,
            next: {
                suggest_only: true,
                action: 'repair_run',
                command: `maestro run check ${runId}`,
                reason: 'Run gates are blocking; fix outputs before advancing the chain',
                preconditions: ['repair blocking outputs or gates', 'run check must report no blocking gates'],
            },
            seal,
        };
    }
    const transition = seal.chain_transition ?? null;
    if (!transition) {
        return {
            session_id: sessionId,
            run_id: runId,
            verdict,
            run_sealed: seal.sealed,
            chain: null,
            session_status: after.status,
            next: completionNextPointer(after),
            seal,
        };
    }
    return {
        session_id: sessionId,
        run_id: runId,
        verdict,
        run_sealed: seal.sealed,
        chain: {
            step_id: transition.step_id,
            index: transition.index,
            step_status: transition.step_status,
            retry: transition.retry,
        },
        session_status: after.status,
        next: completionNextPointer(after),
        seal,
    };
}
export function summarizeRunMode(raw) {
    const lines = raw
        .split(/\r?\n/)
        .map(line => line.trim())
        .filter(line => line.length > 0 && !line.startsWith('#'));
    return lines.slice(0, 8).join('\n');
}
// ---------------------------------------------------------------------------
// Goal mode — prepare frontmatter 声明 `goal: true` 的 step，加载时按平台附带
// goal 设置提示词。Goal 工具是 LLM 内置工具，不检测可用性——LLM 能调就调。
// ---------------------------------------------------------------------------
const GOAL_MODE_BLOCKS = {
    claude: [
        'Goal 模式（该 step 声明 goal 标志）：',
        '1. Session 创建后，输出 Goal Prompt 供用户设定终止条件（非阻塞，继续执行）：',
        '   📋 可随时复制以下 /goal 设定终止条件（执行过程中输入即可）：',
        '   /goal 完成以下子目标：',
        '   {逐条列出 decomposition.goals 中 status!=superseded 的 id: goal — 完成条件: done_when}',
        '   直到 session 的 decomposition.goals 全部 done 且 chain steps 全部 sealed 才停。',
        '2. 用户输入 /goal 后由 harness 管理终止条件，LLM 无需额外操作。',
        '3. 若用户未输入 /goal，不影响执行流程。',
    ].join('\n'),
    codex: [
        'Goal 模式（该 step 声明 goal 标志）：',
        '1. Session 创建后 call `create_goal({ objective: "{intent}", success_criteria: [decomposition.goals 各 done_when] })`；单一活跃 goal，若已有未完成 goal 先收口。',
        '2. 过程中可用 `get_goal({})` 查看进度与剩余 token 预算。',
        '3. 全部子目标完成时 `update_goal({ status: "complete" })`；阻塞时 `update_goal({ status: "blocked" })`。',
        '4. 完成后向用户报告最终状态。',
    ].join('\n'),
    pi: [
        'Goal 模式（该 step 声明 goal 标志）：',
        '1. Session 创建后 call `goal({ action: "create", objective: "{intent}" })`。',
        '2. 过程中可用 `goal({ action: "get" })` 查看状态。',
        '3. 全部子目标完成时 `goal({ action: "complete", summary: "..." })`。',
    ].join('\n'),
    'agents-standard': [
        'Goal 模式（该 step 声明 goal 标志）：',
        '1. Session 创建后 call `create_task({ subject: "Session: {intent}", description: "完成条件: {decomposition.goals 各 done_when 汇总}" })` 作为 session goal。',
        '2. 各子目标完成时 update_task 标记 completed。',
        '3. 全部完成时 update_task session goal 为 completed。',
    ].join('\n'),
};
function extractGoalFlag(raw) {
    const fm = raw.match(/^---\s*\r?\n([\s\S]*?)\r?\n---/);
    if (!fm)
        return false;
    return /^goal:\s*true\s*$/m.test(fm[1]);
}
function resolveGoalMode(prepareRaw, platform) {
    if (!prepareRaw || !extractGoalFlag(prepareRaw))
        return null;
    const block = GOAL_MODE_BLOCKS[platform];
    return block ? { platform, instructions: block } : null;
}
/**
 * Read-only prior-step context for `run prepare --session`: the latest completed
 * Run's handoff plus the present state of each contract-declared consume alias.
 * Never mutates state and never creates directories.
 */
function preparePreviousContext(projectRoot, stepName, sessionId) {
    const store = new SessionStore(projectRoot);
    if (!store.sessionExists(sessionId)) {
        return { handoff: null, consumes: [], upstream: {}, reuse_assessments: [], selected_refs: [] };
    }
    const bundle = store.readBundle(sessionId);
    const handoff = handoffByLatestCompleted(store, bundle.session);
    const contract = resolveCommandSource(projectRoot, stepName).contract;
    const reuse = assessSessionReuse(projectRoot, sessionId, stepName);
    const consumes = contract.consumes.map(consume => {
        const selected = Object.entries(reuse.upstream).find(([alias, item]) => (consume.alias ? alias === consume.alias : item.kind === consume.kind));
        const alias = selected?.[0] ?? consume.alias ?? null;
        const artifactId = selected?.[1].artifact_id;
        const artifact = artifactId ? bundle.artifacts.artifacts[artifactId] : undefined;
        return {
            alias,
            kind: consume.kind,
            required: consume.required,
            present: Boolean(artifact),
            status: artifact ? (artifact.status === 'sealed' ? 'sealed' : 'draft') : null,
            path: artifact ? `sessions/${sessionId}/${artifact.relative_path}` : null,
        };
    });
    const selectedRefs = Object.entries(reuse.upstream).map(([alias, item]) => ({
        alias,
        artifact_id: item.artifact_id,
        path: item.path,
        assessment_hash: reuse.assessments.find(assessment => assessment.source_fence.artifact_id === item.artifact_id)?.assessment_hash ?? '',
    }));
    return {
        handoff,
        consumes,
        upstream: reuse.upstream,
        reuse_assessments: reuse.assessments,
        selected_refs: selectedRefs,
    };
}
function prepareStepHint(step, index) {
    return {
        index,
        step_id: step.step_id,
        command: step.command,
        status: step.status,
        run_id: step.run_id,
        decision_ref: step.decision_ref,
    };
}
function prepareSessionGuidance(projectRoot, sessionId) {
    const store = new SessionStore(projectRoot);
    if (!store.sessionExists(sessionId)) {
        return {
            session_id: sessionId,
            status: 'missing',
            active_run_id: null,
            latest_completed_run_id: null,
            current_step: null,
            next_pending_step: null,
            open_decisions: [],
            reminders: [`Session ${sessionId} was not found; create or select a Session before relying on prior context.`],
            next: { command: null, reason: 'Session not found' },
        };
    }
    const session = store.readBundle(sessionId).session;
    const knowledgeSummary = summarizeSessionKnowledge(projectRoot, sessionId, { readOnly: true });
    const pendingKnowledge = knowledgeSummary.candidates
        .filter(candidate => candidate.status === 'pending');
    const promotingKnowledge = knowledgeSummary.candidates
        .filter(candidate => candidate.status === 'promoting');
    const reconciliationPolicies = knowledgeSummary.candidates.map(candidate => {
        const policies = reconciliationForCandidate(projectRoot, sessionId, candidate.run_ids, candidate.candidate_id);
        return {
            missing: policies.length < candidate.run_ids.length,
            policy: policies.find(item => item.promotion_eligibility === 'suppressed')
                ?? policies.find(item => item.promotion_eligibility === 'review_required')
                ?? policies[0]
                ?? null,
        };
    });
    const reviewRequiredKnowledge = reconciliationPolicies
        .filter(item => item.policy?.promotion_eligibility === 'review_required').length;
    const conflictKnowledge = reconciliationPolicies
        .filter(item => item.policy?.disposition === 'potential_conflict').length;
    const suppressedKnowledge = reconciliationPolicies
        .filter(item => item.policy?.promotion_eligibility === 'suppressed').length;
    const missingReconciliation = reconciliationPolicies.filter(item => item.missing).length;
    const chain = session.orchestration.chain;
    const activeIndex = activeStepIndex(session);
    const nextExecutionIndex = nextPendingIndex(session, true);
    const nextDecisionIndex = nextPendingDecisionIndex(session);
    const currentStep = activeIndex === null ? null : prepareStepHint(chain[activeIndex], activeIndex);
    const nextPendingStep = nextExecutionIndex === null ? null : prepareStepHint(chain[nextExecutionIndex], nextExecutionIndex);
    const openDecisions = session.orchestration.decision_points
        .filter(point => point.status !== 'passed')
        .map(point => ({
        point_id: point.point_id,
        after_step_id: point.after_step_id,
        status: point.status,
        retry_count: point.retry_count,
        max_retries: point.max_retries,
        evidence_ref: point.evidence_ref,
    }));
    const reminders = [];
    let next;
    if (session.status !== 'running') {
        const escalated = openDecisions.filter(point => point.status === 'escalated').map(point => point.point_id);
        if (escalated.length > 0)
            reminders.push(`Resolve escalated decision(s): ${escalated.join(', ')}.`);
        next = {
            command: null,
            reason: `session ${session.session_id} is ${session.status}; resolve or resume Session authority before continuing`,
        };
    }
    else if (session.active_run_id && activeIndex === null) {
        reminders.push(`Re-attach active Run ${session.active_run_id} instead of creating a new Run.`);
        next = {
            command: `maestro run brief ${session.active_run_id} --session ${session.session_id}`,
            reason: `session already has active Run ${session.active_run_id}`,
        };
    }
    else if (activeIndex !== null) {
        const activeRunId = chain[activeIndex].run_id ?? session.active_run_id;
        reminders.push(`Finish active chain step ${chain[activeIndex].step_id} before dispatching another step.`);
        next = {
            command: activeRunId ? `maestro run check ${activeRunId}` : null,
            reason: 'active chain step is still running',
        };
    }
    else if (nextDecisionIndex !== null && (nextExecutionIndex === null || nextDecisionIndex < nextExecutionIndex)) {
        const decision = chain[nextDecisionIndex];
        reminders.push(`Review decision node ${decision.decision_ref ?? decision.step_id} before later execution steps.`);
        next = {
            command: `maestro run next --session ${session.session_id}`,
            reason: `next chain node is unresolved decision ${decision.decision_ref}`,
        };
    }
    else if (nextExecutionIndex !== null) {
        next = {
            command: `maestro run next --session ${session.session_id}`,
            reason: `next pending step is ${chain[nextExecutionIndex].step_id}`,
        };
    }
    else {
        reminders.push('No pending chain execution step remains; seal the Session after reviewing the knowledge candidate backlog.');
        next = {
            command: `maestro run seal-session ${session.session_id}`,
            reason: 'chain has no pending execution steps',
        };
    }
    if (openDecisions.length > 0 && !reminders.some(item => item.includes('decision'))) {
        reminders.push(`Open decision(s): ${openDecisions.map(point => point.point_id).join(', ')}.`);
    }
    if (pendingKnowledge.length > 0 || promotingKnowledge.length > 0) {
        reminders.push(`Knowledge backlog: ${pendingKnowledge.length} pending, ${promotingKnowledge.length} promoting; `
            + `review with \`maestro knowledge review ${sessionId}\`.`);
    }
    if (reviewRequiredKnowledge > 0 || missingReconciliation > 0) {
        reminders.push(`Knowledge reconciliation: ${reviewRequiredKnowledge} require review, `
            + `${conflictKnowledge} potential conflicts, ${missingReconciliation} missing receipts; `
            + `inspect with \`maestro knowledge review ${sessionId}\`.`);
    }
    return {
        session_id: session.session_id,
        status: session.status,
        active_run_id: session.active_run_id,
        latest_completed_run_id: session.latest_completed_run_id,
        current_step: currentStep,
        next_pending_step: nextPendingStep,
        open_decisions: openDecisions,
        knowledge: {
            unique_inputs: knowledgeSummary.unique_inputs,
            pending_candidates: pendingKnowledge.length,
            corroborated_candidates: pendingKnowledge
                .filter(candidate => candidate.stage === 'corroborated').length,
            promoting_candidates: promotingKnowledge.length,
            review_required_candidates: reviewRequiredKnowledge,
            conflict_candidates: conflictKnowledge,
            suppressed_candidates: suppressedKnowledge,
            missing_reconciliation_candidates: missingReconciliation,
            review_command: `maestro knowledge review ${sessionId}`,
        },
        reminders,
        next,
    };
}
export function prepareStep(projectRoot, stepName, platform, sessionId) {
    const suffix = platform ? PLATFORM_SUFFIX[platform] : undefined;
    const content = resolveStepContent(projectRoot, stepName, suffix);
    const tx = (raw) => platform ? transformContentForPlatform(raw, platform) : raw;
    const result = {
        step: stepName,
        platform: platform ?? 'claude',
        prepare: content.prepare ? { path: content.prepare.path, content: tx(content.prepare.raw) } : null,
        workflow: content.workflow
            ? { path: content.workflow.path, line_count: content.workflow.raw.split(/\r?\n/).length }
            : null,
        run_mode: content.runMode
            ? { path: content.runMode.path, summary: summarizeRunMode(content.runMode.raw) }
            : null,
        refs: content.refs,
        goal_mode: resolveGoalMode(content.prepare?.raw, platform ?? 'claude'),
    };
    if (sessionId) {
        result.previous = preparePreviousContext(projectRoot, stepName, sessionId);
        result.session_guidance = prepareSessionGuidance(projectRoot, sessionId);
    }
    return result;
}
export function skillContent(projectRoot, stepName, platform) {
    const suffix = platform ? PLATFORM_SUFFIX[platform] : undefined;
    const content = resolveStepContent(projectRoot, stepName, suffix);
    const tx = (raw) => platform ? transformContentForPlatform(raw, platform) : raw;
    return {
        step: stepName,
        platform: platform ?? 'claude',
        prepare: content.prepare ? { path: content.prepare.path, content: tx(content.prepare.raw) } : null,
        workflow: content.workflow
            ? { path: content.workflow.path, content: tx(content.workflow.raw) }
            : null,
        refs: content.refs,
        goal_mode: resolveGoalMode(content.prepare?.raw, platform ?? 'claude'),
    };
}
export function briefRun(projectRoot, runId, sessionId, platform) {
    const context = resolveRunContextFull(projectRoot, runId, sessionId, platform);
    const { store, bundle, run } = context;
    const resolvedPlatform = context.resolved_platform;
    const suffix = PLATFORM_SUFFIX[resolvedPlatform];
    const content = resolveStepContent(projectRoot, run.command.name, suffix);
    const tx = (raw) => transformContentForPlatform(raw, resolvedPlatform);
    const outputs = run.output.produces
        .map(id => {
        const artifact = bundle.artifacts.artifacts[id];
        if (!artifact)
            return null;
        return {
            artifact_id: id,
            kind: artifact.kind,
            role: artifact.role,
            path: artifact.relative_path,
            status: artifact.status,
        };
    })
        .filter((item) => item !== null);
    const resolvedContract = contractForRun(projectRoot, run);
    const contract = resolvedContract.contract;
    const validatedReuse = revalidateRunReuse(projectRoot, store, bundle, run, contract);
    const upstream = validatedReuse.upstream;
    const prevHandoff = handoffBeforeSequence(store, bundle.session, run.sequence);
    const anchor = buildAnchorSections(store, bundle.session);
    const freshness = guidanceFreshness(projectRoot, run);
    const argumentRequirements = resolveArgumentRequirements(projectRoot, run.command.name, run.input.args);
    const reuseAssessments = validatedReuse.assessments;
    const inputs = contract.consumes.map(consume => ({
        kind: consume.kind,
        alias: consume.alias ?? null,
        required: consume.required,
        require_status: consume.require_status ?? null,
        schema: consume.schema ?? null,
        resolved: consume.alias
            ? upstream[consume.alias] ?? null
            : Object.values(upstream).find(item => item.kind === consume.kind) ?? null,
    }));
    const declaredOutputs = contract.produces.map(produce => ({
        kind: produce.kind,
        alias: produce.alias ?? null,
        role: produce.role ?? (produce.primary ? 'primary' : 'attachment'),
        required: produce.required ?? false,
        primary: produce.primary,
        path: produce.path ?? null,
        schema: typeof produce.schema === 'string' ? produce.schema : null,
    }));
    const gateItems = run.gate_ids
        .map(gateId => {
        const gate = bundle.gates.gates[gateId];
        return gate ? {
            gate_id: gateId,
            title: gate.title,
            scope: gate.scope,
            status: gate.status,
            required: gate.required,
            blocking: gate.blocking,
        } : null;
    })
        .filter((item) => item !== null);
    const executionContract = executionContractV11Schema.parse({
        schema_version: 'execution-contract/1.1',
        command: run.command.name,
        invocation: { args: [...run.input.args] },
        guidance: {
            prepare_path: content.prepare?.path ?? null,
            workflow_path: content.workflow?.path ?? null,
            run_mode_path: content.runMode?.path ?? null,
        },
        inputs,
        outputs: { declared: declaredOutputs, actual: outputs },
        gates: { registry_revision: bundle.gates.revision, items: gateItems },
        contract: {
            version: run.contract_snapshot?.contract_version
                ?? (contract.contract_version === 2.1
                    ? 'command-contract/2.1'
                    : contract.contract_version === 2 ? 'command-contract/2.0' : 'command-contract/1.0'),
            snapshot_hash: run.contract_snapshot?.snapshot_hash ?? null,
            warnings: contract.compatibility_warnings ?? [],
            drift: resolvedContract.warning ? 'prompt-only' : 'none',
        },
        freshness: {
            captured_at: localISO(),
            run_context_identity_revision: run.input.context_identity_revision,
            session_identity_revision: bundle.session.identity_revision,
            session_activity_revision: bundle.session.activity_revision,
            identity_current: run.input.context_identity_revision === bundle.session.identity_revision,
            command_contract_hash: run.command.contract_hash ?? null,
        },
        argument_requirements: argumentRequirements,
        reuse_assessments: reuseAssessments,
        orchestration: { chain_effects: [...(contract.orchestration?.chain_effects ?? [])] },
    });
    return briefResultV11Schema.parse({
        schema_version: 'brief-result/1.1',
        session_id: context.session_id,
        run_id: runId,
        run_dir: context.run_dir,
        upstream,
        session: {
            session_id: context.session_id,
            intent: bundle.session.intent,
            status: bundle.session.status,
            identity_revision: bundle.session.identity_revision,
            activity_revision: bundle.session.activity_revision,
            active_run_id: bundle.session.active_run_id,
            open_decisions: bundle.session.orchestration.decision_points
                .filter(point => point.status !== 'passed'),
        },
        run: {
            run_id: runId,
            run_dir: context.run_dir,
            chain_step_id: context.chain_step_id,
            resolved_platform: resolvedPlatform,
            status: run.status,
        },
        guidance: {
            prepare: content.prepare
                ? { path: content.prepare.path, content: tx(content.prepare.raw) }
                : null,
            workflow: content.workflow
                ? { path: content.workflow.path, content: tx(content.workflow.raw) }
                : null,
            run_mode: content.runMode
                ? { path: content.runMode.path, hash: protocolSha256(content.runMode.raw) }
                : null,
            refs: content.refs,
            goal_mode: resolveGoalMode(content.prepare?.raw, resolvedPlatform),
            freshness,
        },
        execution_contract: executionContract,
        knowledge_context: (() => {
            const card = buildKnowledgeReconciliationCard(projectRoot, context.session_id, runId);
            const receipt = readKnowledgeReconciliation(store, context.session_id, runId, true);
            const fresh = receipt
                ? isKnowledgeReconciliationFresh(projectRoot, context.session_id, runId, receipt, readReportFrontmatter(context.run_dir))
                : false;
            return {
                ...card,
                reconciliation: {
                    status: receipt ? (fresh ? 'fresh' : 'stale') : 'missing',
                    duplicates: receipt?.counts.duplicates ?? 0,
                    conflicts: receipt?.counts.conflicts ?? 0,
                    review_required: receipt?.counts.review_required ?? 0,
                    suppressed: receipt?.counts.suppressed ?? 0,
                    command: `maestro knowledge review ${context.session_id} --refresh`,
                },
            };
        })(),
        continuity: { prev_handoff: prevHandoff, anchor },
        recovery: { next: briefNext(bundle.session, runId, run.status) },
    });
}
/**
 * Next lifecycle verb after `run brief`, closing next→brief→check→complete
 * (plan P2.5/G4). A live Run points at `run check` (pre-completion gate check —
 * does not seal); a sealed Run points at `run next` to advance the chain.
 */
function briefNext(session, runId, status) {
    if (session.status !== 'running') {
        return {
            suggest_only: true,
            command: null,
            reason: `session ${session.session_id} is ${session.status}; resolve or resume Session authority before continuing`,
        };
    }
    if (session.active_run_id && session.active_run_id !== runId) {
        return {
            suggest_only: true,
            command: `maestro run brief ${session.active_run_id} --session ${session.session_id}`,
            reason: `session already has active Run ${session.active_run_id}; re-attach it instead of allocating another Run`,
        };
    }
    if (status === 'sealed' || status === 'completed') {
        const nextExecutionIndex = nextPendingIndex(session, true);
        const decisionIndex = nextPendingDecisionIndex(session);
        if (decisionIndex !== null && (nextExecutionIndex === null || decisionIndex < nextExecutionIndex)) {
            const decision = session.orchestration.chain[decisionIndex];
            return {
                suggest_only: true,
                command: `maestro run next --session ${session.session_id}`,
                reason: `next chain node is unresolved decision ${decision.decision_ref}; run next surfaces its decision card without allocating a Run`,
            };
        }
        return {
            suggest_only: true,
            command: `maestro run next --session ${session.session_id}`,
            reason: 'run sealed — advance the chain',
        };
    }
    return {
        suggest_only: true,
        command: `maestro run check ${runId}`,
        reason: `pre-completion gate check (does not seal); when clean it emits the finish checklist — work through it, then run: maestro run complete ${runId}`,
    };
}
//# sourceMappingURL=runtime.js.map