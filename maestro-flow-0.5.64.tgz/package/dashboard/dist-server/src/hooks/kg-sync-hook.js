/**
 * KG Sync Hook — UserPromptSubmit
 *
 * Silently syncs the Knowledge Graph when source files have changed.
 * Change detection: dirty source files (git status) OR HEAD moved since the
 * last successful sync (covers commit / pull / branch switch, which leave a
 * clean working tree). Uses CooldownGuard for cross-process debouncing.
 */
import { execSync, spawn } from 'node:child_process';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { kgSyncGuard } from '../utils/cooldown-guard.js';
import { invalidateSearchIndex } from '../search/daemon-client.js';
import { readSyncState, getGitHead } from '../graph/kg/sync-state.js';
const SOURCE_EXTENSIONS = new Set([
    '.ts', '.tsx', '.js', '.jsx', '.py', '.go', '.rs', '.java',
]);
/**
 * Set on the detached worker that performs the actual sync. The hook fires on
 * UserPromptSubmit, where a full tree-sitter re-index costs tens of seconds — far
 * beyond an interactive budget — so the prompt-side invocation only does the cheap
 * change detection and hands the heavy work to a background copy of itself.
 *
 * This preserves the observable contract: the hook writes nothing to stdout, and
 * the UserPromptSubmit hooks already run as independent parallel processes, so no
 * consumer ever had an ordering guarantee against this sync.
 */
const WORKER_ENV = 'MAESTRO_KG_SYNC_WORKER';
/** Advisory single-flight marker for the detached worker. */
const WORKER_PID_FILE = 'kg-sync-worker.pid';
/**
 * Mirrors `getKgDatabasePath` (src/graph/kg/db/connection.ts) so the not-initialized
 * and cooldown gates can run without importing it — that module pulls in
 * `node:sqlite` and the whole graph engine, ~60ms this hook has no use for on the
 * ~29/30 prompts that are inside the cooldown window.
 */
function hasKgDatabase(projectPath) {
    return existsSync(resolve(projectPath, '.workflow', 'kg', 'maestro.db'));
}
// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------
export async function evaluateKgSync(projectPath, sessionId) {
    try {
        if (!hasKgDatabase(projectPath)) {
            return { synced: false, reason: 'maestrograph-not-initialized' };
        }
        // The worker was already authorized by the prompt-side invocation that spawned
        // it — re-running the guard there would let the parent's own cooldown mark
        // cancel the work it just delegated.
        if (process.env[WORKER_ENV] !== '1') {
            if (!kgSyncGuard.shouldRun(sessionId)) {
                return { synced: false, reason: 'cooldown' };
            }
            if (!detectSourceChanges(projectPath) && !headMovedSinceLastSync(projectPath)) {
                kgSyncGuard.markDone(sessionId);
                return { synced: false, reason: 'no-changes' };
            }
            // Hot path: delegate and return. Falls through to a synchronous sync when
            // no worker could be spawned, so the graph is never left silently stale.
            if (spawnSyncWorker(projectPath, sessionId)) {
                kgSyncGuard.markDone(sessionId);
                return { synced: false, reason: 'delegated' };
            }
        }
        const start = Date.now();
        const { MaestroGraph } = await import('../graph/kg/engine.js');
        const mg = await MaestroGraph.open(projectPath);
        let filesChanged = 0;
        try {
            const results = await mg.sync();
            filesChanged = results.reduce((sum, r) => sum + r.nodesAdded + r.nodesRemoved, 0);
            kgSyncGuard.markDone(sessionId);
        }
        finally {
            mg.close();
        }
        if (filesChanged > 0) {
            invalidateSearchIndex(resolve(projectPath, '.workflow')).catch(() => { });
            import('../graph/kg/engine.js').then(({ MaestroGraph: MG }) => MG.open(projectPath).then(mg2 => mg2.buildCodeEmbeddings().catch((e) => {
                if (process.env.MAESTRO_DEBUG === '1') {
                    console.warn(`[kg-sync] code embedding build failed: ${e instanceof Error ? e.message : e}`);
                }
            }).finally(() => mg2.close()))).catch(() => { });
        }
        return { synced: true, filesChanged, durationMs: Date.now() - start };
    }
    catch (e) {
        if (process.env.MAESTRO_DEBUG === '1') {
            console.error(`[kg-sync] sync failed: ${e instanceof Error ? e.message : e}`);
        }
        return { synced: false, reason: 'sync-error' };
    }
}
// ---------------------------------------------------------------------------
// Internal
// ---------------------------------------------------------------------------
/**
 * Re-invoke this same hook as a detached background process that owns the heavy
 * sync. Best-effort: on any failure the caller falls through to a synchronous
 * sync, so the graph is never silently left stale.
 *
 * Returns false when no usable CLI entry point could be resolved.
 */
function spawnSyncWorker(projectPath, sessionId) {
    const entry = process.argv[1];
    if (!entry || !/\.[cm]?js$/.test(entry))
        return false;
    if (workerAlreadyRunning(projectPath))
        return true;
    try {
        const child = spawn(process.execPath, [entry, 'hooks', 'run', 'kg-sync'], {
            cwd: projectPath,
            env: { ...process.env, [WORKER_ENV]: '1' },
            detached: true,
            stdio: ['pipe', 'ignore', 'ignore'],
            windowsHide: true,
        });
        child.stdin?.end(JSON.stringify({ session_id: sessionId, cwd: projectPath }));
        child.unref();
        if (child.pid) {
            try {
                writeFileSync(workerPidPath(projectPath), String(child.pid));
            }
            catch { /* advisory only */ }
        }
        return true;
    }
    catch {
        return false;
    }
}
function workerPidPath(projectPath) {
    return resolve(projectPath, '.workflow', WORKER_PID_FILE);
}
/**
 * Single-flight guard. A sync runs far longer than the cooldown window, so
 * without this every cooldown expiry would stack another concurrent indexer on
 * top of the one still running. Advisory: a missing or stale pid file simply
 * allows the spawn.
 */
function workerAlreadyRunning(projectPath) {
    try {
        const pid = parseInt(readFileSync(workerPidPath(projectPath), 'utf-8').trim(), 10);
        if (!Number.isInteger(pid) || pid <= 0)
            return false;
        process.kill(pid, 0);
        return true;
    }
    catch {
        return false;
    }
}
/**
 * True when git HEAD differs from the recorded sync watermark — catches
 * committed changes that git status cannot see. Missing watermark counts
 * as moved so pre-watermark databases self-heal with one sync.
 */
function headMovedSinceLastSync(projectPath) {
    const head = getGitHead(projectPath);
    if (!head)
        return false;
    return readSyncState(projectPath)?.lastSyncHead !== head;
}
function detectSourceChanges(projectPath) {
    try {
        const output = execSync('git status --porcelain', {
            cwd: projectPath,
            encoding: 'utf-8',
            timeout: 5000,
            stdio: ['pipe', 'pipe', 'pipe'],
        });
        if (!output.trim())
            return false;
        for (const line of output.trim().split('\n')) {
            const filePath = line.slice(3).trim();
            const actualPath = filePath.includes(' -> ') ? filePath.split(' -> ')[1] : filePath;
            const dotIdx = actualPath.lastIndexOf('.');
            if (dotIdx >= 0 && SOURCE_EXTENSIONS.has(actualPath.slice(dotIdx).toLowerCase()))
                return true;
        }
        return false;
    }
    catch {
        return false;
    }
}
//# sourceMappingURL=kg-sync-hook.js.map