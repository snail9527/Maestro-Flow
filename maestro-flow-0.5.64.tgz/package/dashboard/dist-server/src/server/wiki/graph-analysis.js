const LINK_RE = /\[\[([^\]]+)\]\]/g;
/**
 * Compute forward links + broken links from the current index. Backlinks are
 * already computed by WikiIndexer; we reuse them so the graph is consistent.
 */
export function buildGraph(index) {
    const forwardLinks = {};
    const broken = [];
    const titleIndex = new Map();
    for (const d of index.entries)
        titleIndex.set(d.title.toLowerCase(), d.id);
    const resolve = (target) => {
        if (index.byId[target])
            return target;
        const hit = titleIndex.get(target.toLowerCase());
        return hit ?? null;
    };
    const pushFwd = (source, targetId) => {
        if (!forwardLinks[source])
            forwardLinks[source] = [];
        if (!forwardLinks[source].includes(targetId))
            forwardLinks[source].push(targetId);
    };
    for (const d of index.entries) {
        // `related` frontmatter
        for (const rel of d.related) {
            const hit = resolve(rel);
            if (hit)
                pushFwd(d.id, hit);
            else
                broken.push({ sourceId: d.id, target: rel });
        }
        // inline body wikilinks
        if (d.body) {
            LINK_RE.lastIndex = 0;
            let m;
            while ((m = LINK_RE.exec(d.body))) {
                const hit = resolve(m[1]);
                if (hit)
                    pushFwd(d.id, hit);
                else
                    broken.push({ sourceId: d.id, target: m[1] });
            }
        }
    }
    return {
        forwardLinks,
        backlinks: index.backlinks,
        brokenLinks: broken,
    };
}
/**
 * Entries with zero incoming and zero outgoing resolved links.
 * Virtual entries are excluded — they have no body and no `related`, and would
 * flood the list.
 */
export function detectOrphans(graph, entries) {
    const out = [];
    for (const d of entries) {
        if (d.source.kind === 'virtual')
            continue;
        const outgoing = graph.forwardLinks[d.id]?.length ?? 0;
        const incoming = graph.backlinks[d.id]?.length ?? 0;
        if (outgoing === 0 && incoming === 0)
            out.push(d.id);
    }
    return out;
}
export function detectHubs(graph, topN = 10) {
    const ranked = Object.entries(graph.backlinks)
        .map(([id, sources]) => ({ id, inDegree: sources.length }))
        .sort((a, b) => b.inDegree - a.inDegree || a.id.localeCompare(b.id));
    return ranked.slice(0, topN);
}
export function detectDeadEnds(graph) {
    return graph.brokenLinks.slice();
}
/**
 * Heuristic health score: 100 minus weighted counts of broken links,
 * orphaned entries, and entries missing titles. Floored at 0.
 */
export function computeHealth(index, graph) {
    const orphans = detectOrphans(graph, index.entries);
    const hubs = detectHubs(graph, 10);
    const missingTitles = index.entries.filter((d) => d.source.kind === 'file' && (!d.title || d.title === d.id.split('-').slice(1).join('-'))).length;
    const brokenLinks = graph.brokenLinks;
    const rawScore = 100 - 2 * brokenLinks.length - 1 * orphans.length - 3 * missingTitles;
    const score = Math.max(0, Math.min(100, rawScore));
    return {
        score,
        totals: {
            entries: index.entries.length,
            brokenLinks: brokenLinks.length,
            orphans: orphans.length,
            missingTitles,
        },
        orphans,
        hubs,
        brokenLinks,
        lastUpdated: index.generatedAt,
    };
}
//# sourceMappingURL=graph-analysis.js.map