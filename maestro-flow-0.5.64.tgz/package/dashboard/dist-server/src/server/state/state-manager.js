import { readdir } from 'node:fs/promises';
import { join, relative, resolve } from 'node:path';
import { SSE_EVENT_TYPES } from '../../shared/constants.js';
import { readJsonSafe } from './file-reader.js';
import { toForwardSlash } from '../../shared/utils.js';
// ---------------------------------------------------------------------------
// StateManager — in-memory projection of .workflow/ directory
// ---------------------------------------------------------------------------
export class StateManager {
    workflowRoot;
    eventBus;
    board;
    /** Cache: phase number → directory path for O(1) lookups */
    phaseDirCache = new Map();
    isSwitching = false;
    constructor(workflowRoot, eventBus) {
        this.workflowRoot = workflowRoot;
        this.eventBus = eventBus;
        this.board = emptyBoard();
    }
    /** Return current workspace project root (parent of .workflow/) */
    getWorkspaceRoot() {
        return resolve(this.workflowRoot, '..');
    }
    /** Return current .workflow/ directory path (updates on workspace switch) */
    getWorkflowRoot() {
        return this.workflowRoot;
    }
    /** Return current board state snapshot */
    getBoard() {
        return this.board;
    }
    /** Return project state */
    getProject() {
        return this.board.project;
    }
    /** Return a specific phase by number, or undefined */
    getPhase(n) {
        return this.board.phases.find((p) => p.phase === n);
    }
    /** Return tasks for a given phase number */
    async getTasks(phaseNum) {
        // Use cached directory path if available
        const cached = this.phaseDirCache.get(phaseNum);
        if (cached)
            return readPhaseTasks(cached);
        const phaseDir = await findPhaseDir(this.workflowRoot, phaseNum);
        if (!phaseDir)
            return [];
        this.phaseDirCache.set(phaseNum, phaseDir);
        return readPhaseTasks(phaseDir);
    }
    // -------------------------------------------------------------------------
    // Full state build — scans the entire .workflow/ directory
    // -------------------------------------------------------------------------
    async buildInitialState() {
        const project = await readJsonSafe(join(this.workflowRoot, 'state.json'));
        const phases = await this.readAllPhases();
        const scratch = await this.readAllScratch();
        this.board = {
            project: project ?? emptyProject(),
            phases,
            scratch,
            lastUpdated: new Date().toISOString(),
        };
        this.eventBus.emit(SSE_EVENT_TYPES.BOARD_FULL, this.board);
        return this.board;
    }
    // -------------------------------------------------------------------------
    // Workspace switch — replace root, rebuild state, broadcast switch event
    // -------------------------------------------------------------------------
    get switching() {
        return this.isSwitching;
    }
    async resetForNewWorkspace(newRoot) {
        if (this.isSwitching) {
            throw new Error('Workspace switch already in progress.');
        }
        this.isSwitching = true;
        try {
            this.phaseDirCache.clear();
            this.workflowRoot = newRoot;
            await this.buildInitialState();
            this.eventBus.emit(SSE_EVENT_TYPES.WORKSPACE_SWITCHED, { workspace: resolve(newRoot, '..') });
        }
        finally {
            this.isSwitching = false;
        }
    }
    // -------------------------------------------------------------------------
    // Delta update — re-read a single changed file and emit event
    // -------------------------------------------------------------------------
    async applyFileChange(filePath) {
        const rel = toForwardSlash(relative(this.workflowRoot, filePath));
        // state.json — project-level change
        if (rel === 'state.json') {
            const project = await readJsonSafe(filePath);
            if (project) {
                this.board.project = project;
                this.board.lastUpdated = new Date().toISOString();
                this.eventBus.emit(SSE_EVENT_TYPES.PROJECT_UPDATED, this.board.project);
            }
            return;
        }
        // phases/<slug>/index.json — phase updated
        const phaseIndexMatch = rel.match(/^phases\/[^/]+\/index\.json$/);
        if (phaseIndexMatch) {
            const phase = await readJsonSafe(filePath);
            if (phase) {
                this.upsertPhase(phase);
                this.board.lastUpdated = new Date().toISOString();
                this.eventBus.emit(SSE_EVENT_TYPES.PHASE_UPDATED, phase);
            }
            return;
        }
        // phases/<slug>/.task/TASK-*.json — task updated
        const taskMatch = rel.match(/^phases\/[^/]+\/\.task\/TASK-.*\.json$/);
        if (taskMatch) {
            const task = await readJsonSafe(filePath);
            if (task) {
                this.board.lastUpdated = new Date().toISOString();
                this.eventBus.emit(SSE_EVENT_TYPES.TASK_UPDATED, task);
            }
            return;
        }
        // scratch/<slug>/index.json — scratch task updated
        const scratchMatch = rel.match(/^scratch\/[^/]+\/index\.json$/);
        if (scratchMatch) {
            const scratch = await readJsonSafe(filePath);
            if (scratch) {
                this.upsertScratch(scratch);
                this.board.lastUpdated = new Date().toISOString();
                this.eventBus.emit(SSE_EVENT_TYPES.SCRATCH_UPDATED, scratch);
            }
            return;
        }
        // collab/members/*.json — member profile updated
        const collabMemberMatch = rel.match(/^collab\/members\/[^/]+\.json$/);
        if (collabMemberMatch) {
            this.eventBus.emit(SSE_EVENT_TYPES.COLLAB_MEMBERS_UPDATED, { at: Date.now(), path: filePath });
            return;
        }
        // collab/activity.jsonl — activity log updated
        if (rel === 'collab/activity.jsonl') {
            this.eventBus.emit(SSE_EVENT_TYPES.COLLAB_ACTIVITY, { at: Date.now(), path: filePath });
            return;
        }
    }
    // -------------------------------------------------------------------------
    // Internal helpers
    // -------------------------------------------------------------------------
    upsertPhase(phase) {
        phase = normalizePhase(phase);
        const idx = this.board.phases.findIndex((p) => p.phase === phase.phase);
        if (idx >= 0) {
            this.board.phases[idx] = phase;
        }
        else {
            this.board.phases.push(phase);
            this.board.phases.sort((a, b) => a.phase - b.phase);
        }
    }
    upsertScratch(card) {
        const idx = this.board.scratch.findIndex((s) => s.id === card.id);
        if (idx >= 0) {
            this.board.scratch[idx] = card;
        }
        else {
            this.board.scratch.push(card);
        }
    }
    async readAllPhases() {
        const phasesDir = join(this.workflowRoot, 'phases');
        const slugs = await safeReaddir(phasesDir);
        const phases = [];
        this.phaseDirCache.clear();
        for (const slug of slugs) {
            const dirPath = join(phasesDir, slug);
            const indexPath = join(dirPath, 'index.json');
            const phase = await readJsonSafe(indexPath);
            if (phase) {
                phases.push(normalizePhase(phase));
                this.phaseDirCache.set(phase.phase, dirPath);
            }
        }
        phases.sort((a, b) => a.phase - b.phase);
        return phases;
    }
    async readAllScratch() {
        const scratchDir = join(this.workflowRoot, 'scratch');
        const slugs = await safeReaddir(scratchDir);
        const cards = [];
        for (const slug of slugs) {
            const indexPath = join(scratchDir, slug, 'index.json');
            const card = await readJsonSafe(indexPath);
            if (card) {
                cards.push(card);
            }
        }
        return cards;
    }
}
// ---------------------------------------------------------------------------
// Module-level helpers
// ---------------------------------------------------------------------------
async function findPhaseDir(workflowRoot, phaseNum) {
    const phasesDir = join(workflowRoot, 'phases');
    const slugs = await safeReaddir(phasesDir);
    for (const slug of slugs) {
        const indexPath = join(phasesDir, slug, 'index.json');
        const phase = await readJsonSafe(indexPath);
        if (phase && phase.phase === phaseNum) {
            return join(phasesDir, slug);
        }
    }
    return null;
}
async function readPhaseTasks(phaseDir) {
    const taskDir = join(phaseDir, '.task');
    const entries = await safeReaddirFiles(taskDir);
    const tasks = [];
    for (const entry of entries) {
        if (!entry.startsWith('TASK-') || !entry.endsWith('.json'))
            continue;
        const task = await readJsonSafe(join(taskDir, entry));
        if (task) {
            tasks.push(task);
        }
    }
    return tasks;
}
async function safeReaddir(dir) {
    try {
        const entries = await readdir(dir, { withFileTypes: true });
        return entries.filter((e) => e.isDirectory()).map((e) => e.name);
    }
    catch {
        return [];
    }
}
async function safeReaddirFiles(dir) {
    try {
        const entries = await readdir(dir, { withFileTypes: true });
        return entries.filter((e) => e.isFile()).map((e) => e.name);
    }
    catch {
        return [];
    }
}
function emptyProject() {
    return {
        version: '1.0',
        project_name: '',
        current_milestone: '',
        current_phase: 0,
        status: 'idle',
        phases_summary: { total: 0, completed: 0, in_progress: 0, pending: 0 },
        last_updated: new Date().toISOString(),
        accumulated_context: { key_decisions: [], blockers: [], deferred: [] },
    };
}
function emptyBoard() {
    return {
        project: emptyProject(),
        phases: [],
        scratch: [],
        lastUpdated: new Date().toISOString(),
    };
}
/** Fill missing fields in PhaseCard so components never crash on partial data */
function normalizePhase(p) {
    const raw = p;
    if (p.execution && raw.verification && raw.validation && raw.uat && raw.reflection
        && Array.isArray(p.success_criteria) && Array.isArray(p.requirements)
        && Array.isArray(raw.verification?.must_haves))
        return p;
    return {
        ...p,
        goal: p.goal ?? '',
        success_criteria: p.success_criteria ?? [],
        requirements: p.requirements ?? [],
        spec_ref: p.spec_ref ?? null,
        plan: p.plan ?? { task_ids: [], task_count: 0, complexity: null, waves: [] },
        execution: p.execution ?? { method: '', started_at: null, completed_at: null, tasks_completed: 0, tasks_total: 0, current_wave: 0, commits: [] },
        verification: {
            status: raw.verification?.status ?? 'pending',
            verified_at: raw.verification?.verified_at ?? null,
            must_haves: raw.verification?.must_haves ?? [],
            gaps: raw.verification?.gaps ?? [],
        },
        validation: {
            status: raw.validation?.status ?? 'pending',
            test_coverage: raw.validation?.test_coverage ?? null,
            gaps: raw.validation?.gaps ?? [],
        },
        uat: {
            status: raw.uat?.status ?? 'pending',
            test_count: raw.uat?.test_count ?? 0,
            passed: raw.uat?.passed ?? 0,
            gaps: raw.uat?.gaps ?? [],
        },
        reflection: {
            rounds: raw.reflection?.rounds ?? 0,
            strategy_adjustments: raw.reflection?.strategy_adjustments ?? [],
        },
    };
}
//# sourceMappingURL=state-manager.js.map