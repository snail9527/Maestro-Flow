// ---------------------------------------------------------------------------
// ClaudeCodeAdapter — spawns Claude Code CLI with stream-json protocol
// ---------------------------------------------------------------------------
import { spawn } from 'node:child_process';
import { createInterface } from 'node:readline';
import { randomUUID } from 'node:crypto';
import { resolve as resolvePath } from 'node:path';
import { existsSync } from 'node:fs';
import { BaseAgentAdapter } from './base-adapter.js';
import { EntryNormalizer } from './entry-normalizer.js';
import { loadEnvFile } from './env-file-loader.js';
import { StreamMonitor } from './stream-monitor.js';
import { cleanSpawnEnv } from './env-cleanup.js';
/**
 * Resolve the Claude Code CLI `.js` entry point for direct `node` invocation.
 * On Windows, the global `claude` command is a `.cmd` wrapper requiring
 * `shell: true`, which adds cmd.exe nesting. Spawning `node cli.js` directly
 * avoids that overhead.
 */
function resolveClaudeCliPath() {
    const npmPrefix = process.env.APPDATA
        ? resolvePath(process.env.APPDATA, 'npm', 'node_modules', '@anthropic-ai', 'claude-code', 'cli.js')
        : '';
    if (npmPrefix && existsSync(npmPrefix))
        return npmPrefix;
    return '';
}
// ---------------------------------------------------------------------------
// Adapter implementation
// ---------------------------------------------------------------------------
export class ClaudeCodeAdapter extends BaseAgentAdapter {
    agentType = 'claude-code';
    childProcesses = new Map();
    readlineInterfaces = new Map();
    pendingApprovals = new Map();
    streamMonitors = new Map();
    // --- Lifecycle hooks -----------------------------------------------------
    /** Whether this adapter supports interactive follow-up messages */
    supportsInteractive() {
        return true;
    }
    async doSpawn(processId, config) {
        const interactive = config.interactive === true;
        // Build CLI arguments:
        // --input-format=stream-json requires --print (per Claude Code docs).
        // - Interactive mode: --print --input-format=stream-json (prompt sent via stdin, stdin kept open)
        // - Default mode: --print with prompt as CLI argument (stdin closed immediately)
        const args = interactive
            ? [
                '--output-format=stream-json',
                '--input-format=stream-json',
                '--print',
                '--verbose',
            ]
            : [
                '--output-format=stream-json',
                '--verbose',
                '--print',
                config.prompt,
            ];
        // Map approvalMode to Claude Code permission flags.
        // 'auto' → bypass all permission prompts (yolo) — required for non-interactive
        // --print mode where stdin is closed and no approval responder exists.
        // Claude Code only accepts: default | acceptEdits | bypassPermissions | plan.
        // 'suggest' → allow read-only tools without prompts (analysis mode).
        if (config.approvalMode === 'auto') {
            args.push('--permission-mode', 'bypassPermissions');
        }
        else if (config.approvalMode === 'suggest') {
            args.push('--permission-mode', 'default', '--allowedTools', 'Read,Glob,Grep,WebFetch,WebSearch');
        }
        // Resolve CLI entry point for direct node invocation (avoids cmd.exe
        // wrapper nesting on Windows which causes stdout buffering).
        const envFromFile = config.envFile ? loadEnvFile(config.envFile) : {};
        const envOverrides = { ...envFromFile, ...config.env };
        if (config.baseUrl)
            envOverrides.ANTHROPIC_BASE_URL = config.baseUrl;
        if (config.apiKey)
            envOverrides.ANTHROPIC_API_KEY = config.apiKey;
        const childEnv = cleanSpawnEnv(envOverrides);
        const cliPath = resolveClaudeCliPath();
        const child = cliPath
            ? spawn(process.execPath, [cliPath, ...args], {
                cwd: config.workDir,
                env: childEnv,
                stdio: ['pipe', 'pipe', 'pipe'],
                windowsHide: true,
            })
            : spawn('claude', args, {
                cwd: config.workDir,
                env: childEnv,
                stdio: ['pipe', 'pipe', 'pipe'],
                shell: true,
                windowsHide: true,
            });
        if (!child.stdout || !child.stdin || !child.stderr) {
            throw new Error('Failed to spawn Claude Code: stdio streams not available');
        }
        if (interactive) {
            // Interactive mode: send initial prompt as stream-json SDKUserMessage,
            // keep stdin open for follow-up messages via doSendMessage.
            const initMsg = JSON.stringify({
                type: 'user',
                message: { role: 'user', content: config.prompt },
            });
            child.stdin.write(initMsg + '\n');
        }
        else {
            // One-shot --print mode: close stdin immediately. Without this, the child
            // process blocks indefinitely waiting for stdin input on Windows pipes.
            child.stdin.end();
        }
        // Heartbeat monitor: detect stale streams (60s silence)
        const monitor = new StreamMonitor(() => {
            this.emitEntry(processId, EntryNormalizer.error(processId, 'Stream stale: no output for 60s', 'stream_stale'));
        });
        this.streamMonitors.set(processId, monitor);
        // Line-by-line parsing of stream-json stdout
        const rl = createInterface({ input: child.stdout });
        rl.on('line', (line) => {
            monitor.heartbeat();
            this.parseClaudeMessage(line, processId);
        });
        // Stderr => error entries
        child.stderr.on('data', (chunk) => {
            const text = chunk.toString().trim();
            if (text.length > 0) {
                this.emitEntry(processId, EntryNormalizer.error(processId, text, 'stderr'));
            }
        });
        // Process exit handling
        this.setupProcessListeners(child, processId);
        // Store references for later use
        this.childProcesses.set(processId, child);
        this.readlineInterfaces.set(processId, rl);
        return {
            id: processId,
            type: 'claude-code',
            status: 'running',
            config,
            startedAt: new Date().toISOString(),
            pid: child.pid,
            interactive: true,
        };
    }
    async doStop(processId) {
        const child = this.childProcesses.get(processId);
        if (!child) {
            return;
        }
        // Update status to stopping
        const proc = this.getProcess(processId);
        if (proc) {
            proc.status = 'stopping';
            this.emitEntry(processId, EntryNormalizer.statusChange(processId, 'stopping', 'User requested stop'));
        }
        // Graceful SIGTERM
        child.kill('SIGTERM');
        // SIGKILL fallback after 5 seconds
        const killTimer = setTimeout(() => {
            if (!child.killed) {
                child.kill('SIGKILL');
            }
        }, 5000);
        // Wait for exit, then clean up timer
        child.once('exit', () => {
            clearTimeout(killTimer);
        });
        this.cleanup(processId);
    }
    /** Close stdin to signal no more input — process exits naturally after finishing current work */
    endInput(processId) {
        const child = this.childProcesses.get(processId);
        if (child?.stdin?.writable) {
            child.stdin.end();
        }
    }
    async doSendMessage(processId, content) {
        const child = this.childProcesses.get(processId);
        if (!child?.stdin?.writable) {
            throw new Error(`Cannot send message: stdin not writable for process ${processId}`);
        }
        // SDKUserMessage format required by --input-format=stream-json
        const message = JSON.stringify({
            type: 'user',
            message: { role: 'user', content },
        });
        child.stdin.write(message + '\n');
    }
    async doRespondApproval(decision) {
        const pending = this.pendingApprovals.get(decision.id);
        if (!pending) {
            throw new Error(`No pending approval found with id: ${decision.id}`);
        }
        const child = this.childProcesses.get(decision.processId);
        if (!child?.stdin?.writable) {
            throw new Error(`Cannot respond to approval: stdin not writable for process ${decision.processId}`);
        }
        // Write approval decision to stdin
        const response = JSON.stringify({
            decision: decision.allow ? 'allow' : 'deny',
        });
        child.stdin.write(response + '\n');
        // Emit approval response entry
        this.emitEntry(decision.processId, EntryNormalizer.approvalResponse(decision.processId, decision.id, decision.allow));
        // Resolve the pending promise and clean up
        pending.resolve(decision.allow);
        this.pendingApprovals.delete(decision.id);
    }
    // --- Stream-json parsing -------------------------------------------------
    parseClaudeMessage(line, processId) {
        const trimmed = line.trim();
        if (trimmed.length === 0) {
            return;
        }
        let msg;
        try {
            msg = JSON.parse(trimmed);
        }
        catch {
            // Non-JSON lines are silently skipped (e.g. npx output)
            return;
        }
        if (!msg || typeof msg !== 'object' || !('type' in msg)) {
            return;
        }
        switch (msg.type) {
            case 'assistant': {
                const content = this.extractAssistantContent(msg);
                if (content.length > 0) {
                    this.emitEntry(processId, EntryNormalizer.assistantMessage(processId, content, false));
                }
                break;
            }
            case 'content_block_start': {
                const text = msg.content_block?.text ?? '';
                if (text.length > 0) {
                    this.emitEntry(processId, EntryNormalizer.assistantMessage(processId, text, true));
                }
                break;
            }
            case 'content_block_delta': {
                const text = msg.delta?.text ?? '';
                if (text.length > 0) {
                    this.emitEntry(processId, EntryNormalizer.assistantMessage(processId, text, true));
                }
                break;
            }
            case 'result': {
                // Note: msg.result duplicates the assistant message text already emitted
                // via 'assistant' / 'content_block_*' events, so we skip it here.
                if (msg.usage) {
                    this.emitEntry(processId, EntryNormalizer.tokenUsage(processId, msg.usage.input_tokens ?? 0, msg.usage.output_tokens ?? 0, msg.usage.cache_read_input_tokens, msg.usage.cache_creation_input_tokens));
                }
                break;
            }
            case 'tool_use': {
                const name = msg.name ?? 'unknown';
                const input = msg.input ?? {};
                this.emitEntry(processId, EntryNormalizer.toolUse(processId, name, input, 'running'));
                break;
            }
            case 'tool_result': {
                const name = msg.name ?? 'unknown';
                const status = msg.is_error ? 'failed' : 'completed';
                this.emitEntry(processId, EntryNormalizer.toolUse(processId, name, {}, status, msg.content));
                break;
            }
            case 'permission': {
                this.handlePermissionRequest(msg, processId);
                break;
            }
            case 'system': {
                // System messages are informational; skip silently
                break;
            }
            default:
                console.warn(`[ClaudeCodeAdapter] Unknown stream-json message type: ${msg.type}`);
                break;
        }
    }
    // --- Helpers -------------------------------------------------------------
    extractAssistantContent(msg) {
        const contentBlocks = msg.message?.content;
        if (!Array.isArray(contentBlocks)) {
            return '';
        }
        return contentBlocks
            .filter((block) => block.type === 'text' && typeof block.text === 'string')
            .map((block) => block.text)
            .join('');
    }
    handlePermissionRequest(msg, processId) {
        const toolName = msg.permission?.tool_name ?? 'unknown';
        const toolInput = msg.permission?.input ?? {};
        const requestId = randomUUID();
        // Create a promise that will be resolved when the user responds
        new Promise((resolve) => {
            this.pendingApprovals.set(requestId, { resolve });
        });
        // Build and emit approval request
        const request = {
            id: requestId,
            processId,
            toolName,
            toolInput,
            timestamp: new Date().toISOString(),
        };
        this.emitEntry(processId, EntryNormalizer.approvalRequest(processId, toolName, toolInput, requestId));
        this.emitApproval(processId, request);
    }
    setupProcessListeners(child, processId) {
        child.on('exit', (code, signal) => {
            const reason = signal
                ? `Terminated by signal: ${signal}`
                : `Exited with code: ${code ?? 'unknown'}`;
            this.emitEntry(processId, EntryNormalizer.statusChange(processId, 'stopped', reason));
            const proc = this.getProcess(processId);
            if (proc) {
                proc.status = 'stopped';
            }
            this.cleanup(processId);
            this.removeProcess(processId);
        });
        child.on('error', (err) => {
            this.emitEntry(processId, EntryNormalizer.error(processId, err.message, 'spawn_error'));
            const proc = this.getProcess(processId);
            if (proc) {
                proc.status = 'error';
            }
        });
    }
    cleanup(processId) {
        const rl = this.readlineInterfaces.get(processId);
        if (rl) {
            rl.close();
            this.readlineInterfaces.delete(processId);
        }
        const monitor = this.streamMonitors.get(processId);
        if (monitor) {
            monitor.dispose();
            this.streamMonitors.delete(processId);
        }
        this.childProcesses.delete(processId);
        // Clean up any pending approvals for this process
        this.pendingApprovals.forEach((pending, id) => {
            pending.resolve(false);
            this.pendingApprovals.delete(id);
        });
    }
}
//# sourceMappingURL=claude-code-adapter.js.map