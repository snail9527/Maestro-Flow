// ---------------------------------------------------------------------------
// CodexCliAdapter -- spawns OpenAI Codex CLI with NDJSON protocol
// ---------------------------------------------------------------------------
import { spawn } from 'node:child_process';
import { createInterface } from 'node:readline';
import { BaseAgentAdapter } from './base-adapter.js';
import { EntryNormalizer } from './entry-normalizer.js';
import { loadEnvFile } from './env-file-loader.js';
import { StreamMonitor } from './stream-monitor.js';
import { cleanSpawnEnv } from './env-cleanup.js';
// ---------------------------------------------------------------------------
// Stderr error pattern
// ---------------------------------------------------------------------------
const STDERR_ERROR_RE = /\b(error|fatal)\b/i;
// ---------------------------------------------------------------------------
// Adapter implementation
// ---------------------------------------------------------------------------
export class CodexCliAdapter extends BaseAgentAdapter {
    agentType = 'codex';
    childProcesses = new Map();
    readlineInterfaces = new Map();
    streamMonitors = new Map();
    // --- Lifecycle hooks -----------------------------------------------------
    async doSpawn(processId, config) {
        const args = [
            'exec',
            '--full-auto',
            '--json',
            '--skip-git-repo-check',
            '-',
        ];
        // Profile from config.toml
        if (config.settingsFile) {
            args.push('--profile', config.settingsFile);
        }
        const envFromFile = config.envFile ? loadEnvFile(config.envFile) : {};
        const envOverrides = { ...envFromFile, ...config.env };
        if (config.apiKey)
            envOverrides.OPENAI_API_KEY = config.apiKey;
        const childEnv = cleanSpawnEnv(envOverrides);
        const child = spawn('codex', args, {
            cwd: config.workDir,
            env: childEnv,
            stdio: ['pipe', 'pipe', 'pipe'],
            shell: true,
            windowsHide: true,
        });
        if (!child.stdout || !child.stdin || !child.stderr) {
            throw new Error('Failed to spawn Codex CLI: stdio streams not available');
        }
        // Pipe prompt to stdin then close it
        child.stdin.write(config.prompt);
        child.stdin.end();
        // Heartbeat monitor: detect stale streams (60s silence)
        const monitor = new StreamMonitor(() => {
            this.emitEntry(processId, EntryNormalizer.error(processId, 'Stream stale: no output for 60s', 'stream_stale'));
        });
        this.streamMonitors.set(processId, monitor);
        // Line-by-line parsing of NDJSON stdout
        const rl = createInterface({ input: child.stdout });
        rl.on('line', (line) => {
            monitor.heartbeat();
            this.parseCodexMessage(line, processId);
        });
        // Stderr handling: classify progress vs error
        child.stderr.on('data', (chunk) => {
            const text = chunk.toString().trim();
            if (text.length === 0)
                return;
            for (const line of text.split('\n')) {
                const trimmed = line.trim();
                if (trimmed.length === 0)
                    continue;
                if (STDERR_ERROR_RE.test(trimmed)) {
                    this.emitEntry(processId, EntryNormalizer.error(processId, trimmed, 'stderr'));
                }
                else {
                    this.emitEntry(processId, EntryNormalizer.assistantMessage(processId, trimmed, true));
                }
            }
        });
        // Process exit handling
        this.setupProcessListeners(child, processId);
        // Store references
        this.childProcesses.set(processId, child);
        this.readlineInterfaces.set(processId, rl);
        return {
            id: processId,
            type: 'codex',
            status: 'running',
            config,
            startedAt: new Date().toISOString(),
            pid: child.pid,
            interactive: false,
        };
    }
    async doStop(processId) {
        const child = this.childProcesses.get(processId);
        if (!child)
            return;
        const proc = this.getProcess(processId);
        if (proc) {
            proc.status = 'stopping';
            this.emitEntry(processId, EntryNormalizer.statusChange(processId, 'stopping', 'User requested stop'));
        }
        // Graceful SIGTERM
        child.kill('SIGTERM');
        // SIGKILL fallback after 5 seconds
        const killTimer = setTimeout(() => {
            if (!child.killed) {
                child.kill('SIGKILL');
            }
        }, 5000);
        child.once('exit', () => {
            clearTimeout(killTimer);
        });
        this.cleanup(processId);
    }
    async doSendMessage(_processId, _content) {
        // Codex exec uses single-prompt mode via stdin (already closed after spawn).
        // Interactive messaging is not supported.
        throw new Error('CodexCliAdapter does not support interactive messaging');
    }
    async doRespondApproval(_decision) {
        // Codex --full-auto mode does not request approvals; no-op.
    }
    // --- NDJSON parsing ------------------------------------------------------
    parseCodexMessage(line, processId) {
        const trimmed = line.trim();
        if (trimmed.length === 0)
            return;
        let msg;
        try {
            msg = JSON.parse(trimmed);
        }
        catch {
            // Non-JSON lines silently skipped
            return;
        }
        if (!msg || typeof msg !== 'object' || !('type' in msg))
            return;
        switch (msg.type) {
            case 'thread.started': {
                this.emitEntry(processId, EntryNormalizer.statusChange(processId, 'running', 'Codex session started'));
                break;
            }
            case 'item.completed': {
                const item = msg.item;
                if (item) {
                    this.classifyItem(item, processId);
                }
                break;
            }
            case 'turn.completed': {
                const usage = msg.usage;
                if (usage) {
                    this.emitEntry(processId, EntryNormalizer.tokenUsage(processId, usage.input_tokens ?? 0, usage.output_tokens ?? 0));
                }
                break;
            }
            // turn.started and unknown types are silently skipped
            default:
                break;
        }
    }
    // --- Item classification -------------------------------------------------
    classifyItem(item, processId) {
        const itemType = item.type ?? '';
        const itemName = (item.name ?? '').toLowerCase();
        // Function call that looks like a command execution
        if (itemType === 'function_call_output' ||
            (itemType === 'function_call' && this.isCommandCall(itemName)) ||
            (typeof item.output === 'string' && itemType !== 'message')) {
            const command = item.name ?? item.arguments ?? 'codex_exec';
            const output = item.output ?? '';
            this.emitEntry(processId, EntryNormalizer.commandExec(processId, command, undefined, output));
            return;
        }
        // Function call that looks like a file operation
        if (itemType === 'function_call' && this.isFileCall(itemName)) {
            const filePath = item.filename ?? item.path ?? itemName;
            const action = this.inferFileAction(itemName);
            this.emitEntry(processId, EntryNormalizer.fileChange(processId, filePath, action, item.diff));
            return;
        }
        // Default: treat as assistant message
        const text = this.extractItemText(item);
        if (text.length > 0) {
            this.emitEntry(processId, EntryNormalizer.assistantMessage(processId, text, false));
        }
    }
    isCommandCall(name) {
        return /exec|shell|command|run|bash/.test(name);
    }
    isFileCall(name) {
        return /file|write|create|patch|edit|apply|read/.test(name);
    }
    inferFileAction(name) {
        if (/create|new/.test(name))
            return 'create';
        if (/delete|remove/.test(name))
            return 'delete';
        return 'modify';
    }
    extractItemText(item) {
        // Try content array first
        if (Array.isArray(item.content)) {
            const parts = item.content
                .filter((c) => typeof c.text === 'string')
                .map((c) => c.text);
            if (parts.length > 0)
                return parts.join('');
        }
        // Try direct text field
        if (typeof item.text === 'string')
            return item.text;
        // Try output field
        if (typeof item.output === 'string')
            return item.output;
        // Fallback: stringify the item (skip empty objects)
        const json = JSON.stringify(item);
        return json === '{}' ? '' : json;
    }
    // --- Process lifecycle helpers -------------------------------------------
    setupProcessListeners(child, processId) {
        child.on('exit', (code, signal) => {
            const reason = signal
                ? `Terminated by signal: ${signal}`
                : `Exited with code: ${code ?? 'unknown'}`;
            this.emitEntry(processId, EntryNormalizer.statusChange(processId, 'stopped', reason));
            const proc = this.getProcess(processId);
            if (proc) {
                proc.status = 'stopped';
            }
            this.cleanup(processId);
            this.removeProcess(processId);
        });
        child.on('error', (err) => {
            this.emitEntry(processId, EntryNormalizer.error(processId, err.message, 'spawn_error'));
            const proc = this.getProcess(processId);
            if (proc) {
                proc.status = 'error';
            }
        });
    }
    cleanup(processId) {
        const rl = this.readlineInterfaces.get(processId);
        if (rl) {
            rl.close();
            this.readlineInterfaces.delete(processId);
        }
        const monitor = this.streamMonitors.get(processId);
        if (monitor) {
            monitor.dispose();
            this.streamMonitors.delete(processId);
        }
        this.childProcesses.delete(processId);
    }
}
//# sourceMappingURL=codex-cli-adapter.js.map