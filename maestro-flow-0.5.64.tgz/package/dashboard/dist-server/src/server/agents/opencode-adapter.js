// ---------------------------------------------------------------------------
// OpenCodeAdapter — spawns OpenCode CLI with NDJSON protocol
// ---------------------------------------------------------------------------
import { spawn } from 'node:child_process';
import { createInterface } from 'node:readline';
import { BaseAgentAdapter } from './base-adapter.js';
import { EntryNormalizer } from './entry-normalizer.js';
import { loadEnvFile } from './env-file-loader.js';
import { StreamMonitor } from './stream-monitor.js';
import { cleanSpawnEnv } from './env-cleanup.js';
// ---------------------------------------------------------------------------
// Adapter implementation
// ---------------------------------------------------------------------------
export class OpenCodeAdapter extends BaseAgentAdapter {
    agentType = 'opencode';
    childProcesses = new Map();
    readlineInterfaces = new Map();
    streamMonitors = new Map();
    // --- Lifecycle hooks -----------------------------------------------------
    async doSpawn(processId, config) {
        const args = ['run', '--format', 'json'];
        // Optional model flag
        if (config.model) {
            args.push('--model', config.model);
        }
        // Prompt is a positional argument (last)
        args.push(config.prompt);
        const envFromFile = config.envFile ? loadEnvFile(config.envFile) : {};
        const envOverrides = { ...envFromFile, ...config.env };
        if (config.apiKey)
            envOverrides.OPENAI_API_KEY = config.apiKey;
        const childEnv = cleanSpawnEnv(envOverrides);
        const child = spawn('opencode', args, {
            cwd: config.workDir,
            env: childEnv,
            stdio: ['pipe', 'pipe', 'pipe'],
            shell: true,
            windowsHide: true,
        });
        if (!child.stdout || !child.stderr) {
            throw new Error('Failed to spawn OpenCode: stdio streams not available');
        }
        // Heartbeat monitor: detect stale streams (60s silence)
        const monitor = new StreamMonitor(() => {
            this.emitEntry(processId, EntryNormalizer.error(processId, 'Stream stale: no output for 60s', 'stream_stale'));
        });
        this.streamMonitors.set(processId, monitor);
        // Line-by-line parsing of NDJSON stdout
        const rl = createInterface({ input: child.stdout });
        rl.on('line', (line) => {
            monitor.heartbeat();
            this.parseOpenCodeMessage(line, processId);
        });
        // Stderr => error entries
        child.stderr.on('data', (chunk) => {
            const text = chunk.toString().trim();
            if (text.length > 0) {
                this.emitEntry(processId, EntryNormalizer.error(processId, text, 'stderr'));
            }
        });
        // Process exit handling
        this.setupProcessListeners(child, processId);
        // Store references
        this.childProcesses.set(processId, child);
        this.readlineInterfaces.set(processId, rl);
        return {
            id: processId,
            type: 'opencode',
            status: 'running',
            config,
            startedAt: new Date().toISOString(),
            pid: child.pid,
        };
    }
    async doStop(processId) {
        const child = this.childProcesses.get(processId);
        if (!child) {
            return;
        }
        // Update status to stopping
        const proc = this.getProcess(processId);
        if (proc) {
            proc.status = 'stopping';
            this.emitEntry(processId, EntryNormalizer.statusChange(processId, 'stopping', 'User requested stop'));
        }
        // Graceful SIGTERM
        child.kill('SIGTERM');
        // SIGKILL fallback after 5 seconds
        const killTimer = setTimeout(() => {
            if (!child.killed) {
                child.kill('SIGKILL');
            }
        }, 5000);
        child.once('exit', () => {
            clearTimeout(killTimer);
        });
        this.cleanup(processId);
    }
    async doSendMessage(_processId, _content) {
        throw new Error('OpenCode does not support interactive messages');
    }
    async doRespondApproval(_decision) {
        // No-op: OpenCode does not have an approval workflow
    }
    // --- NDJSON parsing ------------------------------------------------------
    parseOpenCodeMessage(line, processId) {
        const trimmed = line.trim();
        if (trimmed.length === 0) {
            return;
        }
        let msg;
        try {
            msg = JSON.parse(trimmed);
        }
        catch {
            // Non-JSON lines are silently skipped
            return;
        }
        if (!msg || typeof msg !== 'object' || !('type' in msg)) {
            return;
        }
        switch (msg.type) {
            case 'step_start': {
                const reason = msg.step ?? 'Step started';
                this.emitEntry(processId, EntryNormalizer.statusChange(processId, 'running', reason));
                break;
            }
            case 'text': {
                const content = msg.content ?? '';
                if (content.length > 0) {
                    this.emitEntry(processId, EntryNormalizer.assistantMessage(processId, content, false));
                }
                break;
            }
            case 'tool_use': {
                const name = msg.name ?? 'unknown';
                const input = msg.input ?? {};
                this.emitEntry(processId, EntryNormalizer.toolUse(processId, name, input, 'running'));
                break;
            }
            case 'step_finish': {
                if (msg.usage) {
                    this.emitEntry(processId, EntryNormalizer.tokenUsage(processId, msg.usage.input_tokens ?? 0, msg.usage.output_tokens ?? 0));
                }
                break;
            }
            default:
                // Unknown message types are silently ignored
                break;
        }
    }
    // --- Helpers -------------------------------------------------------------
    setupProcessListeners(child, processId) {
        child.on('exit', (code, signal) => {
            const reason = signal
                ? `Terminated by signal: ${signal}`
                : `Exited with code: ${code ?? 'unknown'}`;
            this.emitEntry(processId, EntryNormalizer.statusChange(processId, 'stopped', reason));
            const proc = this.getProcess(processId);
            if (proc) {
                proc.status = 'stopped';
            }
            this.cleanup(processId);
            this.removeProcess(processId);
        });
        child.on('error', (err) => {
            this.emitEntry(processId, EntryNormalizer.error(processId, err.message, 'spawn_error'));
            const proc = this.getProcess(processId);
            if (proc) {
                proc.status = 'error';
            }
        });
    }
    cleanup(processId) {
        const rl = this.readlineInterfaces.get(processId);
        if (rl) {
            rl.close();
            this.readlineInterfaces.delete(processId);
        }
        const monitor = this.streamMonitors.get(processId);
        if (monitor) {
            monitor.dispose();
            this.streamMonitors.delete(processId);
        }
        this.childProcesses.delete(processId);
    }
}
//# sourceMappingURL=opencode-adapter.js.map