import { WebSocket } from 'ws';
import { loadDashboardAgentSettings } from '../../config.js';
import { EntryNormalizer } from '../../agents/entry-normalizer.js';
import { handleDelegateMessage } from '../../../../../src/async/delegate-control.js';
// ---------------------------------------------------------------------------
// AgentWsHandler — spawn, stop, message, approve, CLI bridge forwarding
// ---------------------------------------------------------------------------
export class AgentWsHandler {
    agentManager;
    eventBus;
    workflowRoot;
    delegateMessage;
    actions = [
        'spawn',
        'stop',
        'message',
        'delegate:message',
        'approve',
        'cli:spawned',
        'cli:entry',
        'cli:stopped',
    ];
    constructor(agentManager, eventBus, workflowRoot, delegateMessage = handleDelegateMessage) {
        this.agentManager = agentManager;
        this.eventBus = eventBus;
        this.workflowRoot = workflowRoot;
        this.delegateMessage = delegateMessage;
    }
    async handle(action, data, ws, broadcast) {
        const msg = data;
        switch (action) {
            case 'spawn':
                await this.mergeSettingsAndSpawn(ws, msg.config);
                break;
            case 'stop':
                await this.agentManager.stop(msg.processId);
                break;
            case 'message':
                await this.agentManager.sendMessage(msg.processId, msg.content);
                break;
            case 'delegate:message': {
                const delivery = msg.delivery;
                const content = String(msg.content ?? '').trim();
                const execId = typeof msg.execId === 'string' && msg.execId.trim()
                    ? msg.execId.trim()
                    : typeof msg.processId === 'string'
                        ? msg.processId
                        : '';
                if (!execId) {
                    throw new Error('processId or execId is required');
                }
                if (!content) {
                    throw new Error('content is required');
                }
                if (delivery !== 'inject' && delivery !== 'after_complete') {
                    throw new Error('delivery must be inject or after_complete');
                }
                this.delegateMessage({
                    execId,
                    message: content,
                    delivery,
                    requestedBy: 'dashboard:ws:delegate_message',
                });
                break;
            }
            case 'approve':
                await this.agentManager.respondApproval({
                    id: msg.requestId,
                    processId: msg.processId,
                    allow: msg.allow,
                });
                break;
            case 'cli:spawned': {
                const proc = msg.process;
                this.agentManager.registerCliProcess(proc);
                this.eventBus.emit('agent:spawned', proc);
                if (proc.config?.prompt) {
                    const userEntry = EntryNormalizer.userMessage(proc.id, proc.config.prompt);
                    this.agentManager.addCliEntry(proc.id, userEntry);
                    this.eventBus.emit('agent:entry', userEntry);
                }
                break;
            }
            case 'cli:entry': {
                const entry = msg.entry;
                this.agentManager.addCliEntry(entry.processId, entry);
                this.eventBus.emit('agent:entry', entry);
                break;
            }
            case 'cli:stopped':
                this.agentManager.updateCliProcessStatus(msg.processId, 'stopped');
                this.eventBus.emit('agent:stopped', { processId: msg.processId });
                break;
        }
    }
    /**
     * Merge saved agent settings into spawn config, then spawn.
     * Public so ExecutionWsHandler can reuse it for issue analyze/plan.
     */
    async mergeSettingsAndSpawn(ws, config) {
        const saved = await loadDashboardAgentSettings(this.workflowRoot, config.type);
        const mergedConfig = {
            ...config,
            model: (config.model ?? saved?.model) || undefined,
            approvalMode: config.approvalMode ?? saved?.approvalMode ?? undefined,
            baseUrl: (config.baseUrl ?? saved?.baseUrl) || undefined,
            apiKey: (config.apiKey ?? saved?.apiKey) || undefined,
            settingsFile: (config.settingsFile ?? saved?.settingsFile) || undefined,
            envFile: (config.envFile ?? saved?.envFile) || undefined,
        };
        const proc = await this.agentManager.spawn(mergedConfig.type, mergedConfig);
        const response = {
            type: 'agent:spawned',
            data: proc,
            timestamp: new Date().toISOString(),
        };
        if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify(response));
        }
    }
}
//# sourceMappingURL=agent-handler.js.map