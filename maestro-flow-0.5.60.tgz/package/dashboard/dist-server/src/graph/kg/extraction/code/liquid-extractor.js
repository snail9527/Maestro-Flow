// src/graph/kg/extraction/code/liquid-extractor.ts
// Shopify/Jekyll Liquid 模板提取器:
// render/include/section 标签 → import edge
// schema/assign 块 → variable node
// 参考: codegraph/src/extraction/liquid-extractor.ts
export function extractLiquid(source, filePath) {
    const symbols = [];
    const references = [];
    const edges = [];
    const lines = source.split('\n');
    for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        const lineNum = i + 1;
        // render/include → import edge
        const renderMatch = line.match(/\{%[-\s]*render\s+"([^"]+)"/);
        if (renderMatch) {
            references.push({
                fromSymbolName: '<module>',
                fromSymbolId: `${filePath}:<module>`,
                referenceName: renderMatch[1],
                referenceKind: 'imports',
                line: lineNum,
                col: (renderMatch.index ?? 0) + 1,
                filePath,
                language: 'liquid',
            });
        }
        const includeMatch = line.match(/\{%[-\s]*include\s+"([^"]+)"/);
        if (includeMatch) {
            references.push({
                fromSymbolName: '<module>',
                fromSymbolId: `${filePath}:<module>`,
                referenceName: includeMatch[1],
                referenceKind: 'imports',
                line: lineNum,
                col: (includeMatch.index ?? 0) + 1,
                filePath,
                language: 'liquid',
            });
        }
        // section → import edge
        const sectionMatch = line.match(/\{%[-\s]*section\s+"([^"]+)"/);
        if (sectionMatch) {
            references.push({
                fromSymbolName: '<module>',
                fromSymbolId: `${filePath}:<module>`,
                referenceName: sectionMatch[1],
                referenceKind: 'imports',
                line: lineNum,
                col: (sectionMatch.index ?? 0) + 1,
                filePath,
                language: 'liquid',
            });
        }
        // assign → variable node
        const assignMatch = line.match(/\{%[-\s]*assign\s+(\w+)\s*=/);
        if (assignMatch) {
            symbols.push({
                kind: 'variable',
                name: assignMatch[1],
                qualifiedName: assignMatch[1],
                filePath,
                language: 'liquid',
                startLine: lineNum,
                endLine: lineNum,
                startColumn: (assignMatch.index ?? 0) + 1,
                endColumn: line.length + 1,
                docstring: '',
                signature: `assign ${assignMatch[1]}`,
                visibility: '',
                isExported: false,
                isAsync: false,
                isStatic: false,
                isAbstract: false,
                decorators: [],
                typeParameters: [],
            });
        }
        // schema 块 → JSON schema 定义
        if (line.includes('{% schema %}')) {
            const schemaStart = i;
            let schemaEnd = i;
            for (let j = i + 1; j < lines.length; j++) {
                if (lines[j].includes('{% endschema %}')) {
                    schemaEnd = j;
                    break;
                }
            }
            const schemaContent = lines.slice(schemaStart + 1, schemaEnd).join('\n');
            const nameMatch = schemaContent.match(/"name"\s*:\s*"([^"]+)"/);
            if (nameMatch) {
                symbols.push({
                    kind: 'variable',
                    name: nameMatch[1],
                    qualifiedName: `schema:${nameMatch[1]}`,
                    filePath,
                    language: 'liquid',
                    startLine: schemaStart + 1,
                    endLine: schemaEnd + 1,
                    startColumn: 1,
                    endColumn: 1,
                    docstring: schemaContent.substring(0, 200),
                    signature: `schema "${nameMatch[1]}"`,
                    visibility: '',
                    isExported: false,
                    isAsync: false,
                    isStatic: false,
                    isAbstract: false,
                    decorators: [],
                    typeParameters: [],
                });
            }
        }
    }
    return { symbols, references, edges };
}
//# sourceMappingURL=liquid-extractor.js.map