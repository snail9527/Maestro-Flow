import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import YAML from 'yaml';
import { reportFrontmatterSchema, } from './schemas.js';
export function readReportFrontmatter(runDir) {
    const path = join(runDir, 'report.md');
    if (!existsSync(path))
        return reportFrontmatterSchema.parse({});
    const raw = readFileSync(path, 'utf8');
    const match = raw.match(/^---\s*\r?\n([\s\S]*?)\r?\n---/);
    if (!match)
        return reportFrontmatterSchema.parse({});
    const parsed = YAML.parse(match[1]);
    return reportFrontmatterSchema.parse(parsed ?? {});
}
export function deriveHandoff(frontmatter, runId, command, artifactRefs, evidenceRefs) {
    return {
        schema_version: 'command-handoff/1.0',
        producer_run_id: runId,
        command,
        verdict: frontmatter.verdict,
        summary: frontmatter.summary,
        constraints: frontmatter.constraints,
        decisions: frontmatter.decisions,
        concerns: frontmatter.concerns,
        artifact_refs: artifactRefs,
        next: frontmatter.next.map(item => ({
            command: item.command,
            reason: item.reason,
            needs: item.needs,
        })),
        details: frontmatter.details,
    };
}
//# sourceMappingURL=report.js.map